"""Real gzip I/O and evidence-binding tests; mocked slide QA is not visual approval."""
from contextlib import redirect_stdout
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import deck_gate as gate
import find_designs
import index_designs
import package_skill
from recipe_io import open_recipe_text
from test_index_designs import recipe


class CompressedLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.rows = [recipe(f'recipe-{i}', x=.05 + i*.07) for i in range(6)]
        self.payload = ''.join(json.dumps(r) + '\n' for r in self.rows).encode()
        self.plain = self.root / 'recipes.jsonl'
        self.compressed = self.root / 'recipes.jsonl.gz'
        self.plain.write_bytes(self.payload)
        self.compressed.write_bytes(gzip.compress(self.payload, mtime=0))

    def test_finder_plain_and_compressed_results_match(self):
        self.assertEqual(find_designs.search(self.plain), find_designs.search(self.compressed))
        self.assertEqual(find_designs.search(self.compressed, design_id='recipe-3'), [self.rows[3]])

    def test_index_binds_stored_compressed_bytes(self):
        with redirect_stdout(io.StringIO()):
            result = index_designs.index(self.compressed, self.root / 'index.json', clusters=2)
        self.assertEqual(result['count'], 6)
        self.assertEqual(result['library_sha256'], hashlib.sha256(self.compressed.read_bytes()).hexdigest())
        self.assertNotEqual(result['library_sha256'], hashlib.sha256(self.payload).hexdigest())

    def board(self):
        sample = self.root / 'mock-slide-artifact'
        sample.write_bytes(b'mocked structural QA, not a PPT')
        options = [
            {'id': str(i), 'design_id': r['design_id'], 'reference': gate.bind(self.compressed),
             'reference_validation_note': 'Synthetic structural test only',
             'sample': gate.bind(sample), 'render': {}, 'name': f'Option {i}',
             'design_notes': 'Synthetic independent geometry'}
            for i, r in enumerate(self.rows)]
        board = {'design_round': 'gzip-test', 'options': options}
        (self.root / 'board.json').write_text(json.dumps(board), encoding='utf-8')
        return {'design_round': 'gzip-test', 'recipe_library': gate.bind(self.compressed)}, board

    def test_gate_finds_compressed_recipes_and_rejects_unknown_id(self):
        job, board = self.board()
        infos = [{'slide_count': 2, 'slides': [{'geometry_hash': f'{i}-a'}, {'geometry_hash': f'{i}-b'}]}
                 for i in range(6)]
        with patch.object(gate, 'inspect', side_effect=infos), patch.object(gate, 'check_render'):
            self.assertEqual(gate.check_board(self.root, job), board)
        board['options'][0]['design_id'] = 'missing'
        (self.root / 'board.json').write_text(json.dumps(board), encoding='utf-8')
        with self.assertRaisesRegex(gate.GateError, 'Unknown portable recipe'):
            gate.check_board(self.root, job)

    def test_gate_rejects_tampered_compressed_bytes_before_lookup(self):
        job, _ = self.board()
        # Same decoded JSONL, different valid gzip header: stored-byte binding must fail.
        self.compressed.write_bytes(gzip.compress(self.payload, mtime=1))
        with self.assertRaisesRegex(gate.GateError, 'Stale artifact'):
            gate.check_board(self.root, job)

    def test_corrupt_gzip_is_not_silently_accepted(self):
        damaged = bytearray(self.compressed.read_bytes())
        damaged[-8] ^= 0x01  # Deliberately invalidate the gzip CRC.
        self.compressed.write_bytes(damaged)
        with self.assertRaises(gzip.BadGzipFile):
            with open_recipe_text(self.compressed) as lines:
                list(lines)
        with self.assertRaises(gzip.BadGzipFile):
            find_designs.search(self.compressed, limit=100)

    @unittest.skipUnless(shutil.which('node'), 'Node runtime unavailable')
    def test_node_reader_loads_gzip_and_rejects_crc_without_generating_ppt(self):
        request = self.root / 'request.json'
        request.write_text(json.dumps({'schema': 'aurelia-build-v1', 'purpose': 'validation',
                                      'pages': [{'design_id': 'recipe-0'}]}), encoding='utf-8')
        script = (
            "const {build}=await import(process.argv[1]);"
            "try {await build(process.argv[2],process.argv[3],process.argv[4]);"
            "throw new Error('Unexpected generation');}"
            "catch(error){console.log(error.message);}"
        )
        env = dict(os.environ)
        env.pop('RUNTIME_NODE_MODULES', None)
        def run(library):
            return subprocess.run(
                [shutil.which('node'), '--input-type=module', '-e', script,
                 (SCRIPTS / 'recipe_renderer.mjs').as_uri(), str(library),
                 str(request), str(self.root / 'must-not-exist')],
                check=True, capture_output=True, text=True, env=env, timeout=20).stdout
        for library in (self.plain, self.compressed):
            self.assertIn('Set RUNTIME_NODE_MODULES', run(library))
        damaged = bytearray(self.compressed.read_bytes())
        damaged[-8] ^= 1
        self.compressed.write_bytes(damaged)
        self.assertIn('incorrect data check', run(self.compressed))
        self.assertFalse((self.root / 'must-not-exist').exists())

    def test_packager_includes_and_privacy_scans_decoded_gzip(self):
        skill = self.root / 'portable-skill'
        library = skill / 'design-library'
        library.mkdir(parents=True)
        (skill / 'SKILL.md').write_text('Test skill', encoding='utf-8')
        packed = library / self.compressed.name
        packed.write_bytes(self.compressed.read_bytes())
        output = self.root / 'safe.zip'
        report = package_skill.package(skill, output)
        entry = next(r for r in report['files'] if r['path'].endswith('.jsonl.gz'))
        self.assertEqual(entry['sha256'], hashlib.sha256(packed.read_bytes()).hexdigest())
        with ZipFile(output) as archive:
            self.assertEqual(archive.read('portable-skill/design-library/recipes.jsonl.gz'), packed.read_bytes())
        packed.write_bytes(gzip.compress(b'{"original_text":"private source"}\n', mtime=0))
        with self.assertRaisesRegex(ValueError, 'Private path/content marker'):
            package_skill.package(skill, self.root / 'unsafe.zip')
        self.assertFalse((self.root / 'unsafe.zip').exists())


if __name__ == '__main__':
    unittest.main()
