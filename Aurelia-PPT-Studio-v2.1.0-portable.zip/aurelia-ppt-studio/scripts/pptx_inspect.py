"""Read-only OOXML inspection. No renderer, template or design defaults."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import posixpath
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
      'cx': 'http://schemas.microsoft.com/office/drawing/2014/chartex'}
REL = 'http://schemas.openxmlformats.org/package/2006/relationships'


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def read_xml(z, part):
    if z.getinfo(part).file_size > 16 * 1024 * 1024:
        raise ValueError(f'XML too large: {part}')
    return ET.fromstring(z.read(part))


def relationships(z, part):
    folder, name = posixpath.split(part)
    rp = posixpath.join(folder, '_rels', name + '.rels')
    if rp not in z.namelist():
        return {}
    return {r.get('Id'): dict(r.attrib) for r in read_xml(z, rp)}


def resolve(part, target):
    return posixpath.normpath(posixpath.join(posixpath.dirname(part), target)).lstrip('/')


def paragraphs(root):
    return [''.join(n.text or '' for n in p.findall('.//a:t', NS)).strip()
            for p in root.findall('.//a:p', NS)]


def inspect(path):
    result = {'sha256': sha(path), 'slides': [], 'signals': [], 'limitations': [
        'Geometry fingerprint ignores color/text and is not perceptual similarity.',
        'Inherited placeholders and nested group transforms require visual review.',
        'This inspector does not measure rendered text overflow or factual correctness.']}
    with ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError('Bad ZIP CRC')
        pres = read_xml(z, 'ppt/presentation.xml')
        size = pres.find('p:sldSz', NS)
        width, height = int(size.get('cx')), int(size.get('cy'))
        if min(width, height) <= 0:
            raise ValueError('Invalid slide size')
        result['slide_size_emu'] = [width, height]
        rels = relationships(z, 'ppt/presentation.xml')
        ids = pres.findall('p:sldIdLst/p:sldId', NS)
        for number, sid in enumerate(ids, 1):
            rel = rels[sid.get('{' + NS['r'] + '}id')]
            if rel.get('TargetMode') == 'External':
                raise ValueError('External slide relationship')
            part = resolve('ppt/presentation.xml', rel['Target'])
            root = read_xml(z, part)
            texts = [p for p in paragraphs(root) if p]
            elems, missing = [], 0
            tree = root.find('p:cSld/p:spTree', NS)
            for node in list(tree) if tree is not None else []:
                tag = node.tag.rsplit('}', 1)[-1]
                if tag not in ('sp', 'pic', 'graphicFrame', 'cxnSp', 'grpSp'):
                    continue
                kind = tag
                if node.find('.//a:tbl', NS) is not None:
                    kind = 'table'
                elif node.find('.//c:chart', NS) is not None or node.find('.//cx:chart', NS) is not None:
                    kind = 'chart'
                elif node.find('p:txBody', NS) is not None:
                    kind = 'text'
                xfrm = node.find('p:spPr/a:xfrm', NS)
                if xfrm is None:
                    xfrm = node.find('p:xfrm', NS)
                if xfrm is None:
                    xfrm = node.find('p:grpSpPr/a:xfrm', NS)
                off = xfrm.find('a:off', NS) if xfrm is not None else None
                ext = xfrm.find('a:ext', NS) if xfrm is not None else None
                if off is None or ext is None:
                    missing += 1
                    box = None
                else:
                    box = [int(off.get('x')) / width, int(off.get('y')) / height,
                           int(ext.get('cx')) / width, int(ext.get('cy')) / height]
                    # Native decorative bleed can be intentional: signal, never auto-delete.
                    if box[0] < -.01 or box[1] < -.01 or box[0]+box[2] > 1.01 or box[1]+box[3] > 1.01:
                        result['signals'].append({'id': f'outside-{number}-{len(elems)}',
                                                  'slide': number, 'kind': 'outside_canvas'})
                sizes = sorted({round(int(n.get('sz'))/100, 2) for n in node.findall('.//a:rPr', NS)
                                if n.get('sz', '').isdigit()})
                elems.append({'kind': kind, 'box': [round(v, 3) for v in box] if box else None,
                              'font_sizes': sizes})
            # Entire paragraph equality within a slide often detects subtitle/body duplication.
            for text, count in Counter(texts).items():
                if count > 1 and len(text) >= 12:
                    result['signals'].append({'id': f'duplicate-{number}-{digest(text)[:8]}',
                                              'slide': number, 'kind': 'duplicate_paragraph',
                                              'count': count, 'text': text})
            if not texts:
                result['signals'].append({'id': f'no-text-{number}', 'slide': number,
                                          'kind': 'no_editable_text'})
            if missing or any(e['kind'] == 'grpSp' for e in elems):
                result['signals'].append({'id': f'geometry-review-{number}', 'slide': number,
                                          'kind': 'inherited_or_group_geometry'})
            silhouette = sorted((e['kind'], tuple(round(v * 25) for v in e['box']))
                                for e in elems if e['box'])
            sr = relationships(z, part)
            notes = []
            for r in sr.values():
                if r.get('Type', '').endswith('/notesSlide') and r.get('TargetMode') != 'External':
                    notes.extend(paragraphs(read_xml(z, resolve(part, r['Target']))))
            fonts = sorted({n.get('typeface') for n in root.iter()
                            if n.tag.rsplit('}', 1)[-1] in ('latin','ea','cs') and n.get('typeface')})
            result['slides'].append({'number': number, 'part': part, 'paragraphs': texts,
                'notes': notes, 'elements': elems, 'fonts': fonts,
                'geometry_hash': digest(silhouette) if silhouette else None,
                'content_hash': digest(texts), 'table_count': len(root.findall('.//a:tbl', NS)),
                'chart_count': len(root.findall('.//c:chart', NS)) + len(root.findall('.//cx:chart', NS)),
                'picture_count': len(root.findall('.//p:pic', NS)),
                'external_relationship_count': sum(r.get('TargetMode') == 'External' for r in sr.values())})
    result['slide_count'] = len(result['slides'])
    repeated = Counter(s['geometry_hash'] for s in result['slides'] if s['geometry_hash'])
    result['unique_geometry_count'] = len(repeated)
    if result['slide_count'] >= 6 and repeated and max(repeated.values()) / result['slide_count'] > .5:
        result['signals'].append({'id': 'repetitive-layout', 'kind': 'majority_same_silhouette',
                                  'count': max(repeated.values())})
    return result


def compare(before, after):
    a, b = inspect(before), inspect(after)
    n = min(a['slide_count'], b['slide_count'])
    return {'before_sha256': a['sha256'], 'after_sha256': b['sha256'], 'compared_slides': n,
            'identical_file': a['sha256'] == b['sha256'],
            'same_geometry_pages': [i+1 for i in range(n) if a['slides'][i]['geometry_hash']
                                    and a['slides'][i]['geometry_hash'] == b['slides'][i]['geometry_hash']],
            'same_content_pages': [i+1 for i in range(n) if a['slides'][i]['content_hash'] == b['slides'][i]['content_hash']]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pptx')
    parser.add_argument('--compare-to')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    data = compare(args.compare_to, args.pptx) if args.compare_to else inspect(args.pptx)
    write_json(args.output, data)
    print(json.dumps({k:v for k,v in data.items() if k not in ('slides', 'signals')}, ensure_ascii=False))
