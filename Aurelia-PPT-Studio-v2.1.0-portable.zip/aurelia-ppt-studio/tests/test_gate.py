"""Engineering invariants, NOT a presentation-design or Office compatibility test.

All PPTX, PNG, source, and finalization-receipt fixtures below are synthetic.
A passing fixture only establishes gate behavior; it is not evidence that a
real engine rendered a real professional deck or that factual claims are true.
Run: python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED
import zlib

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import deck_gate as gate
import pptx_inspect as inspector

P = inspector.NS["p"]
A = inspector.NS["a"]
R = inspector.NS["r"]
REL = inspector.REL
WIDTH, HEIGHT = 12192000, 6858000


def make_png(path: Path, shade=240):
    """Generate an actual decodable opaque 960 x 540 RGB PNG using stdlib."""
    def chunk(kind, payload):
        return (struct.pack(">I", len(payload)) + kind + payload
                + struct.pack(">I", zlib.crc32(kind + payload) & 0xffffffff))
    pixels = (b"\0" + bytes([shade, shade, shade]) * 960) * 540
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"\x89PNG\r\n\x1a\n"
                     + chunk(b"IHDR", struct.pack(">IIBBBBB", 960, 540, 8, 2, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b""))


def make_deck(path: Path, shifts=(0.05, 0.1), color="123456", order=None,
              duplicate=False, notes="S:p1", text="Verified metric 42", scale=1, native=None):
    """Small OOXML fixture sufficient to exercise the read-only inspector."""
    path.parent.mkdir(parents=True, exist_ok=True)
    order = order or list(range(1, len(shifts) + 1))
    with ZipFile(path, "w", ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '</Types>')
        z.writestr("_rels/.rels", f'<Relationships xmlns="{REL}"><Relationship Id="root" '
                   f'Type="{R}/officeDocument" Target="ppt/presentation.xml"/></Relationships>')
        ids = ''.join(f'<p:sldId id="{255+i}" r:id="r{i}"/>' for i in order)
        z.writestr("ppt/presentation.xml", f'<p:presentation xmlns:p="{P}" xmlns:r="{R}">'
                   f'<p:sldIdLst>{ids}</p:sldIdLst><p:sldSz cx="{WIDTH*scale}" cy="{HEIGHT*scale}"/>'
                   '</p:presentation>')
        rels = ''.join(f'<Relationship Id="r{i}" Type="{R}/slide" Target="slides/slide{i}.xml"/>'
                       for i in range(1, len(shifts)+1))
        z.writestr("ppt/_rels/presentation.xml.rels", f'<Relationships xmlns="{REL}">{rels}</Relationships>')
        for i, x in enumerate(shifts, 1):
            para = f'<a:p><a:r><a:rPr sz="2400"/><a:t>{escape(text)} / page {i}</a:t></a:r></a:p>'
            if duplicate:
                para += para
            shape = (f'<p:sp><p:nvSpPr><p:cNvPr id="2" name="Fixture text"/></p:nvSpPr>'
                     f'<p:spPr><a:xfrm><a:off x="{int(x*WIDTH)*scale}" y="{int(.12*HEIGHT)*scale}"/>'
                     f'<a:ext cx="{int(.4*WIDTH)*scale}" cy="{int(.3*HEIGHT)*scale}"/></a:xfrm>'
                     f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill></p:spPr>'
                     f'<p:txBody><a:bodyPr/><a:lstStyle/>{para}</p:txBody></p:sp>')
            if native:
                if native == "chartEx":
                    payload = '<cx:chart xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"/>'
                elif native == "chart":
                    payload = '<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"/>'
                elif native == "table":
                    payload = '<a:tbl><a:tblPr/><a:tblGrid><a:gridCol w="2000000"/></a:tblGrid></a:tbl>'
                else:
                    raise ValueError(native)
                shape += (f'<p:graphicFrame><p:xfrm><a:off x="1000000" y="3500000"/>'
                          f'<a:ext cx="6000000" cy="1500000"/></p:xfrm>'
                          f'<a:graphic><a:graphicData>{payload}</a:graphicData></a:graphic></p:graphicFrame>')
            z.writestr(f"ppt/slides/slide{i}.xml", f'<p:sld xmlns:p="{P}" xmlns:a="{A}">'
                       f'<p:cSld><p:spTree>{shape}</p:spTree></p:cSld></p:sld>')
            z.writestr(f"ppt/slides/_rels/slide{i}.xml.rels", f'<Relationships xmlns="{REL}">'
                       f'<Relationship Id="notes" Type="{R}/notesSlide" Target="../notesSlides/notesSlide{i}.xml"/>'
                       '</Relationships>')
            z.writestr(f"ppt/notesSlides/notesSlide{i}.xml", f'<p:notes xmlns:p="{P}" xmlns:a="{A}">'
                       f'<p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>{escape(notes)}</a:t>'
                       '</a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:notes>')


class SyntheticJob:
    def __init__(self, root: Path):
        self.root = root
        self.corpus = root / "corpus"
        self.corpus.mkdir()
        self.candidate = root / "candidate.pptx"
        make_deck(self.candidate)
        self.builder = root / "builder.mjs"
        self.builder.write_text("// SYNTHETIC TEST FIXTURE; not a real builder\n", encoding="utf-8")
        self.source = root / "source.txt"
        self.source.write_text("Synthetic source, page 1: Verified metric 42.\n", encoding="utf-8")
        self.receipt = root / "engine.json"
        self.make_receipt()
        options = []
        for i in range(7):
            reference = self.corpus / f"reference-{i}.pptx"
            sample = root / "samples" / f"sample-{i}.pptx"
            make_deck(reference, shifts=(.02+i*.065, .02+i*.065))
            make_deck(sample, shifts=(.02+i*.065, .02+i*.065))
            options.append({"id": str(i+1), "name": f"Synthetic direction {i+1}",
                            "reference": gate.bind(reference), "reference_pages": [1, 2],
                            "sample": gate.bind(sample), "render": self.make_render(sample, root / "samples" / f"renders-{i}"),
                            "design_notes": "Synthetic geometrically distinct test fixture only."})
        self.board = {"design_round": "test-round", "options": options}
        gate.write_json(root / "board.json", self.board)
        self.selection = {"design_round": "test-round", "board_sha256": gate.sha(root / "board.json"),
                          "option": "1", "user_quote": "Fixture user chooses 1", "board_shown_to_user": True}
        gate.write_json(root / "selection.json", self.selection)
        self.job = {"schema": "aurelia-job-v2", "design_round": "test-round", "corpus_root": str(self.corpus),
                    "mode": "new", "brief": {"slide_count": 2, "audience": "test", "objective": "test invariants", "density": "detailed"},
                    "sources": [dict(gate.bind(self.source), id="S", pages=1)],
                    "evidence": [{"id": "E", "source_id": "S", "page": 1, "claim": "Verified metric 42", "locator": "Synthetic line 1", "kind": "fact"}],
                    "required_topics": [{"topic": "Verified metric", "slides": [1, 2]}],
                    "storyboard": [{"slide": i, "title": f"Page {i}", "purpose": "analysis", "body": "Verified metric 42", "layout_family": f"family-{i}",
                                    "visual_owner": "text", "evidence_ids": ["E"], "required_terms": ["Verified metric 42"]} for i in (1, 2)],
                    "design_tokens": {"option": "1", "fonts": ["Fixture sans"], "palette": ["123456"], "layout_vocabulary": ["test offsets"],
                                      "pilot_review": {"render_sha256": options[0]["render"]["sha256"],
                                                       "observation": "Synthetic observation to test review gating; no real design quality claim."}},
                    "candidate": gate.bind(self.candidate), "builder": gate.bind(self.builder), "engine_receipt": gate.bind(self.receipt),
                    "render": self.make_render(self.candidate, root / "candidate-render")}
        self.save()
        self.seal_review()

    def make_receipt(self):
        gate.write_json(self.receipt, {"schemaVersion": "presentation-finalization.v1", "finalSha256": gate.sha(self.candidate),
                                     "packageIntegrity": {"exitCode": 0, "findingCount": 0},
                                     "presentationLayout": {"exitCode": 0, "findingCount": 0}, "firstPartyImport": {"passed": True},
                                     "test_fixture_only": True})

    def make_render(self, deck, folder):
        pages = []
        for i in range(1, inspector.inspect(deck)["slide_count"] + 1):
            image = folder / f"slide-{i}.png"
            make_png(image, shade=230+i)
            pages.append(dict(gate.bind(image), slide=i, width=960, height=540))
        manifest = folder / "render.json"
        gate.write_json(manifest, {"candidate_sha256": gate.sha(deck), "directory": str(folder.resolve()), "slides": pages,
                                   "test_fixture_only": True})
        return gate.bind(manifest)

    def save(self):
        gate.write_json(self.root / "job.json", self.job)

    def save_board(self, reselect=False):
        gate.write_json(self.root / "board.json", self.board)
        if reselect:
            self.selection["board_sha256"] = gate.sha(self.root / "board.json")
            gate.write_json(self.root / "selection.json", self.selection)

    def seal_review(self):
        report = gate.validate(self.root, include_review=False)
        pages = gate.load(self.job["render"]["path"])["slides"]
        gate.write_json(self.root / "review.json", {"snapshot": report["snapshot"], "reviewer": "synthetic-test-harness",
            "review_method": "agent-self-review", "coverage": True, "factual_accuracy": True, "design_fidelity": True, "editability": True,
            "issues": [], "signal_dispositions": {s["id"]: "Synthetic signal disposition, only tests the gate." for s in report["signals"]},
            "slides": [{"slide": p["slide"], "image_sha256": p["sha256"], "content": "Synthetic specific content observation.",
                        "style": "Synthetic specific style observation.", "readability": "Synthetic specific readability observation."} for p in pages]})

    def rebind_candidate(self):
        self.job["candidate"] = gate.bind(self.candidate)
        self.make_receipt()
        self.job["engine_receipt"] = gate.bind(self.receipt)
        self.job["render"] = self.make_render(self.candidate, self.root / "candidate-render")
        self.save()

    def portable(self):
        """Retain only neutral test recipe metadata; remove all synthetic originals."""
        self.library = self.root / "portable" / "recipes.jsonl"
        self.library.parent.mkdir()
        self.recipes = [{"design_id": f"fixture-design-{i}", "source_sha256": option["reference"]["sha256"],
                         "source_page": 1, "test_fixture_only": True} for i, option in enumerate(self.board["options"])]
        self.save_library()
        self.job["corpus_root"] = None
        for i, option in enumerate(self.board["options"]):
            option["design_id"] = self.recipes[i]["design_id"]
            option["reference"] = gate.bind(self.library)
            option.pop("reference_pages")
            option["reference_validation_note"] = "Synthetic structural-only recipe, not visually validated against a real template."
        self.save_library(rebind=True)
        for path in self.corpus.iterdir():
            # These are only the seven files made by this test's constructor.
            if path.parent == self.corpus and path.name.startswith("reference-") and path.suffix == ".pptx":
                path.unlink()
        self.corpus.rmdir()
        self.seal_review()

    def save_library(self, rebind=False):
        self.library.write_text(''.join(json.dumps(r) + '\n' for r in self.recipes), encoding="utf-8")
        if rebind:
            self.job["recipe_library"] = gate.bind(self.library)
            for option in self.board["options"]:
                option["reference"] = gate.bind(self.library)
            self.save_board(reselect=True); self.save()


class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="aurelia-gate-test-")
        self.addCleanup(self.tmp.cleanup)
        self.fx = SyntheticJob(Path(self.tmp.name))

    def reject(self, fragment, review=False):
        result = gate.validate(self.fx.root, include_review=review)
        self.assertFalse(result["passed"], result)
        self.assertIn(fragment, "\n".join(result["errors"]))

    def cli(self, *args):
        return subprocess.run([sys.executable, str(SCRIPTS / "deck_gate.py"), "--job", str(self.fx.root), *args],
                              capture_output=True, text=True, encoding="utf-8", errors="replace")

    def test_synthetic_positive_gate(self):
        result = gate.validate(self.fx.root)
        self.assertTrue(result["passed"], result["errors"])

    def test_release_is_exclusive_and_byte_identical(self):
        first = self.cli("release")
        self.assertEqual(first.returncode, 0, first.stderr)
        released = list((self.fx.root / "released").glob("*.pptx"))
        self.assertEqual(len(released), 1)
        self.assertEqual(released[0].read_bytes(), self.fx.candidate.read_bytes())
        before = gate.sha(released[0])
        second = self.cli("release")
        self.assertNotEqual(second.returncode, 0)
        self.assertEqual(gate.sha(released[0]), before)

    def test_missing_source(self):
        self.fx.job["sources"] = []; self.fx.save()
        self.reject("No verified content sources")

    def test_stale_source(self):
        self.fx.source.write_text("Changed source", encoding="utf-8")
        self.reject("Stale artifact: source.txt")

    def test_invalid_evidence_page(self):
        self.fx.job["evidence"][0]["page"] = 2; self.fx.save()
        self.reject("Invalid evidence page")

    def test_unknown_evidence_id(self):
        self.fx.job["storyboard"][0]["evidence_ids"] = ["UNKNOWN"]; self.fx.save()
        self.reject("Unknown evidence")

    def test_old_style_round(self):
        self.fx.selection["design_round"] = "old-round"
        gate.write_json(self.fx.root / "selection.json", self.fx.selection)
        self.reject("previous round")

    def test_board_changed_after_selection(self):
        self.fx.board["options"][0]["name"] = "Changed title"; self.fx.save_board()
        self.reject("Board changed after style selection")

    def test_visual_board_not_shown(self):
        self.fx.selection["board_shown_to_user"] = False
        gate.write_json(self.fx.root / "selection.json", self.fx.selection)
        self.reject("Visual board was not shown")

    def test_missing_user_reply(self):
        self.fx.selection["user_quote"] = "  "
        gate.write_json(self.fx.root / "selection.json", self.fx.selection)
        self.reject("Missing actual user style reply")

    def test_too_few_options(self):
        self.fx.board["options"] = self.fx.board["options"][:5]; self.fx.save_board(reselect=True)
        self.reject("Need 6")

    def test_seven_recolored_options_are_rejected(self):
        for i, option in enumerate(self.fx.board["options"]):
            sample = Path(option["sample"]["path"])
            make_deck(sample, shifts=(.1, .2), color=f"{i*24:02X}0000")
            option["sample"] = gate.bind(sample)
            option["render"] = self.fx.make_render(sample, self.fx.root / f"recolor-{i}")
        self.fx.save_board(reselect=True)
        self.reject("repeat the same silhouettes")

    def test_style_directions_cannot_differ_only_in_cover(self):
        for i, option in enumerate(self.fx.board["options"]):
            sample = Path(option["sample"]["path"])
            make_deck(sample, shifts=(.02+i*.065, .2), color=f"{i*24:02X}0000")
            option["sample"] = gate.bind(sample)
            option["render"] = self.fx.make_render(sample, self.fx.root / f"cover-only-{i}")
        self.fx.save_board(reselect=True)
        self.fx.job["design_tokens"]["pilot_review"]["render_sha256"] = self.fx.board["options"][0]["render"]["sha256"]
        self.fx.save()
        result = gate.validate(self.fx.root, include_review=False)
        self.assertFalse(result["passed"], "Different cover offsets conceal identical substantive style samples")

    def test_option_reference_outside_corpus(self):
        self.fx.board["options"][0]["reference"] = gate.bind(self.fx.candidate); self.fx.save_board(reselect=True)
        self.reject("outside the approved corpus")

    def test_out_of_range_reference_page(self):
        self.fx.board["options"][0]["reference_pages"] = [3]; self.fx.save_board(reselect=True)
        self.reject("reference page is invalid")

    def test_design_option_mismatch(self):
        self.fx.job["design_tokens"]["option"] = "2"; self.fx.save()
        self.reject("does not match selected option")

    def test_stale_pilot_review(self):
        self.fx.job["design_tokens"]["pilot_review"]["render_sha256"] = "old"; self.fx.save()
        self.reject("no current pilot review")

    def test_stale_builder(self):
        self.fx.builder.write_text("// changed builder", encoding="utf-8")
        self.reject("Stale artifact: builder.mjs")

    def test_stale_candidate(self):
        make_deck(self.fx.candidate, text="Changed claim")
        self.reject("Stale artifact: candidate.pptx")

    def test_engine_receipt_for_different_deck(self):
        receipt = gate.load(self.fx.receipt); receipt["finalSha256"] = "wrong"
        gate.write_json(self.fx.receipt, receipt)
        self.fx.job["engine_receipt"] = gate.bind(self.fx.receipt); self.fx.save()
        self.reject("Engine validated a different candidate")

    def test_engine_warning_blocks_delivery(self):
        receipt = gate.load(self.fx.receipt); receipt["presentationLayout"]["findingCount"] = 1
        gate.write_json(self.fx.receipt, receipt)
        self.fx.job["engine_receipt"] = gate.bind(self.fx.receipt); self.fx.save()
        self.reject("Engine check not passed")

    def test_stale_render_manifest(self):
        manifest = Path(self.fx.job["render"]["path"])
        data = gate.load(manifest); data["candidate_sha256"] = "old"
        gate.write_json(manifest, data)
        self.reject("Stale artifact: render.json")

    def test_render_for_other_candidate(self):
        manifest = Path(self.fx.job["render"]["path"])
        data = gate.load(manifest); data["candidate_sha256"] = "old"
        gate.write_json(manifest, data)
        self.fx.job["render"] = gate.bind(manifest); self.fx.save()
        self.reject("Render does not belong to current deck")

    def test_changed_render_image(self):
        data = gate.load(self.fx.job["render"]["path"])
        make_png(Path(data["slides"][0]["path"]), shade=180)
        self.reject("Stale artifact: slide-1.png")

    def test_render_header_without_image_pixels_is_rejected(self):
        manifest = Path(self.fx.job["render"]["path"])
        data = gate.load(manifest)
        image = Path(data["slides"][0]["path"])
        # This looks large enough to the existing 24-byte header-only probe,
        # but is not a decodable image and therefore cannot be visual evidence.
        image.write_bytes(image.read_bytes()[:24])
        data["slides"][0].update(gate.bind(image))
        gate.write_json(manifest, data)
        self.fx.job["render"] = gate.bind(manifest); self.fx.save()
        result = gate.validate(self.fx.root, include_review=False)
        self.assertFalse(result["passed"], "Truncated PNG without any pixels must not count as a reviewed rendering")

    def test_missing_rendered_page(self):
        manifest = Path(self.fx.job["render"]["path"])
        data = gate.load(manifest); data["slides"] = data["slides"][:1]
        gate.write_json(manifest, data)
        self.fx.job["render"] = gate.bind(manifest); self.fx.save()
        self.reject("Incomplete/duplicate/out-of-order")

    def test_unrelated_png_rejected(self):
        make_png(self.fx.root / "candidate-render" / "leftover.png")
        self.reject("missing or unrelated PNGs")

    def test_source_locator_missing_in_notes(self):
        make_deck(self.fx.candidate, notes="No sources")
        self.fx.rebind_candidate()
        self.reject("lacks source locator in notes")

    def test_wrong_source_page_prefix_is_not_valid_citation(self):
        make_deck(self.fx.candidate, notes="S:p10")
        self.fx.rebind_candidate()
        self.reject("source locator")

    def test_required_visible_term_omitted(self):
        self.fx.job["storyboard"][0]["required_terms"] = ["Absent important fact"]
        self.fx.save()
        self.reject("omits required content")

    def test_chart_owner_requires_native_chart(self):
        self.fx.job["storyboard"][0]["visual_owner"] = "chart"; self.fx.save()
        self.reject("lacks editable chart")

    def test_table_owner_requires_native_table(self):
        self.fx.job["storyboard"][0]["visual_owner"] = "table"; self.fx.save()
        self.reject("lacks editable table")

    def test_native_chart_owner_is_detected(self):
        make_deck(self.fx.candidate, native="chart")
        self.fx.job["storyboard"][0]["visual_owner"] = "chart"
        self.fx.rebind_candidate(); self.fx.seal_review()
        result = gate.validate(self.fx.root)
        self.assertTrue(result["passed"], result["errors"])

    def test_native_chartex_owner_is_detected(self):
        make_deck(self.fx.candidate, native="chartEx")
        self.fx.job["storyboard"][0]["visual_owner"] = "chart"
        self.fx.rebind_candidate(); self.fx.seal_review()
        result = gate.validate(self.fx.root)
        self.assertTrue(result["passed"], result["errors"])

    def test_native_table_owner_is_detected(self):
        make_deck(self.fx.candidate, native="table")
        self.fx.job["storyboard"][0]["visual_owner"] = "table"
        self.fx.rebind_candidate(); self.fx.seal_review()
        result = gate.validate(self.fx.root)
        self.assertTrue(result["passed"], result["errors"])

    def test_redesign_same_geometry_is_audited(self):
        previous = self.fx.root / "previous.pptx"
        make_deck(previous, color="DDEEAA")
        self.fx.job["previous_candidate"] = gate.bind(previous)
        self.fx.job["mode"] = "redesign"; self.fx.save(); self.fx.seal_review()
        review = gate.load(self.fx.root / "review.json")
        self.assertIn("redesign-same-geometry", review["signal_dispositions"])
        review["signal_dispositions"] = {}
        gate.write_json(self.fx.root / "review.json", review)
        self.reject("Unreviewed inspector signal: redesign-same-geometry", review=True)

    def test_wrong_slide_count(self):
        self.fx.job["brief"]["slide_count"] = 3; self.fx.save()
        self.reject("Expected 3 pages; actual 2")

    def test_storyboard_missing_page(self):
        self.fx.job["storyboard"] = self.fx.job["storyboard"][:1]; self.fx.save()
        self.reject("Storyboard must cover every page")

    def test_stale_review_after_job_change(self):
        self.fx.job["brief"]["objective"] = "Changed objective"; self.fx.save()
        self.reject("Review is stale", review=True)

    def test_missing_slide_review(self):
        review = gate.load(self.fx.root / "review.json"); review["slides"] = review["slides"][:1]
        gate.write_json(self.fx.root / "review.json", review)
        self.reject("Missing/duplicate slide reviews", review=True)

    def test_missing_concrete_visual_review(self):
        review = gate.load(self.fx.root / "review.json"); review["slides"][0]["readability"] = "pass"
        gate.write_json(self.fx.root / "review.json", review)
        self.reject("missing specific readability", review=True)

    def test_unresolved_issue_rejected(self):
        review = gate.load(self.fx.root / "review.json"); review["issues"] = [{"status": "open", "description": "Overflow"}]
        gate.write_json(self.fx.root / "review.json", review)
        self.reject("Unresolved review issues", review=True)

    def test_required_inspector_signal_disposition(self):
        make_deck(self.fx.candidate, duplicate=True)
        self.fx.rebind_candidate(); self.fx.seal_review()
        review = gate.load(self.fx.root / "review.json"); review["signal_dispositions"] = {}
        gate.write_json(self.fx.root / "review.json", review)
        self.reject("Unreviewed inspector signal", review=True)

    def test_local_path_traversal_rejected(self):
        with self.assertRaisesRegex(gate.GateError, "outside job"):
            gate.local(self.fx.root, "../escape.txt")
        with self.assertRaisesRegex(gate.GateError, "outside job"):
            gate.local(self.fx.root, str(self.fx.root.parent / "escape.txt"))

    def test_bind_cannot_use_outside_builder(self):
        result = self.cli("bind", "--candidate", "candidate.pptx", "--builder", "../outside.mjs", "--receipt", "engine.json")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("outside job", result.stderr)

    def test_candidate_outside_job_rejected(self):
        with tempfile.TemporaryDirectory(prefix="aurelia-external-test-") as outside:
            candidate = Path(outside) / "outside.pptx"; make_deck(candidate)
            self.fx.job["candidate"] = gate.bind(candidate); self.fx.save()
            self.reject("Candidate outside job")

    def test_render_directory_symlink_cannot_escape_job(self):
        with tempfile.TemporaryDirectory(prefix="aurelia-render-escape-") as outside:
            link = self.fx.root / "renders"
            try:
                os.symlink(outside, link, target_is_directory=True)
            except OSError as exc:
                self.skipTest(f"Directory symlinks unavailable on this host: {exc}")
            try:
                result = self.cli("render", "--deck", "candidate.pptx", "--node", "unused-node",
                                  "--renderer", "unused-renderer", "--modules", "unused-modules")
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("outside job", result.stderr)
                self.assertEqual(list(Path(outside).iterdir()), [])
            finally:
                link.unlink()


class PortableLibraryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="aurelia-portable-test-")
        self.addCleanup(self.tmp.cleanup)
        self.fx = SyntheticJob(Path(self.tmp.name))
        self.fx.portable()

    def reject(self, fragment):
        result = gate.validate(self.fx.root, include_review=False)
        self.assertFalse(result["passed"], result)
        self.assertIn(fragment, "\n".join(result["errors"]))

    def test_init_supports_library_without_corpus(self):
        fresh = self.fx.root / "new-offline-job"
        result = subprocess.run([sys.executable, str(SCRIPTS / "deck_gate.py"), "--job", str(fresh),
                                 "init", "--pages", "15", "--library", str(self.fx.library)],
                                capture_output=True, text=True, encoding="utf-8", errors="replace")
        self.assertEqual(result.returncode, 0, result.stderr)
        job = gate.load(fresh / "job.json")
        self.assertIsNone(job["corpus_root"])
        self.assertEqual(job["recipe_library"], gate.bind(self.fx.library))
        self.assertEqual(job["brief"]["slide_count"], 15)

    def test_offline_positive_without_originals(self):
        self.assertFalse(self.fx.corpus.exists())
        result = gate.validate(self.fx.root)
        self.assertTrue(result["passed"], result["errors"])
        released = subprocess.run([sys.executable, str(SCRIPTS / "deck_gate.py"), "--job", str(self.fx.root), "release"],
                                  capture_output=True, text=True, encoding="utf-8", errors="replace")
        self.assertEqual(released.returncode, 0, released.stderr)
        files = list((self.fx.root / "released").glob("*.pptx"))
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0].read_bytes(), self.fx.candidate.read_bytes())

    def test_unknown_recipe_id_rejected(self):
        self.fx.board["options"][0]["design_id"] = "not-in-approved-library"
        self.fx.save_board(reselect=True)
        self.reject("Unknown portable recipe ID")

    def test_modified_bound_library_rejected(self):
        self.fx.recipes[0]["extra"] = "Changed after project binding"
        self.fx.save_library()
        self.reject("Stale artifact: recipes.jsonl")

    def test_unapproved_library_substitution_rejected(self):
        other = self.fx.root / "unapproved-recipes.jsonl"
        other.write_bytes(self.fx.library.read_bytes())
        self.fx.board["options"][0]["reference"] = gate.bind(other)
        self.fx.save_board(reselect=True)
        self.reject("not the approved portable library")

    def test_recipe_id_without_provenance_rejected(self):
        self.fx.recipes[0].pop("source_sha256")
        self.fx.recipes[0].pop("source_page")
        self.fx.save_library(rebind=True)
        self.reject("provenance")

    def test_structural_validation_status_must_be_disclosed(self):
        self.fx.board["options"][0].pop("reference_validation_note")
        self.fx.save_board(reselect=True)
        self.reject("structural-only")

    def test_invalid_provenance_is_not_accepted_as_truthy_text(self):
        valid_hash = self.fx.recipes[0]["source_sha256"]
        for value, page in (("not-a-file-hash", 1), (valid_hash, -1), (valid_hash, 0),
                            (valid_hash, True), (valid_hash, "1")):
            with self.subTest(source_sha256=value, source_page=page):
                self.fx.recipes[0]["source_sha256"] = value
                self.fx.recipes[0]["source_page"] = page
                self.fx.save_library(rebind=True)
                self.reject("provenance")


class InspectorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="aurelia-inspect-test-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_presentation_relationship_order_not_filename_sort(self):
        path = self.root / "order.pptx"; make_deck(path, order=[2, 1])
        info = inspector.inspect(path)
        self.assertIn("page 2", info["slides"][0]["paragraphs"][0])
        self.assertIn("page 1", info["slides"][1]["paragraphs"][0])

    def test_recolor_has_identical_geometry(self):
        a, b = self.root / "a.pptx", self.root / "b.pptx"
        make_deck(a, color="111111"); make_deck(b, color="FFFFFF")
        diff = inspector.compare(a, b)
        self.assertFalse(diff["identical_file"])
        self.assertEqual(diff["same_geometry_pages"], [1, 2])
        self.assertEqual(diff["same_content_pages"], [1, 2])

    def test_relative_geometry_invariant_under_slide_scaling(self):
        a, b = self.root / "a.pptx", self.root / "b.pptx"
        make_deck(a); make_deck(b, scale=2)
        self.assertEqual(inspector.compare(a, b)["same_geometry_pages"], [1, 2])

    def test_duplicate_paragraph_signal(self):
        path = self.root / "duplicate.pptx"; make_deck(path, duplicate=True)
        info = inspector.inspect(path)
        self.assertTrue(any(s["kind"] == "duplicate_paragraph" for s in info["signals"]))

    def test_outside_canvas_signal(self):
        path = self.root / "outside.pptx"; make_deck(path, shifts=(.8, .1))
        self.assertTrue(any(s["kind"] == "outside_canvas" for s in inspector.inspect(path)["signals"]))

    def test_six_repeated_slides_signal(self):
        path = self.root / "repeat.pptx"; make_deck(path, shifts=(.1,)*6)
        self.assertTrue(any(s["id"] == "repetitive-layout" for s in inspector.inspect(path)["signals"]))

    def test_chartex_and_chart_are_native_chart_elements(self):
        for kind in ("chart", "chartEx"):
            with self.subTest(kind=kind):
                path = self.root / f"{kind}.pptx"; make_deck(path, native=kind)
                slide = inspector.inspect(path)["slides"][0]
                self.assertEqual(slide["chart_count"], 1)
                self.assertTrue(any(e["kind"] == "chart" for e in slide["elements"]))


if __name__ == "__main__":
    unittest.main()
