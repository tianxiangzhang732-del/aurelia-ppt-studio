"""Index flattened distilled geometry and explicit adaptation risks; never infer approval."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import statistics
from analyze_corpus import kmeans
from pptx_inspect import sha, write_json
from recipe_io import open_recipe_text


def contained(inner, outer, tolerance=.002):
    x,y,w,h = inner; a,b,c,d = outer
    return x >= a-tolerance and y >= b-tolerance and x+w <= a+c+tolerance and y+h <= b+d+tolerance


def opaque_rect(element):
    fill=element.get('fill') or {}
    color=fill.get('color') or {}
    return ((element.get('geometry') or {}).get('preset') == 'rect' and fill.get('kind') == 'solid'
            and color.get('alpha',color.get('opacity',1)) == 1)


def describe(recipe):
    elements=recipe.get('elements',[])
    texts=[e for e in elements if (e.get('text_capacity') or {}).get('character_count',0)>0]
    kinds=Counter(e['kind'] for e in elements)
    slots=[]; risks=[]; blockers=set(); occupancy=[0.]*12
    sizes=[]; text_area=image_area=0
    background=recipe.get('background') or {}
    if background.get('kind')=='image': blockers.add('new_background_asset_required')
    if background.get('kind')=='gradient' and background.get('angle_degrees') is None:
        blockers.add('path_gradient')
    if recipe.get('source_package_integrity') != 'crc_passed': blockers.add('source_integrity')
    for index,e in enumerate(elements):
        box=e.get('box')
        if not box: blockers.add('missing_geometry'); continue
        x,y,w,h=box; area=max(0,min(1,w*h))
        kind=e['kind']; capacity=(e.get('text_capacity') or {}).get('character_count',0)
        style=e.get('text_style') or {}
        size=style.get('font_size_pt') or 0
        if capacity:
            sizes.append(size); text_area+=area
            # These are frame constraints, not semantic interpretations of deleted source copy.
            form='compact_label' if capacity<=8 else 'paragraph' if capacity>=60 else 'short_copy'
            slots.append({'id':e['id'],'form_hint':form,'source_characters':capacity,'box':box,'font_size_pt':size})
            if size and size<12: risks.append({'kind':'small_reference_text','element':e['id']})
            for later in elements[index+1:]:
                if later.get('box') and opaque_rect(later) and contained(box,later['box']):
                    risks.append({'kind':'text_occluded_by_later_opaque_rect','element':e['id'],'covering_element':later['id']})
                    break
        if kind=='image': image_area+=area; blockers.add('new_image_asset_required')
        if kind not in ('shape','text','connector','image','table','chart'): blockers.add('unsupported_element_kind')
        preset=(e.get('geometry') or {}).get('preset')
        if kind in ('shape','connector','text') and (preset=='custom' or (not preset and kind!='text')): blockers.add('custom_geometry')
        if e.get('rotation_degrees'): blockers.add('rotated_aabb')
        matrix=e.get('group_matrix_emu')
        if matrix and (abs(matrix[1])>1e-8 or abs(matrix[2])>1e-8 or matrix[0]<=0 or matrix[3]<=0):
            blockers.add('rotated_or_mirrored_group')
        for fill in (e.get('fill') or {}, (e.get('line') or {}).get('fill') or {}):
            if 'unresolved_theme_fill_style' in fill: blockers.add('unresolved_theme_fill')
            if fill.get('kind')=='gradient' and fill.get('angle_degrees') is None: blockers.add('path_gradient')
        if kind=='shape' and not capacity and .18<=area<.85 and preset in ('rect','roundRect'):
            content=[c for c in elements if c.get('box') and c['id']!=e['id']
                     and ((c.get('text_capacity') or {}).get('character_count',0)>0 or c['kind'] in ('chart','table','image'))
                     and contained(c['box'],box)]
            if not content: risks.append({'kind':'large_container_without_evidence','element':e['id'],'area_fraction':round(area,3)})
        if w<.95 or h<.95:
            col=max(0,min(3,int((x+w/2)*4))); row=max(0,min(2,int((y+h/2)*3)))
            occupancy[row*4+col]+=min(.5,area)
    features=[math.log1p(len(elements)),math.log1p(len(texts)),math.log1p(kinds['image']),
              math.log1p(kinds['chart']),math.log1p(kinds['table']),math.log1p(kinds['connector']),
              min(2,text_area),min(2,image_area),(statistics.median(sizes) if sizes else 0)/40,
              (max(sizes) if sizes else 0)/72]+occupancy
    total_chars=sum(s['source_characters'] for s in slots)
    return {'design_id':recipe['design_id'],'source_sha256':recipe['source_sha256'],'source_page':recipe['source_page'],
            'fingerprint':recipe.get('layout_summary',{}).get('structure_fingerprint'),
            'kinds':dict(kinds),'text_slot_count':len(slots),'source_character_capacity':total_chars,
            'slots':slots,'risks':risks,'adapter_requirements':sorted(blockers),
            'visual_validation':recipe.get('validation_status','structural_only'),'features':features}


def index(library,output,clusters=18):
    rows=[]
    with open_recipe_text(library) as lines:
        for line in lines: rows.append(describe(json.loads(line)))
    if not rows: raise ValueError('Empty recipe library')
    labels, medoids=kmeans([r['features'] for r in rows],min(clusters,len(rows)))
    groups=[]
    for group,representative,count in medoids:
        groups.append({'id':f'geometry-{group+1:02d}','count':count,'representative':rows[representative]['design_id'],
                       'status':'geometry_only_not_a_style_or_visual_approval'})
    for row,label in zip(rows,labels):
        row['geometry_cluster']=f'geometry-{label+1:02d}'
        del row['features']
    result={'schema':'aurelia-design-index-v1','library_sha256':sha(library),
            'method':'standardized flattened element geometry; deterministic k-means; explicit slot and risk heuristics',
            'scope':'No original copy. Clusters and slot hints are not semantic labels or validated styles.',
            'count':len(rows),'clusters':groups,'designs':rows}
    write_json(output,result)
    print({'designs':len(rows),'clusters':len(groups),'requirements':dict(Counter(x for r in rows for x in r['adapter_requirements'])),
           'review_signals':dict(Counter(x['kind'] for r in rows for x in r['risks']))})
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--library',required=True);p.add_argument('--output',required=True);p.add_argument('--clusters',type=int,default=18)
    a=p.parse_args()
    if a.clusters<2:p.error('Need at least two requested clusters')
    index(a.library,a.output,a.clusters)
