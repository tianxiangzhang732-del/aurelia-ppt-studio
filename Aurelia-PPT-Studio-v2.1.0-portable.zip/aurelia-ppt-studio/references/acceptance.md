# Acceptance and repair

## Two separate gates

Engineering checks sources and board, exact page count, fresh renders, native evidence owners, evidence IDs, visible required terms, current review hashes, and unresolved issues.

Editorial/visual checks require claims that mean what the source means, preserved caveats, complete coverage, selected-style fidelity, readable text, correct chart units/axes, purposeful images, no clipping/collisions, and a non-mechanical narrative.

Engineering success is not design success. The gate requires observations for both but cannot authenticate them. Never claim independent experts when one agent did the passes. Use `agent-self-review` unless another actual reviewer participated.

## Review record

Inspect EVERY full-size slide after rendering. Enter an observation for each covering content, style and readability, bound to its PNG SHA-256. Explicitly complete coverage, factual accuracy, design fidelity and editability checks. Record issues with slide, severity, cause and disposition. Unresolved issues block release. Intentional overlap/repeated layouts need specific dispositions, not blanket waivers.

Inspector signals include duplicated within-slide paragraphs, explicit out-of-bounds geometry, empty content, highly repetitive silhouettes, and unresolved inherited/group geometry. These are review signals, not exact text-overflow detection. The engine's current package/layout validator and visual inspection remain required. Every signal needs a substantive disposition.

After any content/layout edit, rebuild, validate and render again. Retain still-valid source and style decisions only. The review snapshot covers job, builder, candidate, renders, sources and selection. Stale artifacts block delivery even when names match.

## Honest handoff

No automatic 80/100 self-grading. To claim quality comparable to ChatGPT office mode, use identical sources, audience, page count and selected style, then ask the user/a blind reviewer to compare factual coverage, reading clarity, design fidelity, editability and usability. Missing sources, wrong style or unreadable slides fail regardless of total score. This version has not yet passed a comparative benchmark.

For an engine/import issue, diagnose the feature and use a supported correction; do not delete important evidence or repeatedly deliver known-bad files. Ask for a real missing input/permission when needed. Never fabricate passed receipts.
