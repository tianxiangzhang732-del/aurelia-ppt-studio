# Visual choice and layout design

## A usable visual board

Create 6 or 7 numbered options from the permitted corpus. Each has two actual rendered previews: cover and evidence-rich content page. Use the same task content so the user compares design, not unrelated headlines. Supply the underlying PPTX, a short name, source fingerprint/page and intended use. Show preview images in the conversation or an opened preview, not merely file paths. `present_board.py` assembles an HTML contact board from existing previews; it does not generate themes.

Options differ in composition, typography hierarchy, image treatment or graphic vocabulary in addition to color. The checker detects identical explicit OOXML silhouettes across all sample pages, but cannot see pixel-based composition or inherited layouts reliably. Inspect those visually. If the corpus has fewer than six suitable directions, explain and ask for references/permission; do not fill the board with fabricated learned themes.

Capture the user's exact new reply, selected option and board hash. Preference maps to THIS board. Changing a preview invalidates the selection. A new style restarts choice; a spelling correction does not.

## Reference to reusable decisions

Record title/body sizes and contrast, baseline/grid, margin ratios, text-image proportions, alignment, whitespace, separators, chart grammar, photo cropping, and dense/quiet page transitions. Distinguish theme defaults from values actually used. Include counterexamples: which source components do not suit this content.

Native template import is allowed when requested. Do not copy another deck's content, numbers, illustrations or exact sequence as your own work. Derived recipes need inspected source pages and new-content generation tests. Extracted counts/clusters are search aids, not approved styles.

Consult the flattened `design-index.json` before binding content. `compact_label` is a capacity hint, not a conclusion that the slot is a heading; a large numeral does not become a long title. `large_container_without_evidence` and `text_occluded_by_later_opaque_rect` require resolution in the pilot. Do not preserve an empty evidence frame just because it existed in the source. Choose a composition suited to the storyboard, explicitly rebuild that evidence region with native content when appropriate, or reject the recipe. An unsupported feature needs a tested adapter, not a silent deletion or generic fallback.

Use representative original-page observations and new-content tests together. A complete source-design demonstration, a partially repaired label, a negative example and a client-ready slide are different statuses. Keep negative tests; do not present them as successful style samples.

## Variety inside one system

Choose composition after writing the storyboard. Keep the selected palette/fonts consistent but vary the information architecture with the evidence. Do not use title + subtitle + three cards as a universal generator. Repeated tables/process pages can legitimately share a layout; justify repeat-heavy sequences in review. Never change a good repeated design solely to hit a diversity percentage.

For full redesign compare prior output's content and normalized geometry to the new candidate. Name, code hash, theme color or rewritten cover is not proof of redesign. For targeted revision, preserve the design and review the exact change.

Decorative assets use the active presentation skill's supported image workflow and rights rules. Editable charts/tables and requested diagrams remain native. Never flatten evidence pages just to preserve appearance.
