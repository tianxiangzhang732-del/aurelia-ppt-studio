// Read-only conversion audit. Does not create a Presentation or a final PPTX.
// The temporary copy exposes the real internal functions; it does not mock
// the engine or replace conversion logic. Findings are not visual validation.
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = await fs.readFile(path.join(root,'scripts','recipe_renderer.mjs'),'utf8');
const temporary = await fs.mkdtemp(path.join(os.tmpdir(),'aurelia-conversion-audit-'));
try {
  const instrumented = path.join(temporary,'conversion.mjs');
  await fs.writeFile(instrumented, source + '\nexport {color as auditColor,fill as auditFill,moduleFromRuntime as auditRuntime,checkTextFit as auditTextFit,visibleText as auditVisibleText,checkBindings as auditBindings,checkTable as auditTable,checkChart as auditChart};\n');
  const actual = await import(pathToFileURL(instrumented).href);
  const stop = position => ({position,color:{rgb:'112233'}});
  const results = [];
  const linear = actual.auditFill({kind:'gradient',angle_degrees:30,stops:[stop(0),stop(.3),stop(1)]});
  results.push({check:'linear_stop_units',passed:JSON.stringify(linear.stops.map(x=>x.offset))==='[0,30000,100000]',actual:linear});
  for(const [check,input] of [
    ['path_gradient_must_not_silently_become_linear',{kind:'gradient',angle_degrees:null,requires_review:true,stops:[stop(0),stop(1)]}],
    ['unresolved_theme_fill_must_not_silently_become_solid',{kind:'solid',color:{rgb:'112233'},requires_review:true,unresolved_theme_fill_style:2}],
  ]) {
    try { results.push({check,passed:false,actual:actual.auditFill(input),reason:'Unsupported source semantics were accepted and simplified'}); }
    catch(error) { results.push({check,passed:true,rejected_with:error.message}); }
  }
  // Exercise the implementation itself, not a reimplementation of its math.
  // Current checkTextFit throws on failure and returns undefined on success.
  // This helper also records issue-returning implementations if the API evolves.
  const fitCases = [
    {check:'short_chinese_fits',text:'临床证据与产业机会',position:{width:320,height:100},style:{fontSize:24},reject:false},
    {check:'long_chinese_rejected',text:'核心研究结论'.repeat(80),position:{width:240,height:90},style:{fontSize:24},reject:true},
    {check:'newlines_overflow_rejected',text:Array(12).fill('核心要点').join('\n'),position:{width:320,height:90},style:{fontSize:24},reject:true},
    {check:'crlf_overflow_rejected',text:Array(12).fill('核心要点').join('\r\n'),position:{width:320,height:90},style:{fontSize:24},reject:true},
    {check:'zero_insets_are_preserved',text:'一二三四',position:{width:110,height:35},style:{fontSize:24,insets:{left:0,right:0,top:0,bottom:0}},reject:false},
    {check:'default_insets_reduce_capacity',text:'一二三四',position:{width:110,height:35},style:{fontSize:24},reject:true},
    {check:'no_usable_frame_rejected',text:'核心',position:{width:10,height:90},style:{fontSize:24},reject:true},
  ];
  for (const test of fitCases) {
    const before=JSON.stringify({position:test.position,style:test.style});
    let rejected=false, detail;
    try {
      const value=actual.auditTextFit(test.text,test.position,test.style,test.check);
      rejected=Array.isArray(value)?value.length>0:!!(value?.issues?.length || value?.passed===false);
      detail=value;
    } catch(error) { rejected=true;detail=error.message; }
    results.push({check:test.check,passed:rejected===test.reject,
      expected:test.reject?'reject':'allow',actual:rejected?'reject':'allow',detail});
    results.push({check:`${test.check}_does_not_shrink_or_mutate`,passed:before===JSON.stringify({position:test.position,style:test.style})});
  }
  for(const [check,value,expected] of [
    ['visible_chinese_allowed','核心结论',true],['visible_number_string_allowed','42',true],
    ['emoji_symbol_allowed','📊',true],['empty_text_rejected','',false],
    ['whitespace_only_rejected',' \n\t',false],['zero_width_only_rejected','\u200b\u200c\u200d',false],
    ['non_string_rejected',{},false],
  ]) results.push({check,passed:actual.auditVisibleText(value)===expected});
  const prototype={design_id:'fixture',elements:[{id:'e1',kind:'text',text_capacity:{character_count:0}},{id:'e2',kind:'shape'}]};
  const page=changes=>({design_id:'fixture',bindings:{e1:'新标题'},required_slots:['e1'],...changes});
  const validChart=changes=>({chart_kind:'bar',categories:['A','B'],series:[{name:'数量',values:[1,2]}],...changes});
  const validationCases=[
    ['known_binding_allowed',()=>actual.auditBindings(prototype,page()),false],
    ['unknown_binding_rejected',()=>actual.auditBindings(prototype,page({bindings:{eTYPO:'新内容'}})),true],
    ['required_slot_missing_rejected',()=>actual.auditBindings(prototype,page({bindings:{}})),true],
    ['required_slot_unknown_rejected',()=>actual.auditBindings(prototype,page({required_slots:['eTYPO']})),true],
    ['bindings_array_rejected',()=>actual.auditBindings(prototype,page({bindings:[]})),true],
    ['required_null_binding_rejected',()=>actual.auditBindings(prototype,page({bindings:{e1:null}})),true],
    ['required_empty_object_binding_rejected',()=>actual.auditBindings(prototype,page({bindings:{e1:{}}})),true],
    ['valid_table_allowed',()=>actual.auditTable({values:[['类别','值'],['A',1],['B',0]]},'valid'),false],
    ['empty_table_rejected',()=>actual.auditTable({values:[]},'empty'),true],
    ['zero_column_table_rejected',()=>actual.auditTable({values:[[]]},'zero-columns'),true],
    ['ragged_table_rejected',()=>actual.auditTable({values:[[1,2],[3]]},'ragged'),true],
    ['object_cell_rejected',()=>actual.auditTable({values:[[{}]]},'object'),true],
    ['null_cell_rejected',()=>actual.auditTable({values:[[null]]},'null'),true],
    ['nan_cell_rejected',()=>actual.auditTable({values:[[NaN]]},'nan'),true],
    ['infinite_cell_rejected',()=>actual.auditTable({values:[[Infinity]]},'infinite'),true],
    ['invisible_table_rejected',()=>actual.auditTable({values:[['\u200b',' ']]},'invisible'),true],
    ['valid_chart_allowed',()=>actual.auditChart(validChart(), 'valid'),false],
    ['mismatched_series_length_rejected',()=>actual.auditChart(validChart({series:[{name:'数量',values:[1]}]}),'length'),true],
    ['nan_chart_value_rejected',()=>actual.auditChart(validChart({series:[{name:'数量',values:[1,NaN]}]}),'nan'),true],
    ['infinite_chart_value_rejected',()=>actual.auditChart(validChart({series:[{name:'数量',values:[1,Infinity]}]}),'infinite'),true],
    ['empty_series_name_rejected',()=>actual.auditChart(validChart({series:[{name:' ',values:[1,2]}]}),'name'),true],
    ['zero_width_series_name_rejected',()=>actual.auditChart(validChart({series:[{name:'\u200b',values:[1,2]}]}),'name'),true],
    ['empty_categories_rejected',()=>actual.auditChart(validChart({categories:[]}),'categories'),true],
    ['empty_category_name_rejected',()=>actual.auditChart(validChart({categories:['A','\u200b']}),'category'),true],
    ['missing_series_values_rejected',()=>actual.auditChart(validChart({series:[{name:'数量'}]}),'values'),true],
  ];
  for(const [check,execute,expectedReject] of validationCases) {
    let rejected=false,detail;
    try {execute();} catch(error) {rejected=true;detail=error.message;}
    results.push({check,passed:rejected===expectedReject,expected:expectedReject?'reject':'allow',actual:rejected?'reject':'allow',detail});
  }
  if(process.env.RUNTIME_NODE_MODULES) {
    const engine=await actual.auditRuntime();
    results.push({check:'actual_runtime_entrypoint_exports',passed:!!engine.Presentation&&!!engine.PresentationFile});
  }
  console.log(JSON.stringify({scope:'conversion_logic_only_no_deck_created',checks:results.length,
    passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).map(r=>r.check),results},null,2));
  process.exitCode=results.every(r=>r.passed)?0:1;
} finally {
  // Only the explicitly created one-file scratch directory is removed.
  await fs.unlink(path.join(temporary,'conversion.mjs')).catch(()=>{});
  await fs.rmdir(temporary);
}
