"""Independent structural-index/finder tests; no visual or semantic approval."""
from __future__ import annotations

from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import distill_designs
import find_designs
import index_designs


def element(identifier="text", kind="text", characters=20, box=None, geometry="textbox"):
    return {"id":identifier,"kind":kind,"origin":"slide","box":box or [.1,.1,.35,.18],
            "geometry":{"preset":geometry} if geometry is not None else None,
            "fill":{"kind":"none"},"line":None,"requires_asset":False,
            "text_capacity":{"character_count":characters,"paragraph_count":1},
            "text_style":{"font_size_pt":18},"rotation_degrees":0}


def recipe(identifier="recipe-a", x=.1, characters=20, color="FFFFFF"):
    # All descriptors are synthetic. Fingerprints come from actual coordinates,
    # never hand-assigned test labels that would make distinctness tests vacuous.
    elements=[element("background","shape",0,[0,0,1,1],"rect"),
              element("text","text",characters,[x,.1,.35,.18]),
              element("decoration","text",0,[.8,.8,.1,.1],"rect")]
    elements[0]["fill"]={"kind":"solid","color":{"rgb":color}}
    return {"design_id":identifier,"source_sha256":"a"*64,"source_page":1,
            "canvas":{"width_emu":12192000,"height_emu":6858000},
            "source_package_integrity":"crc_passed","validation_status":"structural_only",
            "background":{"kind":"solid","color":{"rgb":color}},"elements":elements,
            "layout_summary":distill_designs.layout_summary(elements)}


class IndexDesignTests(unittest.TestCase):
    def test_geometry_none_is_safe_and_requires_adapter_for_shape(self):
        r=recipe(); r["elements"][0]["geometry"]=None
        row=index_designs.describe(r)
        self.assertIn("custom_geometry",row["adapter_requirements"])
        self.assertFalse(index_designs.opaque_rect(r["elements"][0]))

    def test_textbox_without_explicit_geometry_is_supported(self):
        r=recipe();r["elements"][1]["geometry"]=None
        self.assertEqual(index_designs.describe(r)["text_slot_count"],1)

    def test_decorative_empty_text_frame_not_a_content_slot(self):
        r=recipe();r["elements"][2]["role"]="headline"
        row=index_designs.describe(r)
        self.assertEqual(row["text_slot_count"],1)
        self.assertEqual([s["id"] for s in row["slots"]],["text"])
        self.assertEqual(row["source_character_capacity"],20)

    def test_later_opaque_rect_covering_text_is_signalled(self):
        r=recipe()
        cover=element("cover","shape",0,[.08,.08,.40,.23],"rect")
        cover["fill"]={"kind":"solid","color":{"rgb":"FFFFFF","opacity":1}}
        r["elements"].append(cover)
        signals=index_designs.describe(r)["risks"]
        self.assertIn({"kind":"text_occluded_by_later_opaque_rect","element":"text","covering_element":"cover"},signals)

    def test_translucent_rect_not_reported_as_opaque_occlusion(self):
        r=recipe()
        cover=element("cover","shape",0,[.08,.08,.40,.23],"rect")
        cover["fill"]={"kind":"solid","color":{"rgb":"FFFFFF","opacity":.4}}
        r["elements"].append(cover)
        self.assertFalse(any(s["kind"]=="text_occluded_by_later_opaque_rect" for s in index_designs.describe(r)["risks"]))

    def test_background_behind_text_does_not_occlude_it(self):
        self.assertFalse(any(s["kind"]=="text_occluded_by_later_opaque_rect" for s in index_designs.describe(recipe())["risks"]))

    def test_unverified_semantic_role_does_not_become_approval(self):
        r=recipe();r["elements"][1]["role"]="verified_clinical_conclusion"
        r["role"]="executive_summary";r["approved"]=True
        row=index_designs.describe(r)
        self.assertEqual(row["visual_validation"],"structural_only")
        self.assertNotIn("approved",row)
        self.assertEqual(row["slots"][0]["form_hint"],"short_copy")
        self.assertNotIn("role",row["slots"][0])

    def test_crc_failure_is_an_explicit_requirement(self):
        r=recipe();r["source_package_integrity"]="crc_failed"
        self.assertIn("source_integrity",index_designs.describe(r)["adapter_requirements"])


class FinderTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix="aurelia-index-test-")
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.library=self.root/"recipes.jsonl"

    def write(self,rows):
        self.library.write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding="utf-8")

    def test_crc_failed_sources_are_excluded(self):
        bad=recipe("bad");bad["source_package_integrity"]="crc_failed"
        self.write([bad,recipe("good")])
        self.assertEqual([r["design_id"] for r in find_designs.search(self.library)],["good"])

    def test_explicit_id_with_adapter_ready_cannot_bypass_crc_filter(self):
        bad=recipe("bad");bad["source_package_integrity"]="crc_failed"
        self.write([bad])
        self.assertEqual(find_designs.search(self.library,design_id="bad",adapter_ready=True),[])

    def test_same_geometry_recolor_excluded_but_different_geometry_kept(self):
        self.write([recipe("a",color="FFFFFF"),recipe("recolor",color="001122"),recipe("different",x=.6)])
        hits=find_designs.search(self.library,distinct=True)
        self.assertEqual([r["design_id"] for r in hits],["a","different"])
        self.assertEqual(len(find_designs.search(self.library,distinct=False)),3)

    def test_minimum_capacity_measures_real_nonempty_text_slots(self):
        self.write([recipe("empty",characters=0),recipe("short",characters=8),recipe("long",characters=80)])
        hits=find_designs.search(self.library,min_characters=30)
        self.assertEqual([r["design_id"] for r in hits],["long"])
        self.assertEqual(hits[0]["text_slot_count"],1)

    def test_adapter_ready_excludes_missing_geometry(self):
        bad=recipe("bad");bad["elements"][1]["box"]=None
        self.write([bad,recipe("good")])
        self.assertEqual([r["design_id"] for r in find_designs.search(self.library,adapter_ready=True)],["good"])

    def test_adapter_ready_excludes_custom_text_geometry(self):
        bad=recipe("custom");bad["elements"][1]["geometry"]={"preset":"custom"}
        self.write([bad])
        self.assertEqual(find_designs.search(self.library,adapter_ready=True),[])

    def test_ready_does_not_mean_visual_approval_or_erase_risk(self):
        r=recipe();r["elements"][1]["text_style"]["font_size_pt"]=10
        self.write([r])
        hit=find_designs.search(self.library,adapter_ready=True)[0]
        self.assertEqual(hit["validation_status"],"structural_only")
        self.assertTrue(any(s["kind"]=="small_reference_text" for s in hit["review_signals"]))
        self.assertNotIn("approved",hit)

    def test_index_keeps_cluster_and_semantic_validation_separate(self):
        self.write([recipe("a",x=.05),recipe("b",x=.6),recipe("c",characters=80)])
        with redirect_stdout(io.StringIO()):
            result=index_designs.index(self.library,self.root/"index.json",clusters=2)
        self.assertEqual(result["count"],3)
        self.assertTrue(all(g["status"]=="geometry_only_not_a_style_or_visual_approval" for g in result["clusters"]))
        self.assertTrue(all(r["visual_validation"]=="structural_only" for r in result["designs"]))
        self.assertEqual(json.loads((self.root/"index.json").read_text(encoding="utf-8"))["library_sha256"],result["library_sha256"])

    def test_finder_cli_combines_filters(self):
        self.write([recipe("a",characters=8),recipe("b",characters=80,x=.6)])
        run=subprocess.run([sys.executable,str(SCRIPTS/"find_designs.py"),"--library",str(self.library),
                            "--distinct","--adapter-ready","--min-characters","60"],capture_output=True,text=True,encoding="utf-8")
        self.assertEqual(run.returncode,0,run.stderr)
        self.assertEqual([r["design_id"] for r in json.loads(run.stdout)],["b"])


if __name__=="__main__":
    unittest.main()
