"""Assemble existing cover/content renders into a visual chooser. No theme generation."""
import argparse
import base64
import html
from pathlib import Path
from deck_gate import load, check_board, local, bind
from pptx_inspect import write_json


def build(root):
    root = Path(root).resolve()
    board = check_board(root, load(root / 'job.json'))
    rows = []
    for option in board['options']:
        manifest = load(option['render']['path'])
        imgs = []
        for page in manifest['slides'][:2]:
            data = base64.b64encode(Path(page['path']).read_bytes()).decode('ascii')
            imgs.append(f'<img alt="{html.escape(str(option["name"]))} 第 {page["slide"]} 页" src="data:image/png;base64,{data}">')
        rows.append(f'<section><h2>{html.escape(str(option["id"]))} · {html.escape(option["name"])}</h2>'
                    f'<div class="pair">{"".join(imgs)}</div><p>{html.escape(option["design_notes"])}</p></section>')
    output = local(root, 'style-board.html')
    output.write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>PPT 风格选择</title>'
        '<style>body{font-family:system-ui,sans-serif;background:#f0f0f0;color:#202020;margin:32px auto;max-width:1500px;padding:0 24px}'
        'section{background:white;margin:26px 0;padding:22px}h2{margin:0 0 16px;font-size:23px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:14px}'
        'img{width:100%;border:1px solid #ddd}p{font-size:16px;line-height:1.5}@media(max-width:850px){.pair{grid-template-columns:1fr}}</style>'
        '<h1>请选择 PPT 视觉方向</h1><p>每种方向展示封面和内容页。请回到对话回复编号，或描述需要调整的地方。</p>'
        + ''.join(rows) + '</html>', encoding='utf-8')
    write_json(root / 'style-board-display.json', bind(output))
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', required=True)
    build(parser.parse_args().job)
