"""Stream UTF-8 recipe data from plain JSONL or gzip without unpacking files.

Artifact hashes must still be computed from the original stored path, not this
decoded stream, so evidence bindings identify the exact distributed bytes.
"""
import gzip
from pathlib import Path


def open_recipe_text(path):
    path = Path(path)
    if path.suffix.lower() == '.gz':
        return gzip.open(path, 'rt', encoding='utf-8')
    return path.open(encoding='utf-8')
