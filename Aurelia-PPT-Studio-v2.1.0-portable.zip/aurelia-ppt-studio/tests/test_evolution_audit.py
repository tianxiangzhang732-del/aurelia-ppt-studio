"""Adversarial fixture-lab regressions; these are not production learning cases."""
import copy
import unittest

import test_evolution as fixtures

evo = fixtures.evo
gate = fixtures.gate


class EvolutionAuditTests(unittest.TestCase):
    released_case = fixtures.EvolutionTests.released_case
    two = fixtures.EvolutionTests.two

    def setUp(self):
        fixtures.EvolutionTests.setUp(self)
        # The fixture has one approximately 32-character paragraph at 24 pt.
        self.rule['parameters'] = {'max_characters': 80, 'min_font_size_pt': 12}

    def test_text_only_releases_do_not_support_chart_owner_rule(self):
        first, second = self.two()
        for specimen in (first, second):
            self.assertTrue(all(slide['chart_count'] == 0
                                for slide in evo.inspect(specimen.candidate)['slides']))
        rule = {'id': 'native-chart', 'kind': 'evidence_owner',
                'layout_family': 'family-1', 'parameters': {'required_kind': 'chart'}}
        with self.assertRaises(gate.GateError):
            evo.promote(self.state, rule, ['case-a', 'case-b'])

    def test_over_capacity_text_cannot_support_capacity_rule(self):
        self.two()
        self.rule['parameters']['max_characters'] = 24
        with self.assertRaises(gate.GateError):
            evo.promote(self.state, self.rule, ['case-a', 'case-b'])

    def test_undersized_text_cannot_support_font_floor_rule(self):
        self.two()
        self.rule['parameters']['min_font_size_pt'] = 30
        with self.assertRaises(gate.GateError):
            evo.promote(self.state, self.rule, ['case-a', 'case-b'])

    def test_generic_case_observation_is_not_explicit_review_evidence(self):
        for name, variant in (('case-a', 'alpha'), ('case-b', 'beta')):
            _, case = self.released_case(name, variant)
            case.pop('rule_checks', None)
            evo.record(self.state, case)
        rule = {'id': 'table-review', 'kind': 'review_focus',
                'layout_family': 'family-1', 'parameters': {'checks': ['table_inheritance']}}
        with self.assertRaises(gate.GateError):
            evo.promote(self.state, rule, ['case-a', 'case-b'])

    def test_stale_newer_evidence_does_not_block_valid_older_rollback(self):
        self.two()
        older = evo.promote(self.state, self.rule, ['case-a', 'case-b'])['active_version']
        third, case_c = self.released_case('case-c', 'gamma')
        _, case_d = self.released_case('case-d', 'delta')
        evo.record(self.state, case_c)
        evo.record(self.state, case_d)
        revised = copy.deepcopy(self.rule)
        revised['parameters']['max_characters'] = 72
        newer = evo.promote(self.state, revised, ['case-c', 'case-d'])['active_version']
        third.source.write_text('Changed synthetic source to test evidence drift.', encoding='utf-8')
        evo.verify_version(self.state, older)
        with self.assertRaises(gate.GateError):
            evo.verify_version(self.state, newer)
        result = evo.activate(self.state, older, 'Restore the independently verified earlier rule version')
        self.assertEqual(result['active_version'], older)
        active = evo.status(self.state)['active']
        self.assertEqual(active[0]['version_id'], older)
        self.assertTrue((self.state / 'versions' / f'{newer}.json').is_file())

    def test_recomputed_version_hash_cannot_bypass_case_cardinality(self):
        self.two()
        version = evo.promote(self.state, self.rule, ['case-a', 'case-b'])['active_version']
        path = self.state / 'versions' / f'{version}.json'
        original = gate.load(path)
        for count in (0, 1):
            with self.subTest(case_count=count):
                invalid = copy.deepcopy(original)
                invalid['body']['cases'] = invalid['body']['cases'][:count]
                invalid['sha256'] = evo.digest(invalid['body'])
                gate.write_json(path, invalid)
                with self.assertRaises(gate.GateError):
                    evo.verify_version(self.state, version)

    def test_recomputed_version_hash_cannot_duplicate_one_supporting_case(self):
        self.two()
        version = evo.promote(self.state, self.rule, ['case-a', 'case-b'])['active_version']
        path = self.state / 'versions' / f'{version}.json'
        invalid = gate.load(path)
        invalid['body']['cases'] = [invalid['body']['cases'][0]] * 2
        invalid['sha256'] = evo.digest(invalid['body'])
        gate.write_json(path, invalid)
        with self.assertRaises(gate.GateError):
            evo.verify_version(self.state, version)

    def test_activation_rejects_corrupt_unaffected_rule_pointer(self):
        self.two()
        evo.promote(self.state, self.rule, ['case-a', 'case-b'])
        other_rule = copy.deepcopy(self.rule)
        other_rule['id'] = 'other-capacity'
        other = evo.promote(self.state, other_rule, ['case-a', 'case-b'])['active_version']
        path = self.state / 'active.json'
        original = gate.load(path)
        for corruption in ('hash', 'rule-id'):
            with self.subTest(corruption=corruption):
                invalid = copy.deepcopy(original)
                if corruption == 'hash':
                    invalid['rules'][self.rule['id']]['version_sha256'] = '0' * 64
                else:
                    invalid['rules']['incorrect-rule-id'] = invalid['rules'].pop(self.rule['id'])
                gate.write_json(path, invalid)
                with self.assertRaises(gate.GateError):
                    evo.activate(self.state, other, 'Revalidate without silently retaining corrupt pointers')


if __name__ == '__main__':
    unittest.main()
