# Runtime and CLI

## Dependencies and production engine

Core inspector/gate/analyzer: Python 3.10+, standard library. Generation/rendering: host-provided `@oai/artifact-tool` and its Node runtime. Discover them using `load_workspace_dependencies` in Codex. Do not install substitutes, modify bundled code or call a different desktop LibreOffice to work around a failure. Other hosts must supply a compatible engine and adapter; this package does not redistribute it.

Before writing a deck in Codex read the current Presentations skill, its implementation/API quick start and finalization instructions. Run its operation-start marker once as required. Do not copy its example style. Use a candidate path inside the job. Let the native finalizer produce an internal engine-validated candidate and receipt. Its internal `finalPath` is NOT the user-facing release path. Aurelia's gate still needs source/design/render/visual checks before public handoff.

`recipe_renderer.mjs` is a template-free geometry adapter for distilled recipes. It accepts new content bindings and rejects unsupported visual primitives or missing assets instead of silently substituting a generic theme. It produces a draft and implementation receipt, not a passed delivery receipt. A structural recipe needs a preview/pilot comparison before use; this adapter alone cannot establish aesthetics.

## Job commands

Use an absolute job path. Paths under the job are resolved safely. Replace `PYTHON`, `SKILL`, `JOB` and runtime values with actual paths; these are notation, not literal shell variables.

```text
PYTHON SKILL/scripts/deck_gate.py --job JOB init --pages 15 --corpus CORPUS
PYTHON SKILL/scripts/deck_gate.py --job JOB init --pages 15 --library SKILL/design-library/recipes.jsonl.gz
PYTHON SKILL/scripts/deck_gate.py --job JOB add-source --id report --file SOURCE --pages 10
PYTHON SKILL/scripts/pptx_inspect.py DECK --output INSPECTION.json
PYTHON SKILL/scripts/pptx_inspect.py NEW --compare-to OLD --output DIFFERENCES.json
```

Edit `job.json` to fill the brief, evidence, topic map and storyboard before creating the final deck. Do not import old ledger text. Source page counts come from the actual full extraction. Example fields (illustrative schema, not source facts):

```json
{
  "evidence": [{"id":"e01","source_id":"report","page":2,"locator":"Table 1, row 3","claim":"Exact source finding","kind":"fact","caveats":["source qualification"]}],
  "required_topics": [{"topic":"Limitations","slides":[14]}],
  "storyboard": [{"slide":1,"title":"Actual subject","purpose":"explanation","body":"Detailed audience-facing content","evidence_ids":["e01"],"layout_family":"comparison","visual_owner":"table","required_terms":["Exact source finding"],"notes":"report:p2; Table 1, row 3","caveats":[]}]
}
```

For all pages maintain exact sequence. Notes in the actual PPT use the `source_id:pN` locator plus a readable citation. Put audience-important caveats on slides too. `visual_owner` may be `text`, `table`, `chart`, `diagram`, or `image`; native owners are verified mechanically.

## Board, selection and pilot

Render each 2+ page style sample with `render` (without `--attach`). This is allowed before final style approval because samples are the means of choosing. It creates a fresh directory and `render.json`.

```text
PYTHON SKILL/scripts/deck_gate.py --job JOB render --deck sample-1.pptx --node NODE --renderer RENDERER_MJS --modules NODE_MODULES
```

Write `board.json`: `design_round` equals the job's; `options` has 6 or 7 entries. Each entry has `id`, `name`, `design_notes`, `reference_pages` (actual reference page numbers), and `reference`, `sample`, `render` records. Every record has absolute `path` and SHA-256 `sha256`. Reference is from the authorized corpus; sample is a genuinely different draft with this task's content; render points at its generated manifest. Inspect samples and display the resulting chooser:

For a portable-library job, `reference` instead binds the approved `recipes.jsonl.gz` (plain JSONL is also supported). Supply `design_id` and a truthful `reference_validation_note`; the gate verifies recipe provenance. No access to the original Desktop folder is needed. All visual options still need actual samples, renders, inspection and user choice. Structural-only recipes do not imply pixel-perfect reconstruction of original images.

```text
PYTHON SKILL/scripts/present_board.py --job JOB
```

Open `style-board.html` for the user. Ask for their choice and pause full production. ONLY after the actual reply:

```text
PYTHON SKILL/scripts/deck_gate.py --job JOB select --option 3 --quote ACTUAL_USER_REPLY --shown
```

Add `design_tokens`: selected `option` string, `fonts`, `palette`, `layout_vocabulary`, and `pilot_review` with selected sample's `render_sha256` and a specific `observation`. Inspect the selected dense page and any additional pilot page needed before building all pages.

## Bind, render, review and release

```text
PYTHON SKILL/scripts/deck_gate.py --job JOB bind --candidate build/validated.pptx --builder build/build.mjs --receipt build/engine-validation.json
PYTHON SKILL/scripts/deck_gate.py --job JOB render --deck build/validated.pptx --node NODE --renderer RENDERER_MJS --modules NODE_MODULES --attach
PYTHON SKILL/scripts/deck_gate.py --job JOB prepare-review
PYTHON SKILL/scripts/deck_gate.py --job JOB validate
PYTHON SKILL/scripts/deck_gate.py --job JOB release
```

Renderer path is the current Presentations `container_tools/render_presentation.mjs`. Review preparation creates blanks and false values, never automatic passes. Inspect every full-size page; fill specific content/style/readability observations and resolve inspector signals. Repeat render after changes. Preserve the prior review before generating a new one. Successful release writes `released/deck-HASH.pptx` exclusively, with a bound receipt. Existing releases are never overwritten. No command can certify semantic accuracy, authentic human approval or independent review.

## Corpus analysis and test

```text
PYTHON SKILL/scripts/analyze_corpus.py --corpus CORPUS --output PRIVATE_OUTPUT --clusters 18
PYTHON SKILL/scripts/distill_designs.py CORPUS --output NEW_PRIVATE_OUTPUT
PYTHON SKILL/scripts/index_designs.py --library SKILL/design-library/recipes.jsonl.gz --output SKILL/design-library/design-index.json --clusters 18
PYTHON SKILL/scripts/find_designs.py --library SKILL/design-library/recipes.jsonl.gz --kind chart --tone light --limit 7
PYTHON SKILL/scripts/find_designs.py --library SKILL/design-library/recipes.jsonl.gz --distinct --adapter-ready --min-characters 100 --limit 7
PYTHON SKILL/scripts/find_designs.py --library SKILL/design-library/recipes.jsonl.gz --design-id ACTUAL_DESIGN_ID
PYTHON -m unittest discover -s SKILL/tests -v
```

Keep private corpus indexes outside published skill packages. Core scripts contain no Desktop fallback. A new design round needs new visual approval; a targeted edit can retain its same-board selection but all changed candidate/review hashes must be refreshed.

## Recipe adapter input

Run Node with `RUNTIME_NODE_MODULES` set to the discovered runtime directory:

```text
NODE SKILL/scripts/recipe_renderer.mjs --library SKILL/design-library/recipes.jsonl.gz --request bindings.json --output NEW_BUILD_DIRECTORY
```

`bindings.json` has `schema: "aurelia-build-v1"`, `purpose: "draft"` or `"validation"`, and `pages`. Each page has `design_id`, `bindings` keyed by actual element ID, and `notes`. Text binding is a new string or `{ "text": "..." }`; image binding is `{ "asset": "new-image.png", "content_type": "image/png", "alt": "..." }`. Use actual new evidence for tables/charts, never source placeholder values. `font_substitutions` records explicit tested substitutions by source font name.

Declare `required_slots` for the content-bearing elements in each page plan. Unknown binding IDs and missing declared slots are errors, not ignored copy. A native table binding is `{ "values": [["Category","Value"],["New datum",12]] }`. A chart binding uses `chart_kind`, `categories` and `series` such as `[{ "name":"New series", "values":[12,18] }]`; values must match category count and be finite numbers. Set `options` using the current engine chart API, including suitable series colors, axes/units and legends. These miniature examples explain schema, not a default visual style or a factual dataset.

Do not assign content by font size alone. A source's largest text may be a narrow numeral, page label or KPI. Read geometry and source-role observations, bind short labels to short slots, then check full-size previews. A large empty source frame needs useful new content or a different recipe; do not call the empty frame a completed evidence slide. The adapter conservatively rejects obvious text overflow, unresolved fills, rotated AABBs and missing assets. These checks are not an exact font-metrics engine.

The adapter supports common native shapes/text, supplied images and explicitly bound tables/charts. Table schema v2 retains per-cell explicit/resolved fills, fonts, borders, margins, source row/column ratios and merge regions. Missing built-in style definitions remain warnings. New table dimensions require an explicit adapted recipe. It does not guarantee preservation of mixed run styles, complex effects, all merged-cell edge cases, custom paths, animations or extended chart types. Implement and test a feature-specific adapter when needed rather than silently simplifying it. Generated build receipts remain `draft-not-delivered` until the full gate passes.

For a relocation/generation test, `examples/native-table-probe.json` contains explicitly fictional project data bound to two actual permitted designs. It is not an approved client style or a default deck. Run it against the packaged full recipe library; original source PPTs are unnecessary. Inspect the resulting two pages and native objects; a build receipt still does not substitute for production release.
