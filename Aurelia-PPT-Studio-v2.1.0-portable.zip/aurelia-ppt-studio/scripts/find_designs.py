"""Search the packaged recipe library by actual structure, without original PPT access."""
import argparse
from collections import Counter
import json
from pathlib import Path
from index_designs import describe
from recipe_io import open_recipe_text


def search(library, kind=None, tone=None, asset_free=False, limit=7, min_elements=3, max_elements=100,
           distinct=False, adapter_ready=False, min_characters=0, design_id=None):
    hits=[]; seen=set()
    with open_recipe_text(library) as lines:
        for line in lines:
            recipe=json.loads(line)
            if design_id and recipe['design_id']!=design_id:continue
            if recipe.get('source_package_integrity') not in (None,'crc_passed'):
                continue
            elements=recipe['elements']; kinds=Counter(e['kind'] for e in elements)
            if not design_id and not min_elements<=len(elements)<=max_elements: continue
            if kind and not kinds[kind]: continue
            if asset_free and (any(e.get('requires_asset') for e in elements) or recipe['background']['kind']=='image'):continue
            rgb=(recipe.get('background',{}).get('color') or {}).get('rgb')
            lum=sum(int(rgb[i:i+2],16)*w for i,w in zip((0,2,4),(.2126,.7152,.0722))) if rgb else None
            if tone and (lum is None or (tone=='dark' and lum>100) or (tone=='light' and lum<180)):continue
            profile=describe(recipe)
            if profile['source_character_capacity']<min_characters:continue
            if adapter_ready and profile['adapter_requirements']:continue
            if design_id:return [recipe]
            fingerprint=profile['fingerprint'] or recipe['design_id']
            if distinct and fingerprint in seen:continue
            seen.add(fingerprint)
            hits.append({'design_id':recipe['design_id'],'background':recipe['background'],'kinds':dict(kinds),
                         'layout_summary':recipe['layout_summary'],'validation_status':recipe['validation_status'],
                         'requires_assets':sum(bool(e.get('requires_asset')) for e in elements),
                         'text_slot_count':profile['text_slot_count'],'source_character_capacity':profile['source_character_capacity'],
                         'adapter_requirements':profile['adapter_requirements'],'review_signals':profile['risks']})
            if len(hits)>=limit:break
    return hits


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--library',required=True);p.add_argument('--kind',choices=['text','shape','chart','table','image','connector'])
    p.add_argument('--tone',choices=['light','dark']);p.add_argument('--asset-free',action='store_true')
    p.add_argument('--limit',type=int,default=7);p.add_argument('--min-elements',type=int,default=3);p.add_argument('--max-elements',type=int,default=100)
    p.add_argument('--distinct',action='store_true',help='Exclude identical normalized geometry, not proof of visual variety')
    p.add_argument('--adapter-ready',action='store_true',help='Exclude known geometry/asset requirements; still requires render review')
    p.add_argument('--min-characters',type=int,default=0,help='Minimum source text-slot capacity; not a content-quality measure')
    p.add_argument('--design-id',help='Return one full recipe for deliberate slot binding')
    a=p.parse_args()
    if a.limit<1:p.error('limit must be positive')
    print(json.dumps(search(a.library,a.kind,a.tone,a.asset_free,a.limit,a.min_elements,a.max_elements,
                            a.distinct,a.adapter_ready,a.min_characters,a.design_id),ensure_ascii=False,indent=2))
