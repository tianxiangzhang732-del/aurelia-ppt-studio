"""Cell-level native table extraction tests. No aesthetic or application claims."""
import importlib.util
import json
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

spec=importlib.util.spec_from_file_location('distill_designs',Path(__file__).parents[1]/'scripts'/'distill_designs.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
NS='xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
SID='{12345678-1234-1234-1234-123456789012}'


class Pkg:
    def __init__(self,styles=None): self.styles=ET.fromstring(styles) if styles else None
    def related(self,part,suffix): return None
    def xml(self,part): return self.styles


def cell(text='PRIVATE CELL',attrs='',props='',rprops=''):
    return '<a:tc '+attrs+'><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr/><a:r><a:rPr '+rprops+'/>'+'<a:t>'+text+'</a:t></a:r></a:p></a:txBody><a:tcPr '+props+'/></a:tc>'


def table(cells,props=''):
    return ET.fromstring('<a:tbl '+NS+'><a:tblPr '+props+'><a:tableStyleId>'+SID+'</a:tableStyleId></a:tblPr><a:tblGrid><a:gridCol w="400000"/><a:gridCol w="600000"/></a:tblGrid>'+''.join('<a:tr h="200000">'+row+'</a:tr>' for row in cells)+'</a:tbl>')


class TableStyleTests(unittest.TestCase):
    def setUp(self):
        self.presentation=ET.fromstring('<p:presentation '+NS+'><p:defaultTextStyle><a:lvl1pPr><a:defRPr sz="1800"><a:latin typeface="Arial"/><a:ea typeface="Microsoft YaHei"/></a:defRPr></a:lvl1pPr></p:defaultTextStyle></p:presentation>')
        self.theme=d.Theme(None,{'tx1':'dk1'})
        self.theme.colors={'dk1':'202020','lt1':'FFFFFF','accent1':'2255AA','accent2':'CC5533'}
        self.theme.fonts={'minor:latin':'Arial','minor:ea':'Microsoft YaHei'}

    def styles(self,parts):
        return '<a:tblStyleLst '+NS+' def="'+SID+'"><a:tblStyle styleId="'+SID+'" styleName="PRIVATE CLIENT STYLE">'+parts+'</a:tblStyle></a:tblStyleLst>'

    def test_custom_style_theme_fill_font_and_conditional_header(self):
        styles=self.styles('<a:wholeTbl><a:tcTxStyle><a:fontRef idx="minor"/><a:schemeClr val="dk1"/></a:tcTxStyle><a:tcStyle><a:fill><a:solidFill><a:schemeClr val="lt1"/></a:solidFill></a:fill><a:tcBdr><a:insideH><a:ln w="12700"><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:ln></a:insideH></a:tcBdr></a:tcStyle></a:wholeTbl><a:firstRow><a:tcTxStyle b="on"><a:schemeClr val="lt1"/></a:tcTxStyle><a:tcStyle><a:fill><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:fill><a:tcBdr><a:bottom><a:ln w="38100"><a:solidFill><a:schemeClr val="accent2"/></a:solidFill></a:ln></a:bottom></a:tcBdr></a:tcStyle></a:firstRow>')
        r=d.distill_table(table([cell()+cell(),cell()+cell()],'firstRow="1"'),Pkg(styles),self.presentation,self.theme)
        self.assertEqual(r['style_resolution'],'embedded_table_style')
        a,b=r['cells'][0],r['cells'][2]
        self.assertEqual(a['fill']['color']['rgb'],'2255AA')
        self.assertEqual(a['text_style']['color']['rgb'],'FFFFFF')
        self.assertTrue(a['text_style']['bold'])
        self.assertEqual(a['text_style']['font_east_asian'],'Microsoft YaHei')
        self.assertEqual(a['borders']['bottom']['width_pt'],3)
        self.assertEqual(b['fill']['color']['rgb'],'FFFFFF')
        self.assertEqual(b['borders']['top']['width_pt'],1)

    def test_explicit_cell_overrides_style_and_retains_nofill_borders(self):
        styles=self.styles('<a:wholeTbl><a:tcTxStyle><a:schemeClr val="lt1"/></a:tcTxStyle><a:tcStyle><a:fill><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:fill></a:tcStyle></a:wholeTbl>')
        c=cell(rprops='sz="1200" b="0"',props='marL="82550" marR="90000" marT="38100" marB="38100" anchor="ctr"')
        c=c.replace('</a:tc>', '').replace('<a:tcPr marL="82550" marR="90000" marT="38100" marB="38100" anchor="ctr"/>','<a:tcPr marL="82550" marR="90000" marT="38100" marB="38100" anchor="ctr"><a:lnL w="12700"><a:noFill/></a:lnL><a:solidFill><a:srgbClr val="FF7700"/></a:solidFill></a:tcPr>')+'</a:tc>'
        r=d.distill_table(table([c+cell()]),Pkg(styles),self.presentation,self.theme)
        e=r['cells'][0]
        self.assertEqual(e['fill']['color']['rgb'],'FF7700')
        self.assertEqual(e['borders']['left']['fill']['kind'],'none')
        self.assertEqual(e['margins_emu'],{'left':82550,'right':90000,'top':38100,'bottom':38100})
        self.assertEqual(e['text_style']['font_size_pt'],12)
        self.assertFalse(e['text_style']['bold'])
        self.assertEqual(e['text_style']['vertical_anchor'],'ctr')

    def test_unknown_builtin_style_does_not_invent_cell_colors(self):
        r=d.distill_table(table([cell()+cell()]),Pkg(),self.presentation,self.theme)
        self.assertEqual(r['style_resolution'],'unresolved_style_reference')
        self.assertIsNone(r['cells'][0]['fill'])
        self.assertIn('cell_fill_unresolved',r['cells'][0]['warnings'])
        self.assertIn('table_style_id_not_embedded_no_builtin_defaults_applied',r['warnings'])

    def test_merge_spans_and_continuation_anchor(self):
        r=d.distill_table(table([cell(attrs='gridSpan="2" rowSpan="2"')+cell(attrs='hMerge="1"'),
                                cell(attrs='vMerge="1"')+cell(attrs='hMerge="1" vMerge="1"')]),Pkg(),self.presentation,self.theme)
        self.assertEqual(r['merge_regions'],[{'row':0,'column':0,'row_span':2,'column_span':2,
            'start_row':0,'end_row':1,'start_column':0,'end_column':1}])
        for c in r['cells'][1:]: self.assertEqual(c['merge_anchor'],[0,0])

    def test_geometry_and_no_private_copy(self):
        r=d.distill_table(table([cell()+cell(),cell()+cell()]),Pkg(self.styles('<a:wholeTbl/>')),self.presentation,self.theme)
        self.assertEqual(r['column_widths_emu'],[400000,600000])
        self.assertEqual(r['column_ratios'],[.4,.6])
        self.assertEqual(r['row_heights_emu'],[200000,200000])
        self.assertEqual(r['row_ratios'],[.5,.5])
        raw=json.dumps(r)
        self.assertNotIn('PRIVATE CELL',raw)
        self.assertNotIn('PRIVATE CLIENT STYLE',raw)

    def test_theme_line_reference(self):
        theme_root=ET.fromstring('<a:theme '+NS+'><a:themeElements><a:fmtScheme><a:lnStyleLst><a:ln w="25400"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="dash"/></a:ln></a:lnStyleLst></a:fmtScheme></a:themeElements></a:theme>')
        theme=d.Theme(theme_root,{})
        ln=d.table_line_style(ET.fromstring('<a:lnRef '+NS+' idx="1"><a:srgbClr val="556677"/></a:lnRef>'),theme)
        self.assertEqual(ln['width_pt'],2)
        self.assertEqual(ln['fill']['color']['rgb'],'556677')
        self.assertEqual(ln['dash'],'dash')


if __name__=='__main__': unittest.main()
