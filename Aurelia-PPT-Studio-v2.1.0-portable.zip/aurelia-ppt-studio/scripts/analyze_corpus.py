"""Deterministic structural clustering of a permitted PPT corpus; not model training."""
import argparse
from collections import Counter
import math
from pathlib import Path
import statistics
from pptx_inspect import inspect, digest, sha, write_json


def features(slide):
    elements = slide['elements']
    boxes = [e for e in elements if e['box']]
    kinds = Counter(e['kind'] for e in elements)
    occupancy = [0.] * 12
    image_area = text_area = 0.
    sizes = []
    for e in boxes:
        x,y,w,h = e['box']
        area = max(0, min(1, w*h))
        if e['kind'] == 'text':
            text_area += area
        if e['kind'] == 'pic':
            image_area += area
        # Fine enough to distinguish composition, excluding full-canvas backgrounds.
        if w < .95 or h < .95:
            col = max(0, min(3, int((x+w/2)*4)))
            row = max(0, min(2, int((y+h/2)*3)))
            occupancy[row*4+col] += min(.5,area)
        sizes.extend(e['font_sizes'])
    return [math.log1p(len(elements)), math.log1p(kinds['text']), math.log1p(kinds['pic']),
            math.log1p(kinds['table']), math.log1p(kinds['chart']), math.log1p(kinds['grpSp']),
            min(2,text_area), min(2,image_area), (statistics.median(sizes) if sizes else 0)/40,
            (max(sizes) if sizes else 0)/72, len(boxes)/max(1,len(elements))] + occupancy


def kmeans(points, k, rounds=35):
    # Standardize features; farthest-first seeds produce stable clusters without RNG.
    dims = len(points[0])
    means = [statistics.mean(p[i] for p in points) for i in range(dims)]
    scales = [statistics.pstdev(p[i] for p in points) or 1 for i in range(dims)]
    scaled = [[(p[i]-means[i])/scales[i] for i in range(dims)] for p in points]
    distance = lambda a,b: sum((x-y)**2 for x,y in zip(a,b))
    centers = [scaled[0]]
    nearest = [distance(p,centers[0]) for p in scaled]
    while len(centers) < k:
        index = max(range(len(points)), key=lambda i: nearest[i])
        if nearest[index] < 1e-12:
            break
        centers.append(scaled[index])
        nearest = [min(d, distance(p,centers[-1])) for p,d in zip(scaled,nearest)]
    previous = None
    for _ in range(rounds):
        labels = [min(range(len(centers)), key=lambda i: distance(p,centers[i])) for p in scaled]
        if labels == previous:
            break
        previous = labels
        for c in range(len(centers)):
            members = [p for p,label in zip(scaled,labels) if label == c]
            if members:
                centers[c] = [statistics.mean(p[i] for p in members) for i in range(dims)]
    medoids = []
    for c in range(len(centers)):
        members = [i for i,label in enumerate(labels) if label == c]
        if members:
            medoids.append((c, min(members,key=lambda i: distance(scaled[i],centers[c])),len(members)))
    return labels, medoids


def analyze(corpus, output, k):
    corpus, output = Path(corpus).resolve(), Path(output).resolve()
    paths = sorted(p for p in corpus.rglob('*') if p.is_file() and p.suffix.lower() in ('.pptx','.potx','.pptm','.potm','.ppt'))
    rows, failures, duplicates, legacy = [], [], [], []
    seen = set()
    successful = 0
    for count, path in enumerate(paths,1):
        if path.suffix.lower() not in ('.pptx','.potx'):
            legacy.append(str(path)); continue
        try:
            fingerprint = sha(path)
            if fingerprint in seen:
                duplicates.append(str(path)); continue
            info = inspect(path)
            seen.add(fingerprint)
            successful += 1
            for slide in info['slides']:
                rows.append({'source_path':str(path),'source_sha256':fingerprint, 'slide':slide['number'],
                             'features':features(slide), 'geometry_hash':slide['geometry_hash'],
                             'elements':slide['elements'], 'font_names':slide['fonts'],
                             'review_signals':[s['kind'] for s in info['signals'] if s.get('slide') == slide['number']]})
        except Exception as exc:
            failures.append({'path':str(path),'error':str(exc)})
        if count % 100 == 0:
            print(f'Analyzed {count}/{len(paths)} files; {len(rows)} slides', flush=True)
    if not rows:
        raise ValueError('No supported readable slides')
    labels, medoids = kmeans([r['features'] for r in rows], min(k,len(rows)))
    clusters = []
    for cluster,index,count in medoids:
        row = rows[index]
        clusters.append({'id':f'structure-{cluster+1:02d}', 'status':'structural_only', 'slide_count':count,
                         'representative':{'source_sha256':row['source_sha256'],'slide':row['slide']},
                         'elements':row['elements'], 'features':row['features'], 'review_signals':row['review_signals'],
                         'visual_validation':None, 'new_content_generation_test':None})
    summary = {'schema':'aurelia-structural-atlas-v2', 'method':'standardized OOXML geometry features; deterministic k-means',
               'scope':'Structural analysis only. No image understanding, semantic labels, visual approval or fine-tuning.',
               'files_discovered':len(paths), 'unique_readable_decks':successful,'slides_analyzed':len(rows),
               'duplicates_skipped':len(duplicates), 'unsupported_files':len(legacy),'failed_files':len(failures),
               'clusters':clusters}
    for row,label in zip(rows,labels):
        row['cluster'] = f'structure-{label+1:02d}'
    write_json(output/'structural-atlas.json',summary)
    write_json(output/'private-corpus-index.json',{'corpus':str(corpus),'rows':rows,'failures':failures,'duplicates':duplicates,'unsupported':legacy})
    print({k:v for k,v in summary.items() if k != 'clusters'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus',required=True); parser.add_argument('--output',required=True)
    parser.add_argument('--clusters',type=int,default=16)
    args = parser.parse_args()
    if args.clusters < 2:
        parser.error('Need at least 2 clusters')
    analyze(args.corpus,args.output,args.clusters)
