"""Distill OOXML slide structures into portable, content-free design recipes.

This is structural extraction, not model training or rendered visual validation.
No source text, filenames, relationship targets, images, fonts or chart data are
included in the portable output. Standard-library only; never executes macros.
"""
from __future__ import annotations

import argparse
import copy
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import posixpath
import re
import struct
import xml.etree.ElementTree as ET
from zipfile import ZipFile

NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "c": "http://schemas.openxmlformats.org/drawingml/2006/chart"}
IDENTITY = (1, 0, 0, 1, 0, 0)
FILL_TAGS = ("solidFill", "gradFill", "blipFill", "pattFill", "noFill", "grpFill")
LIMITATIONS = [
    "Structural recipes have not been rendered or aesthetically validated.",
    "Original copy, chart values, artwork, font binaries and source paths are excluded.",
    "Image slots require replacement assets and rights checks; a picture-only slide has no recoverable editable design.",
    "Theme, color maps, matching placeholders and common text-style inheritance are resolved; unsupported effects and script font fallback require review.",
    "Rotated nested groups are represented by axis-aligned bounds and transform metadata; exact re-creation needs a transform-aware renderer.",
    "SmartArt, OLE, equations, custom paths, animation and video require manual rebuilding; they are not converted to working content.",
    "Font family names do not include font files or redistribution rights; check availability and approve substitutions.",
    "Table styles are resolved only from embedded tableStyles.xml and explicit cell properties; unavailable built-in table styles remain unresolved.",
]


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def tag(node):
    return node.tag.rsplit("}", 1)[-1]


def number(value, default=0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def first_not_none(values):
    return next((v for v in values if v is not None), None)


def multiply(m, n):
    a, b, c, d, e, f = m
    g, h, i, j, k, l = n
    return (a*g+c*h, b*g+d*h, a*i+c*j, b*i+d*j, a*k+c*l+e, b*k+d*l+f)


def point(m, x, y):
    a, b, c, d, e, f = m
    return a*x+c*y+e, b*x+d*y+f


def transform_of(node):
    return first_not_none([node.find("p:spPr/a:xfrm", NS), node.find("p:xfrm", NS),
                           node.find("p:grpSpPr/a:xfrm", NS)])


def dimensions(xfrm):
    if xfrm is None:
        return None
    off, ext = xfrm.find("a:off", NS), xfrm.find("a:ext", NS)
    if off is None or ext is None:
        return None
    return [number(off.get("x")), number(off.get("y")), number(ext.get("cx")), number(ext.get("cy"))]


def rotation_matrix(x, y, w, h, degrees, flip_h=False, flip_v=False):
    angle = math.radians(degrees)
    c, s = math.cos(angle), math.sin(angle)
    cx, cy = x+w/2, y+h/2
    m = (c, s, -s, c, 0, 0)
    m = multiply(m, (-1 if flip_h else 1, 0, 0, -1 if flip_v else 1, 0, 0))
    return multiply((1, 0, 0, 1, cx, cy), multiply(m, (1, 0, 0, 1, -cx, -cy)))


def placeholder(node):
    ph = node.find(".//p:nvPr/p:ph", NS)
    return {"type": ph.get("type", "obj"), "idx": ph.get("idx", "0")} if ph is not None else None


def matching_placeholder(root, ph, master=False):
    if root is None or not ph:
        return None
    matches = [(n, placeholder(n)) for n in root.findall("p:cSld/p:spTree/p:sp", NS)]
    if not master:
        n = next((n for n, p in matches if p and p["idx"] == ph["idx"]), None)
        if n is not None:
            return n
    aliases = {"ctrTitle": "title", "subTitle": "body", "obj": "body"}
    wanted = aliases.get(ph["type"], ph["type"])
    return next((n for n, p in matches if p and aliases.get(p["type"], p["type"]) == wanted), None)


class Package:
    def __init__(self, path):
        self.z = ZipFile(path)
        self.names = set(self.z.namelist())
        self.cache = {}

    def close(self):
        self.z.close()

    def xml(self, part):
        if not part or part not in self.names:
            return None
        if part not in self.cache:
            if self.z.getinfo(part).file_size > 32 * 1024 * 1024:
                raise ValueError("oversize_xml")
            self.cache[part] = ET.fromstring(self.z.read(part))
        return self.cache[part]

    def rels(self, part):
        folder, name = posixpath.split(part)
        root = self.xml(posixpath.join(folder, "_rels", name + ".rels"))
        if root is None:
            return {}
        return {n.get("Id"): dict(n.attrib) for n in root}

    def resolve(self, part, rel):
        if not rel or rel.get("TargetMode") == "External":
            return None
        target = rel.get("Target", "")
        return posixpath.normpath(posixpath.join(posixpath.dirname(part), target)).lstrip("/")

    def related(self, part, suffix):
        return next((self.resolve(part, r) for r in self.rels(part).values()
                     if r.get("Type", "").endswith("/" + suffix)), None)


class Theme:
    def __init__(self, root, color_map):
        self.root, self.color_map = root, color_map
        self.colors = {}
        self.fonts = {}
        if root is not None:
            scheme = root.find("a:themeElements/a:clrScheme", NS)
            for n in scheme if scheme is not None else []:
                child = list(n)[0] if len(n) else None
                if child is not None:
                    self.colors[tag(n)] = child.get("lastClr") or child.get("val")
            for family in ("major", "minor"):
                parent = root.find("a:themeElements/a:fontScheme/a:" + family + "Font", NS)
                if parent is not None:
                    for script in ("latin", "ea", "cs"):
                        n = parent.find("a:" + script, NS)
                        if n is not None:
                            self.fonts[family + ":" + script] = n.get("typeface") or None

    def font(self, name):
        if not name:
            return None
        m = re.fullmatch(r"\+(mj|mn)-(lt|ea|cs)", name)
        if m:
            return self.fonts.get(("major" if m[1] == "mj" else "minor") + ":" +
                                  {"lt": "latin", "ea": "ea", "cs": "cs"}[m[2]])
        # Font family is the only free-form source string retained by this schema.
        # Reject paths/URLs; font binaries are never copied.
        return name if len(name) <= 150 and not any(c in name for c in ("/", "\\", ":")) else None

    def color(self, root):
        if root is None:
            return None
        node = next((n for n in root if tag(n) in ("srgbClr", "schemeClr", "sysClr", "scrgbClr", "prstClr")), None)
        if node is None:
            return None
        kind, value = tag(node), node.get("val")
        if kind == "schemeClr":
            mapped = self.color_map.get(value, value)
            rgb = self.colors.get(mapped)
            source = "theme:" + str(mapped)
        elif kind == "sysClr":
            rgb, source = node.get("lastClr"), "system_last_color"
        elif kind == "srgbClr":
            rgb, source = value, "explicit"
        elif kind == "scrgbClr":
            rgb = "".join(f"{min(255,max(0,round(number(node.get(c))*255/100000))):02X}" for c in ("r", "g", "b"))
            source = "scrgb_approximation"
        else:
            named = {"black": "000000", "white": "FFFFFF", "red": "FF0000", "blue": "0000FF", "green": "008000"}
            rgb, source = named.get(value), "preset"
        transforms = {tag(n): number(n.get("val")) / 100000 for n in node if n.get("val") is not None}
        result = {"rgb": rgb.upper() if rgb and re.fullmatch(r"[0-9a-fA-F]{6}", rgb) else None, "source": source}
        if transforms:
            result["transforms"] = transforms
            if result["rgb"]:
                v = [int(result["rgb"][i:i+2], 16)/255 for i in (0, 2, 4)]
                for t in node:
                    ratio = number(t.get("val")) / 100000
                    if tag(t) == "tint": v = [x+(1-x)*ratio for x in v]
                    elif tag(t) == "shade": v = [x*ratio for x in v]
                    elif tag(t) == "lumMod": v = [x*ratio for x in v]
                    elif tag(t) == "lumOff": v = [x+ratio for x in v]
                result["rgb"] = "".join(f"{round(min(1,max(0,x))*255):02X}" for x in v)
                if any(t in transforms for t in ("lumMod", "lumOff", "satMod", "hueMod")):
                    result["approximation"] = "complex_color_transform_requires_render_review"
            if "alpha" in transforms:
                result["opacity"] = transforms["alpha"]
        return result

    def fill(self, root):
        if root is None:
            return None
        f = root if tag(root) in FILL_TAGS else next((n for n in root if tag(n) in FILL_TAGS), None)
        if f is None:
            return None
        kind = tag(f)
        if kind == "noFill": return {"kind": "none"}
        if kind == "solidFill": return {"kind": "solid", "color": self.color(f)}
        if kind == "blipFill": return {"kind": "image", "requires_asset": True, "needs_rights": True}
        if kind == "gradFill":
            lin = f.find("a:lin", NS)
            return {"kind": "gradient", "stops": [{"position": number(n.get("pos"))/100000,
                    "color": self.color(n)} for n in f.findall("a:gsLst/a:gs", NS)],
                    "angle_degrees": number(lin.get("ang"))/60000 if lin is not None else None,
                    "requires_review": f.find("a:path", NS) is not None}
        if kind == "pattFill":
            return {"kind": "pattern", "preset": f.get("prst"),
                    "foreground": self.color(f.find("a:fgClr", NS)), "background": self.color(f.find("a:bgClr", NS)),
                    "requires_review": True}
        return {"kind": "group_inherited", "requires_review": True}

    def referenced_fill(self, ref, background=False):
        if ref is None: return None
        idx = int(number(ref.get("idx")))
        if idx == 0: return {"kind":"none", "inheritance_source":"theme_format_style"}
        color = self.color(ref)
        parent_name = "bgFillStyleLst" if idx >= 1001 else "fillStyleLst"
        offset = idx-1001 if idx >= 1001 else idx-1
        parent = self.root.find("a:themeElements/a:fmtScheme/a:"+parent_name, NS) if self.root is not None else None
        if parent is None or offset < 0 or offset >= len(parent):
            return {"kind":"unresolved_theme_fill", "color":color, "theme_style_index":idx,"requires_review":True}
        previous = self.colors.get("phClr")
        try:
            self.colors["phClr"] = color.get("rgb") if color else None
            result = self.fill(list(parent)[offset])
        finally:
            if previous is None: self.colors.pop("phClr",None)
            else: self.colors["phClr"] = previous
        if result:
            result["inheritance_source"] = "theme_format_style"
            result["resolved_style_index"] = idx
        return result


def effective_text(node, inherited, master_root, pres_root, theme, ph):
    paragraphs = node.findall("p:txBody/a:p", NS)
    if not paragraphs:
        return None, None, []
    styles, sources = [], set()
    for p in paragraphs:
        pp = p.find("a:pPr", NS)
        level = int(number(pp.get("lvl"))) if pp is not None else 0
        level = min(8, max(0, level)) + 1
        chain = []
        default = pres_root.find(f"p:defaultTextStyle/a:lvl{level}pPr", NS)
        if default is not None: chain.append((default, "presentation_default"))
        if master_root is not None:
            category = "titleStyle" if ph and ph["type"] in ("title", "ctrTitle") else "bodyStyle" if ph else "otherStyle"
            d = master_root.find(f"p:txStyles/p:{category}/a:lvl{level}pPr", NS)
            if d is not None: chain.append((d, "master_text_style"))
        for inherited_node, origin in reversed(inherited):
            d = inherited_node.find(f"p:txBody/a:lstStyle/a:lvl{level}pPr", NS)
            if d is not None: chain.append((d, origin+"_list_style"))
            inherited_para = inherited_node.find("p:txBody/a:p/a:pPr", NS)
            if inherited_para is not None: chain.append((inherited_para, origin+"_paragraph_style"))
        own_list = node.find(f"p:txBody/a:lstStyle/a:lvl{level}pPr", NS)
        if own_list is not None: chain.append((own_list, "shape_list_style"))
        if pp is not None: chain.append((pp, "paragraph_style"))
        base = {"font_latin": theme.fonts.get("minor:latin"), "font_east_asian": theme.fonts.get("minor:ea")}
        alignment = None
        for props, origin in chain:
            if props.get("algn"): alignment = props.get("algn")
            apply_text_props(base, props.find("a:defRPr", NS), theme)
            sources.add(origin)
        runs = p.findall("a:r", NS) + p.findall("a:fld", NS)
        if not runs:
            runs = [p]
        for r in runs:
            style = dict(base)
            apply_text_props(style, r.find("a:rPr", NS) if r is not p else p.find("a:endParaRPr", NS), theme)
            if alignment: style["alignment"] = alignment
            if r.find("a:rPr", NS) is not None: sources.add("run_style")
            body = first_not_none([node.find("p:txBody/a:bodyPr", NS)] + [n.find("p:txBody/a:bodyPr", NS) for n, _ in inherited])
            if body is not None:
                for attr, key in (("anchor", "vertical_anchor"), ("vert", "vertical_mode"), ("wrap", "wrap")):
                    if body.get(attr): style[key] = body.get(attr)
                style["insets_emu"] = {k: int(number(body.get(k))) for k in ("lIns", "rIns", "tIns", "bIns") if body.get(k) is not None}
            if style not in styles: styles.append(style)
    capacity = {"paragraph_count": len(paragraphs), "character_count": sum(len(t.text or "") for t in node.findall("p:txBody//a:t", NS))}
    return styles[0] if styles else {}, capacity, styles


def apply_text_props(style, props, theme):
    if props is None: return
    if props.get("sz") is not None: style["font_size_pt"] = number(props.get("sz"))/100
    for attr, key in (("b", "bold"), ("i", "italic")):
        if props.get(attr) is not None: style[key] = props.get(attr) in ("1", "true")
    for script, key in (("latin", "font_latin"), ("ea", "font_east_asian"), ("cs", "font_complex_script")):
        n = props.find("a:"+script, NS)
        if n is not None: style[key] = theme.font(n.get("typeface"))
    fill = theme.fill(props)
    if fill and fill.get("kind") == "solid": style["color"] = fill.get("color")


def geometry_of(node):
    preset = node.find("p:spPr/a:prstGeom", NS)
    if preset is not None:
        return {"preset": preset.get("prst"), "adjustments": {n.get("name"): n.get("fmla")
                for n in preset.findall("a:avLst/a:gd", NS) if re.fullmatch(r"[A-Za-z0-9_ +*/.\-]+", n.get("fmla", ""))}}
    custom = node.find("p:spPr/a:custGeom", NS)
    if custom is not None:
        return {"preset": "custom", "requires_rebuild": True, "path_count": len(custom.findall("a:pathLst/a:path", NS))}
    return None


def table_line_style(line, theme):
    """Cell border metadata, including explicit noFill (not a black default)."""
    if line is None: return None
    if tag(line) == "lnRef":
        idx=int(number(line.get("idx")))
        styles=theme.root.find("a:themeElements/a:fmtScheme/a:lnStyleLst",NS) if theme.root is not None else None
        if idx == 0: return {"fill":{"kind":"none"},"width_pt":0,"resolved_style_index":0}
        if styles is None or idx < 1 or idx > len(styles):
            return {"requires_review":True,"unresolved_theme_line_style":idx}
        previous=theme.colors.get("phClr")
        try:
            color=theme.color(line)
            theme.colors["phClr"]=color.get("rgb") if color else None
            result=table_line_style(list(styles)[idx-1],theme)
        finally:
            if previous is None: theme.colors.pop("phClr",None)
            else: theme.colors["phClr"]=previous
        result["resolved_style_index"]=idx
        return result
    result={"fill":theme.fill(line)}
    if line.get("w") is not None: result["width_pt"]=number(line.get("w"))/12700
    dash=line.find("a:prstDash",NS)
    if dash is not None: result["dash"]=dash.get("val")
    elif line.find("a:custDash",NS) is not None: result["requires_custom_dash_adapter"]=True
    for attr in ("cap","cmpd","algn"):
        if line.get(attr): result[attr]=line.get(attr)
    return result


def table_text_styles(cell, inherited_style, presentation, theme):
    """Resolve source typography without retaining any paragraph/run text."""
    body=cell.find("a:txBody",NS)
    if body is None: return [], {"paragraph_count":0,"character_count":0}
    styles=[]
    paragraphs=body.findall("a:p",NS)
    for p in paragraphs:
        pp=p.find("a:pPr",NS)
        level=min(8,max(0,int(number(pp.get("lvl"))) if pp is not None else 0))+1
        base={}
        default=presentation.find(f"p:defaultTextStyle/a:lvl{level}pPr",NS)
        if default is not None:
            apply_text_props(base,default.find("a:defRPr",NS),theme)
            if default.get("algn"): base["alignment"]=default.get("algn")
        base.update(inherited_style)
        for props in (body.find(f"a:lstStyle/a:lvl{level}pPr",NS),pp):
            if props is not None:
                apply_text_props(base,props.find("a:defRPr",NS),theme)
                if props.get("algn"): base["alignment"]=props.get("algn")
        bp=body.find("a:bodyPr",NS)
        if bp is not None:
            for attr,key in (("anchor","vertical_anchor"),("vert","vertical_mode"),("wrap","wrap")):
                if bp.get(attr): base[key]=bp.get(attr)
        cp=cell.find("a:tcPr",NS)
        if cp is not None:
            for attr,key in (("anchor","vertical_anchor"),("vert","vertical_mode")):
                if cp.get(attr): base[key]=cp.get(attr)
        runs=p.findall("a:r",NS)+p.findall("a:fld",NS)
        if not runs: runs=[p]
        for run in runs:
            style=dict(base)
            apply_text_props(style,run.find("a:rPr",NS) if run is not p else p.find("a:endParaRPr",NS),theme)
            if style not in styles: styles.append(style)
    return styles,{"paragraph_count":len(paragraphs),"character_count":sum(len(n.text or "") for n in body.findall(".//a:t",NS))}


def table_part_style(part, theme):
    result={"fill":None,"borders":{},"text_style":{}}
    if part is None: return result
    tc=part.find("a:tcStyle",NS)
    if tc is not None:
        fill=first_not_none([tc.find("a:fill",NS),tc])
        result["fill"]=theme.fill(fill)
        if result["fill"] is None:
            ref=first_not_none([tc.find("a:fillRef",NS),tc.find("a:fill/a:fillRef",NS)])
            if ref is not None: result["fill"]=theme.referenced_fill(ref)
        for name in ("left","right","top","bottom","insideH","insideV","tl2br","tr2bl"):
            border=tc.find("a:tcBdr/a:"+name,NS)
            if border is not None:
                line=first_not_none([border.find("a:ln",NS),border.find("a:lnRef",NS)])
                if line is not None: result["borders"][name]=table_line_style(line,theme)
    tx=part.find("a:tcTxStyle",NS)
    if tx is not None:
        text_style=result["text_style"]
        for attr,key in (("b","bold"),("i","italic")):
            if tx.get(attr) not in (None,"def"):
                text_style[key]=tx.get(attr) in ("on","1","true")
        font_ref=tx.find("a:fontRef",NS)
        if font_ref is not None and font_ref.get("idx") in ("major","minor"):
            family=font_ref.get("idx")
            for script,key in (("latin","font_latin"),("ea","font_east_asian"),("cs","font_complex_script")):
                resolved=theme.fonts.get(family+":"+script)
                if resolved: text_style[key]=theme.font(resolved)
        font=tx.find("a:font",NS)
        if font is not None: apply_text_props(text_style,font,theme)
        color=theme.color(tx) or theme.color(font_ref)
        if color is not None: text_style["color"]=color
    return result


def distill_table(table, pkg, presentation, theme):
    """Portable cell formatting. Unknown styles are recorded, never invented."""
    rows=table.findall("a:tr",NS)
    widths=[int(number(n.get("w"))) for n in table.findall("a:tblGrid/a:gridCol",NS)]
    heights=[int(number(n.get("h"))) for n in rows]
    props=table.find("a:tblPr",NS)
    flags={key:props is not None and props.get(key) in ("1","true","on")
           for key in ("firstRow","lastRow","firstCol","lastCol","bandRow","bandCol")}
    result={"schema_version":2,"row_count":len(rows),"column_count":len(widths),
            "column_widths_emu":widths,"row_heights_emu":heights,
            "column_ratios":[round(w/sum(widths),8) for w in widths] if sum(widths) else [],
            "row_ratios":[round(h/sum(heights),8) for h in heights] if sum(heights) else [],
            "requires_new_data":True,"original_values_excluded":True,"cells":[],"merge_regions":[],
            "table_style_flags":flags,"style_resolution":"no_style_reference","warnings":[]}
    styles_part=pkg.related("ppt/presentation.xml","tableStyles") or "ppt/tableStyles.xml"
    try:
        styles_root=pkg.xml(styles_part)
    except Exception:
        styles_root=None
        result["warnings"].append("table_styles_part_unreadable")
    style_id=props.find("a:tableStyleId",NS) if props is not None else None
    sid=(style_id.text or "").strip() if style_id is not None else styles_root.get("def") if styles_root is not None else None
    if sid:
        # A GUID is portable; do not retain custom human-readable style names.
        result["style_id"]=sid if re.fullmatch(r"\{?[0-9A-Fa-f-]{36}\}?",sid) else "sha256:"+hashlib.sha256(sid.encode()).hexdigest()
    chosen=next((n for n in styles_root.findall("a:tblStyle",NS) if n.get("styleId")==sid),None) if styles_root is not None else None
    if chosen is not None: result["style_resolution"]="embedded_table_style"
    elif sid:
        result["style_resolution"]="unresolved_style_reference"
        result["warnings"].append("table_style_id_not_embedded_no_builtin_defaults_applied")
    else:
        result["warnings"].append("no_table_style_reference_only_explicit_properties_resolved")

    def region_parts(r,c):
        names=["wholeTbl"]
        # Conditional regions are explicit and recorded for audit. Complex
        # intersections still require visual review; no proprietary builtin map.
        if flags["bandCol"]: names.append("band1V" if (c-int(flags["firstCol"]))%2==0 else "band2V")
        if flags["bandRow"]: names.append("band1H" if (r-int(flags["firstRow"]))%2==0 else "band2H")
        if flags["lastCol"] and c==len(widths)-1: names.append("lastCol")
        if flags["firstCol"] and c==0: names.append("firstCol")
        if flags["lastRow"] and r==len(rows)-1: names.append("lastRow")
        if flags["firstRow"] and r==0: names.append("firstRow")
        for name,yes in (("nwCell",r==0 and c==0 and flags["firstRow"] and flags["firstCol"]),
                         ("neCell",r==0 and c==len(widths)-1 and flags["firstRow"] and flags["lastCol"]),
                         ("swCell",r==len(rows)-1 and c==0 and flags["lastRow"] and flags["firstCol"]),
                         ("seCell",r==len(rows)-1 and c==len(widths)-1 and flags["lastRow"] and flags["lastCol"])):
            if yes: names.append(name)
        return [(name,chosen.find("a:"+name,NS)) for name in names if chosen is not None and chosen.find("a:"+name,NS) is not None]

    for ri,row in enumerate(rows):
        row_cells=row.findall("a:tc",NS)
        if len(row_cells)!=len(widths): result["warnings"].append("table_row_cell_count_differs_from_grid")
        for ci,cell in enumerate(row_cells):
            rs=max(1,int(number(cell.get("rowSpan"),1)))
            cs=max(1,int(number(cell.get("gridSpan"),1)))
            hmerge=cell.get("hMerge") in ("1","true")
            vmerge=cell.get("vMerge") in ("1","true")
            entry={"row":ri,"column":ci,"row_span":rs,"column_span":cs,"h_merge":hmerge,"v_merge":vmerge,
                   "is_merge_continuation":hmerge or vmerge,"fill":None,"borders":{},"margins_emu":{},
                   "text_style":None,"text_style_variants":[],"style_sources":[],"warnings":[]}
            combined_borders={}
            border_priority={}
            text_base={}
            applicable=region_parts(ri,ci)
            for priority,(name,part) in enumerate(applicable):
                parsed=table_part_style(part,theme)
                if parsed["fill"] is not None: entry["fill"]=parsed["fill"]
                combined_borders.update(parsed["borders"])
                border_priority.update({edge:priority for edge in parsed["borders"]})
                text_base.update(parsed["text_style"])
                entry["style_sources"].append("table_style:"+name)
            if len(applicable)>2:
                entry["warnings"].append("conditional_style_intersection_requires_visual_review")
            # Interior table border specs act on internal boundaries. Per-cell
            # explicit edges below override this conditional-table resolution.
            for edge in ("left","right","top","bottom"):
                if edge in combined_borders: entry["borders"][edge]=copy.deepcopy(combined_borders[edge])
            if "insideH" in combined_borders:
                if ri>0 and border_priority["insideH"]>=border_priority.get("top",-1): entry["borders"]["top"]=copy.deepcopy(combined_borders["insideH"])
                if ri<len(rows)-1 and border_priority["insideH"]>=border_priority.get("bottom",-1): entry["borders"]["bottom"]=copy.deepcopy(combined_borders["insideH"])
            if "insideV" in combined_borders:
                if ci>0 and border_priority["insideV"]>=border_priority.get("left",-1): entry["borders"]["left"]=copy.deepcopy(combined_borders["insideV"])
                if ci<len(widths)-1 and border_priority["insideV"]>=border_priority.get("right",-1): entry["borders"]["right"]=copy.deepcopy(combined_borders["insideV"])
            for key,edge in (("tl2br","diagonal_down"),("tr2bl","diagonal_up")):
                if key in combined_borders: entry["borders"][edge]=combined_borders[key]
            cp=cell.find("a:tcPr",NS)
            if cp is not None:
                f=theme.fill(cp)
                if f is not None: entry["fill"]=f
                for attr,name in (("marL","left"),("marR","right"),("marT","top"),("marB","bottom")):
                    if cp.get(attr) is not None: entry["margins_emu"][name]=int(number(cp.get(attr)))
                for key,edge in (("lnL","left"),("lnR","right"),("lnT","top"),("lnB","bottom"),
                                 ("lnTlToBr","diagonal_down"),("lnBlToTr","diagonal_up")):
                    ln=cp.find("a:"+key,NS)
                    if ln is not None: entry["borders"][edge]=table_line_style(ln,theme)
                if any(k in cp.attrib for k in ("vert","anchor","anchorCtr")):
                    entry["cell_alignment"]={k:cp.get(k) for k in ("vert","anchor","anchorCtr") if cp.get(k) is not None}
                entry["style_sources"].append("explicit_cell_properties")
            variants,capacity=table_text_styles(cell,text_base,presentation,theme)
            entry["text_style_variants"]=variants
            entry["text_style"]=variants[0] if variants else {}
            entry["text_capacity"]=capacity
            if cell.findall("a:txBody/a:p/a:r/a:rPr",NS): entry["style_sources"].append("explicit_run_properties")
            if entry["fill"] is None: entry["warnings"].append("cell_fill_unresolved")
            if not entry["text_style"].get("font_size_pt"): entry["warnings"].append("cell_font_size_unresolved")
            if not (entry["text_style"].get("color") or {}).get("rgb"): entry["warnings"].append("cell_text_color_unresolved")
            if any(edge not in entry["borders"] for edge in ("left","right","top","bottom")):
                entry["warnings"].append("some_cell_borders_unresolved")
            if (rs>1 or cs>1) and not entry["is_merge_continuation"]:
                result["merge_regions"].append({"row":ri,"column":ci,"row_span":rs,"column_span":cs,
                    "start_row":ri,"end_row":ri+rs-1,"start_column":ci,"end_column":ci+cs-1})
                if ri+rs>len(rows) or ci+cs>len(widths): entry["warnings"].append("merge_region_outside_table_grid")
            result["cells"].append(entry)
    for cell in result["cells"]:
        if cell["is_merge_continuation"]:
            anchor=next((m for m in result["merge_regions"] if m["row"]<=cell["row"]<m["row"]+m["row_span"]
                         and m["column"]<=cell["column"]<m["column"]+m["column_span"]),None)
            if anchor: cell["merge_anchor"]=[anchor["row"],anchor["column"]]
            else: cell["warnings"].append("merge_continuation_without_explicit_span_anchor")
    result["warnings"]=sorted(set(result["warnings"]))
    return result


def layout_summary(elements):
    visible = [e for e in elements if e.get("box") and e["origin"] == "slide"]
    kinds = Counter(e["kind"] for e in visible)
    rows, cols = Counter(), Counter()
    for e in visible:
        x, y, w, h = e["box"]
        rows[round(y / .015)] += 1
        cols[round(x / .015)] += 1
    silhouette = sorted((e["kind"], [round(v * 50) for v in e["box"]]) for e in visible)
    return {"kind_counts": dict(kinds), "same_top_alignment_groups": sum(n > 1 for n in rows.values()),
            "same_left_alignment_groups": sum(n > 1 for n in cols.values()),
            "picture_area_sum_fraction": round(sum(e["box"][2]*e["box"][3] for e in visible if e["kind"] == "image"), 4),
            "structure_fingerprint": digest(silhouette),
            "fingerprint_ignores_color_and_text": True,
            "inference_scope": "geometry_only_not_visual_semantics"}


def image_dimensions(pkg, owner_part, node):
    blip = node.find(".//a:blip", NS)
    if blip is None: return None
    relid = blip.get("{"+NS["r"]+"}embed")
    part = pkg.resolve(owner_part, pkg.rels(owner_part).get(relid))
    if not part or part not in pkg.names: return None
    with pkg.z.open(part) as stream:
        b = stream.read(131072)
    if b.startswith(b"\x89PNG\r\n\x1a\n") and len(b) >= 24: return list(struct.unpack(">II", b[16:24]))
    if b[:6] in (b"GIF87a", b"GIF89a") and len(b) >= 10: return list(struct.unpack("<HH", b[6:10]))
    if b[:2] == b"BM" and len(b) >= 26: return [abs(n) for n in struct.unpack("<ii", b[18:26])]
    if b[:2] == b"\xff\xd8":
        i = 2
        while i+4 < len(b):
            if b[i] != 255: i += 1; continue
            marker = b[i+1]; i += 2
            if marker in (0xD8, 0xD9): continue
            length = int.from_bytes(b[i:i+2], "big")
            if marker in (0xC0, 0xC1, 0xC2, 0xC3) and i+7 <= len(b):
                return [int.from_bytes(b[i+5:i+7], "big"), int.from_bytes(b[i+3:i+5], "big")]
            if length < 2: break
            i += length
    return None


def distill_slide(pkg, part, number_, source_hash, presentation):
    root = pkg.xml(part)
    if root is None: raise ValueError("missing_slide_part")
    lp = pkg.related(part, "slideLayout")
    mp = pkg.related(lp, "slideMaster") if lp else None
    tp = pkg.related(mp, "theme") if mp else None
    layout, master = pkg.xml(lp), pkg.xml(mp)
    cmap = {"bg1":"lt1", "tx1":"dk1", "bg2":"lt2", "tx2":"dk2"}
    if master is not None:
        cm = master.find("p:clrMap", NS)
        if cm is not None: cmap.update(cm.attrib)
    for r in (layout, root):
        if r is not None:
            cm = r.find("p:clrMapOvr/a:overrideClrMapping", NS)
            if cm is not None: cmap.update(cm.attrib)
    theme = Theme(pkg.xml(tp), cmap)
    size = presentation.find("p:sldSz", NS)
    width, height = int(size.get("cx")), int(size.get("cy"))
    if min(width, height) <= 0: raise ValueError("invalid_canvas")
    out = {"schema_version":1, "design_id":source_hash[:16]+f"-p{number_:04d}", "source_sha256":source_hash,
           "source_page":number_, "validation_status":"structural_only", "canvas":{"width_emu":width,"height_emu":height},
           "background":None,"elements":[], "warnings":[]}
    for r, origin in ((root,"slide"),(layout,"layout"),(master,"master")):
        if r is None: continue
        bg = r.find("p:cSld/p:bg", NS)
        if bg is not None:
            prop = bg.find("p:bgPr", NS)
            out["background"] = theme.fill(prop)
            if out["background"] is None:
                ref = bg.find("p:bgRef", NS)
                if ref is not None:
                    out["background"] = theme.referenced_fill(ref,background=True)
            if out["background"] is not None:
                out["background"]["inheritance_source"] = origin
                break
    if out["background"] is None:
        out["background"] = {"kind":"unspecified", "requires_review":True}

    def visit(container, owner_part, origin, matrix=IDENTITY, parent=None):
        for node in container:
            typ = tag(node)
            if typ not in ("sp","pic","graphicFrame","cxnSp","grpSp"): continue
            ph = placeholder(node)
            if origin != "slide" and ph: continue
            inherited = []
            if origin == "slide" and ph:
                lnode = matching_placeholder(layout, ph)
                mnode = matching_placeholder(master, placeholder(lnode) if lnode is not None else ph, master=True)
                inherited = [(n, src) for n, src in ((lnode,"layout"),(mnode,"master")) if n is not None]
            xfrm = first_not_none([transform_of(node)] + [transform_of(n) for n, _ in inherited])
            dims = dimensions(xfrm)
            rotation = number(xfrm.get("rot"))/60000 if xfrm is not None else 0
            flip_h = xfrm is not None and xfrm.get("flipH") in ("1","true")
            flip_v = xfrm is not None and xfrm.get("flipV") in ("1","true")
            if typ == "grpSp":
                if dims is None:
                    out["warnings"].append("group_transform_missing")
                    visit(node, owner_part, origin, matrix, parent)
                    continue
                x,y,w,h = dims
                child_off, child_ext = xfrm.find("a:chOff",NS), xfrm.find("a:chExt",NS)
                if child_off is None or child_ext is None or not number(child_ext.get("cx")) or not number(child_ext.get("cy")):
                    out["warnings"].append("group_child_transform_missing")
                    visit(node, owner_part, origin, matrix, parent)
                    continue
                sx,sy = w/number(child_ext.get("cx")),h/number(child_ext.get("cy"))
                gm = (sx,0,0,sy,x-number(child_off.get("x"))*sx,y-number(child_off.get("y"))*sy)
                gm = multiply(rotation_matrix(x,y,w,h,rotation,flip_h,flip_v),gm)
                if rotation: out["warnings"].append("rotated_group_requires_transform_aware_rebuild")
                visit(node, owner_part, origin, multiply(matrix,gm), "group"+str(len(out["elements"])+1))
                continue
            kind = {"sp":"shape","pic":"image","graphicFrame":"embedded","cxnSp":"connector"}[typ]
            # PowerPoint frequently writes empty txBody onto decorative shapes.
            # Those objects are geometry, not slots for arbitrary new copy.
            has_text = any((t.text or "").strip() for t in node.findall("p:txBody//a:t",NS))
            if node.find("p:txBody",NS) is not None and (has_text or ph): kind = "text"
            if node.find(".//a:tbl",NS) is not None: kind = "table"
            chart_node = first_not_none([node.find(".//c:chart",NS), next((n for n in node.iter()
                                        if tag(n) == "chart" and "chartex" in n.tag.lower()),None)])
            if chart_node is not None: kind = "chart"
            box = None
            if dims is not None:
                x,y,w,h = dims
                em = multiply(matrix, rotation_matrix(x,y,w,h,rotation,flip_h,flip_v))
                pts = [point(em,a,b) for a,b in ((x,y),(x+w,y),(x,y+h),(x+w,y+h))]
                minx,miny,maxx,maxy = min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)
                box = [round(minx/width,6),round(miny/height,6),round((maxx-minx)/width,6),round((maxy-miny)/height,6)]
            e = {"id":f"e{len(out['elements'])+1:04d}","kind":kind,"origin":origin,"placeholder":ph,"box":box,
                 "rotation_degrees":rotation,"flip_horizontal":flip_h,"flip_vertical":flip_v,
                 "geometry":first_not_none([geometry_of(node)]+[geometry_of(n) for n,_ in inherited]),
                 "fill":None,"line":None,"text_style":None,"requires_asset":kind=="image","warnings":[],
                 "inheritance_sources":[origin]+[src for _,src in inherited]}
            if parent:
                e["parent_group"] = parent
                e["group_matrix_emu"] = [round(v,6) for v in matrix]
                e["local_geometry_emu"] = dims
            if box is None: e["warnings"].append("unresolved_geometry")
            sp_chain = [node]+[n for n,_ in inherited]
            for n in sp_chain:
                prop = n.find("p:spPr",NS)
                if e["fill"] is None: e["fill"] = theme.fill(prop)
                ln = prop.find("a:ln",NS) if prop is not None else None
                if e["line"] is None and ln is not None:
                    dash = ln.find("a:prstDash",NS)
                    e["line"] = {"width_pt":number(ln.get("w"),12700)/12700,"fill":theme.fill(ln),
                                 "dash":dash.get("val") if dash is not None else None}
            if e["fill"] is None:
                ref = first_not_none([n.find("p:style/a:fillRef",NS) for n in sp_chain])
                if ref is not None:
                    e["fill"] = theme.referenced_fill(ref)
            if kind == "text":
                style, capacity, variants = effective_text(node,inherited,master,presentation,theme,ph)
                e.update(text_style=style,text_capacity=capacity,text_style_variants=variants)
                if style and not style.get("font_size_pt"): e["warnings"].append("font_size_unresolved")
                if style and not style.get("font_east_asian"): e["warnings"].append("east_asian_font_fallback_not_resolved")
            if kind == "image":
                e["needs_rights"] = True
                try:
                    e["intrinsic_pixels"] = image_dimensions(pkg,owner_part,node)
                except Exception:
                    e["intrinsic_pixels"] = None
                    e["warnings"].append("source_image_unreadable_dimensions_unavailable")
                crop = node.find("p:blipFill/a:srcRect",NS)
                e["crop"] = {name:number(crop.get(code))/100000 if crop is not None else 0
                             for code,name in (("l","left"),("t","top"),("r","right"),("b","bottom"))}
            if kind == "chart":
                chart = chart_node
                cp = pkg.resolve(owner_part,pkg.rels(owner_part).get(chart.get("{"+NS["r"]+"}id")))
                cr = pkg.xml(cp)
                is_extended = "chartex" in chart.tag.lower()
                e["chart_spec"] = {"types": sorted({tag(n) for n in cr.iter() if tag(n).endswith("Chart")}) if cr is not None else [],
                                   "namespace_family":"chartEx" if is_extended else "drawingml_chart",
                                   "requires_new_data":True,"original_values_excluded":True}
                if is_extended:
                    e["chart_spec"]["requires_rebuild"] = True
                    e["warnings"].append("extended_chart_requires_native_rebuild")
            if kind == "table":
                table = node.find(".//a:tbl",NS)
                e["table_spec"] = distill_table(table,pkg,presentation,theme)
                e["warnings"].extend(e["table_spec"]["warnings"])
            if kind == "embedded": e["warnings"].append("embedded_object_requires_rebuild")
            if node.find(".//a:effectLst",NS) is not None or node.find(".//a:effectDag",NS) is not None:
                e["warnings"].append("effects_not_reconstructed")
            out["elements"].append(e)

    if root.get("showMasterSp", "1") not in ("0","false"):
        for r, owner, origin in ((master,mp,"master"),(layout,lp,"layout")):
            tree = r.find("p:cSld/p:spTree",NS) if r is not None else None
            if tree is not None: visit(tree,owner,origin)
    tree = root.find("p:cSld/p:spTree",NS)
    if tree is not None: visit(tree,part,"slide")
    out["layout_summary"] = layout_summary(out["elements"])
    if not any(e["kind"] == "text" for e in out["elements"]):
        out["warnings"].append("no_editable_text_design_recovered")
    out["warnings"] = sorted(set(out["warnings"]))
    return out


def distill_file(path, source_hash=None):
    source_hash = source_hash or sha_file(path)
    pkg = Package(path)
    try:
        pres = pkg.xml("ppt/presentation.xml")
        if pres is None: raise ValueError("missing_presentation")
        rels = pkg.rels("ppt/presentation.xml")
        pages = pres.findall("p:sldIdLst/p:sldId",NS)
        if not pages: raise ValueError("no_slides")
        for num, sid in enumerate(pages,1):
            part = pkg.resolve("ppt/presentation.xml",rels.get(sid.get("{"+NS["r"]+"}id")))
            if not part: raise ValueError("invalid_slide_relationship")
            try:
                yield distill_slide(pkg,part,num,source_hash,pres)
            except Exception as exc:
                yield {"schema_version":1,"design_id":source_hash[:16]+f"-p{num:04d}",
                       "source_sha256":source_hash,"source_page":num,"validation_status":"extraction_failed",
                       "error_type":type(exc).__name__}
    finally:
        pkg.close()


def distill_library(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    if not root.is_dir(): raise ValueError("Input directory does not exist")
    if root == output or root in output.parents:
        raise ValueError("Output must be outside the input library")
    if output.exists() and any(output.iterdir()):
        raise ValueError("Output must be new or empty to prevent mixing releases")
    output.mkdir(parents=True,exist_ok=True)
    files = sorted((p for p in root.rglob("*") if p.is_file()),key=lambda p:str(p).casefold())
    manifest = {"schema_version":1,"method":"full_slide_ooxml_structural_distillation","visual_validation":"not_performed",
                "content_privacy":"no_original_text_paths_images_font_binaries_or_chart_values",
                "limitations":LIMITATIONS,"input_extension_counts":dict(Counter(p.suffix.lower() or "<none>" for p in files)),
                "sources":[],"slide_records":0,"duplicate_source_files":0,"failed_sources":0,"unsupported_sources":0,
                "failed_slide_records":0,"source_package_integrity":"full_zip_crc_test"}
    seen = {}
    with (output/"recipes.jsonl").open("w",encoding="utf-8",newline="\n") as f:
        for p in files:
            ext = p.suffix.lower()
            if ext not in (".pptx",".potx",".pptm",".potm",".ppt",".pot"): continue
            sh = sha_file(p)
            if sh in seen:
                seen[sh]["occurrences"] += 1
                manifest["duplicate_source_files"] += 1
                continue
            source = {"source_sha256":sh,"format":ext,"occurrences":1,"status":"pending","slides":0,
                      "macros_executed":False}
            seen[sh]=source
            manifest["sources"].append(source)
            if ext in (".ppt",".pot"):
                source["status"]="unsupported_legacy_binary_requires_conversion"
                manifest["unsupported_sources"]+=1
                continue
            try:
                with ZipFile(p) as check_zip:
                    bad_part = check_zip.testzip()
                source["package_integrity"] = "crc_failed" if bad_part else "crc_passed"
            except Exception as exc:
                source["package_integrity"] = "zip_integrity_error"
                source["integrity_error_type"] = type(exc).__name__
            try:
                source["failed_pages"] = []
                for slide in distill_file(p,sh):
                    if slide["validation_status"] == "extraction_failed":
                        source["failed_pages"].append({"page":slide["source_page"],"error_type":slide["error_type"]})
                        manifest["failed_slide_records"]+=1
                        continue
                    slide["source_package_integrity"] = source["package_integrity"]
                    f.write(json.dumps(slide,ensure_ascii=False,separators=(",", ":"))+"\n")
                    source["slides"]+=1
                    manifest["slide_records"]+=1
                source["status"]="structural_only" if source["package_integrity"]=="crc_passed" and not source["failed_pages"] else "partial_integrity_or_page_failure"
                if source["status"]!="structural_only": manifest["failed_sources"]+=1
                if ext in (".pptm",".potm"): source["macro_policy"]="read_ooxml_only_macro_content_excluded"
            except Exception as exc:
                source["status"]="partial_failure" if source["slides"] else "failed"
                source["error_type"]=type(exc).__name__
                manifest["failed_sources"]+=1
    manifest["recipes_sha256"] = sha_file(output/"recipes.jsonl")
    manifest["unique_source_count"] = len(seen)
    manifest["coverage_complete"] = manifest["failed_sources"] == 0 and manifest["unsupported_sources"] == 0
    (output/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    return manifest


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("library")
    p.add_argument("--output",required=True)
    a=p.parse_args()
    result=distill_library(a.library,a.output)
    print(json.dumps({k:v for k,v in result.items() if k not in ("sources","limitations")},ensure_ascii=False,indent=2))
    return 0 if result["coverage_complete"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
