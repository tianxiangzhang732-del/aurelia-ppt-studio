"""Allowlisted local skill archive. Never uploads files or copies raw PPT/assets."""
import argparse
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED
from pptx_inspect import sha, write_json
from recipe_io import open_recipe_text


def package(root, destination, exclude=()):
    root, destination = Path(root).resolve(), Path(destination).resolve()
    if destination.exists():
        raise ValueError('Archive exists; choose a new version/path')
    exact = {'SKILL.md', 'README.md', 'agents/openai.yaml', '.gitignore'}
    rules = {'scripts':{'.py','.mjs'}, 'tests':{'.py','.mjs'}, 'references':{'.md'},
             'design-library':{'.json','.jsonl'}, 'examples':{'.json'}}
    selected = []
    for path in root.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root)
        if relative.as_posix() in set(exclude):
            continue
        allowed = relative.as_posix() in exact or (len(relative.parts) == 2 and
            relative.parts[0] in rules and (path.suffix in rules[relative.parts[0]] or
            (relative.parts[0] == 'design-library' and path.name.endswith('.jsonl.gz'))))
        if not allowed or path.name.startswith('private-') or '__pycache__' in relative.parts:
            continue
        if relative.parts[0] in ('design-library','examples'):
            with open_recipe_text(path) as lines:
                for text in lines:
                    if re.search(r'[A-Za-z]:[\\/]|/Users/|/home/|"source_path"|"original_text"',text):
                        raise ValueError(f'Private path/content marker in portable library: {relative}')
        selected.append((relative,path))
    if not (root/'SKILL.md').is_file() or not selected:
        raise ValueError('Not a skill directory')
    destination.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(destination,'x',compression=ZIP_DEFLATED,compresslevel=9) as archive:
        for relative,path in sorted(selected):
            archive.write(path, root.name + '/' + relative.as_posix())
    with ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive integrity check failed')
    report = {'archive_sha256':sha(destination),'file_count':len(selected),
              'files':[{'path':r.as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for r,p in sorted(selected)],
              'raw_templates_included':False,'uploaded':False}
    write_json(destination.with_suffix('.manifest.json'),report)
    return report


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skill',required=True); parser.add_argument('--output',required=True)
    parser.add_argument('--exclude',action='append',default=[],help='Exact relative path to omit from a versioned distribution')
    args=parser.parse_args()
    report=package(args.skill,args.output,args.exclude)
    print({'files':report['file_count'],'sha256':report['archive_sha256']})
