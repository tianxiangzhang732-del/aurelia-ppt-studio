# Content workflow

## Brief before graphics

Capture audience, use (spoken presentation vs reading copy), objective, N total pages, source boundary, density and mandatory topics. Infer reasonable defaults and disclose them. Ask only about a choice that materially changes the deck. Detailed decks need substantive evidence on content pages, not hollow agendas or repeated slogans. Notes may hold overflow detail but not replace essential slide findings.

## Source ledger

For each source record a local snapshot, SHA-256, title and page count. A website needs actual text/images, not just a title/link. Use the PDF skill when reading PDFs. Extract every page, then visually inspect image-heavy pages and tables. Verify OCR signs, decimals, percentages and units. Do not reconstruct unseen paywalled material from a headline.

Assign evidence IDs. Each record contains `source_id`, `page` (1-based), `locator`, `claim`, `kind` (fact / calculation / interpretation / assumption), and caveats. Calculations include inputs, units, formula and rounding. Interpretation is not a quotation. Clinical claims preserve population, phase, comparator, endpoint, follow-up, uncertainty and maturity; projections retain scenario, time and currency. Risks affecting interpretation are mandatory topics.

## Translate into slides

Build a storyboard, not a fixed outline copied from the last task. Each page answers a real audience question. Select the visual owner by relationship: trend uses a chart; alternatives use a comparison; architecture uses layers; handoffs use a process; chronology uses a timeline; tradeoffs use a matrix. Use prose when clearer. Topic titles suit explanation; supported takeaways suit findings. Never force a slogan into every title.

Record each page's `title`, detailed `body`, evidence IDs, `purpose`, `layout_family`, `visual_owner`, `required_terms` (names/figures that must stay visible), `notes`, and `caveats`. Required terms are a mechanical omission check, not semantic review. Map every mandatory topic to actual slide numbers. Explain excluded source sections, especially risks and contradictory results.

Keep source facts, research and suggestions distinguishable. Do not invent market sizes, companies, study results or ROI to make a chart attractive. If a source is image-based, read the images before claiming complete extraction.
