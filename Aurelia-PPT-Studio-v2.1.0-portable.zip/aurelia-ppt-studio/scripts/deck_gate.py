"""Evidence-bound PPT delivery gate. All write targets stay inside the job directory."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import uuid
import zlib
from pptx_inspect import sha, digest, write_json, inspect, compare
from recipe_io import open_recipe_text


class GateError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise GateError(message)


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def local(root, value):
    path = (root / value).resolve()
    need(path.is_relative_to(root.resolve()), f'Write/build path outside job: {value}')
    return path


def bind(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha(path)}


def verified(record):
    path = Path(record['path'])
    need(path.is_file(), f'Missing artifact: {path.name}')
    need(sha(path) == record['sha256'], f'Stale artifact: {path.name}')
    return path


def png_size(path):
    need(Path(path).stat().st_size <= 128*1024*1024, 'PNG exceeds inspection size limit')
    data = Path(path).read_bytes()
    need(data[:8] == b'\x89PNG\r\n\x1a\n', f'Not a PNG: {path}')
    offset, chunks, compressed = 8, [], bytearray()
    header = None
    while offset < len(data):
        need(offset+12 <= len(data), 'Truncated PNG chunk')
        size = struct.unpack('>I',data[offset:offset+4])[0]
        kind = data[offset+4:offset+8]
        end = offset+12+size
        need(end <= len(data), 'Truncated PNG payload')
        payload = data[offset+8:offset+8+size]
        crc = struct.unpack('>I',data[offset+8+size:end])[0]
        need(zlib.crc32(kind+payload) & 0xffffffff == crc, 'Invalid PNG chunk CRC')
        if kind == b'IHDR':
            need(not chunks and size == 13, 'Invalid/duplicate PNG IHDR')
            header = struct.unpack('>IIBBBBB',payload)
        if kind == b'IDAT':
            compressed.extend(payload)
        chunks.append(kind); offset = end
        if kind == b'IEND':
            need(size == 0 and end == len(data), 'Invalid PNG IEND/trailing data')
            break
    need(header and chunks[-1] == b'IEND' and compressed, 'PNG missing pixels/IEND')
    width,height,depth,mode,compression,filter_method,interlace = header
    valid_depths = {0:(1,2,4,8,16),2:(8,16),3:(1,2,4,8),4:(8,16),6:(8,16)}
    need(mode in valid_depths and depth in valid_depths[mode], 'Invalid PNG color type/depth')
    need(width > 0 and height > 0 and compression == 0 and filter_method == 0 and interlace in (0,1), 'Invalid PNG header')
    need(mode != 3 or b'PLTE' in chunks, 'Indexed PNG has no palette')
    channels = {0:1,2:3,3:1,4:2,6:4}[mode]
    passes = [(0,0,1,1)] if interlace == 0 else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    rows = []
    for x,y,dx,dy in passes:
        w = max(0,(width-x+dx-1)//dx); h = max(0,(height-y+dy-1)//dy)
        if w and h:
            rows.append((((w*channels*depth+7)//8)+1,h))
    expected = sum(length*count for length,count in rows)
    need(expected <= 128*1024*1024, 'PNG decompressed pixels exceed limit')
    decoder = zlib.decompressobj()
    raw = decoder.decompress(compressed,expected+1)
    need(len(raw) == expected and decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail,
         'Invalid/truncated PNG pixel stream')
    pos = 0
    for length,count in rows:
        for _ in range(count):
            need(raw[pos] <= 4, 'Invalid PNG row filter'); pos += length
    return width,height


def check_render(record, deck):
    manifest = load(verified(record))
    need(manifest['candidate_sha256'] == sha(deck), 'Render does not belong to current deck')
    count = inspect(deck)['slide_count']
    pages = manifest['slides']
    need([p['slide'] for p in pages] == list(range(1, count+1)), 'Incomplete/duplicate/out-of-order rendered slides')
    folder = Path(manifest['directory']).resolve()
    expected = {Path(p['path']).resolve() for p in pages}
    need(expected == set(folder.glob('*.png')), 'Render folder contains missing or unrelated PNGs')
    for page in pages:
        path = verified(page)
        need(path.resolve().parent == folder, 'Rendered slide is outside its render directory')
        width, height = png_size(path)
        need(width >= 960 and height >= 400, 'Preview too small for full-page review')
    return manifest


def check_board(root, job):
    board = load(root / 'board.json')
    need(board['design_round'] == job['design_round'], 'Style board belongs to another design round')
    options = board['options']
    need(len(options) in (6, 7), 'Need 6–7 visual options')
    need(len({str(o['id']) for o in options}) == len(options), 'Duplicate style option IDs')
    corpus = Path(job['corpus_root']).resolve() if job.get('corpus_root') else None
    library_path = verified(job['recipe_library']) if job.get('recipe_library') else None
    need((corpus and corpus.is_dir()) or library_path, 'Approved corpus or packaged design library unavailable')
    recipes = None
    signatures, content_signatures = [], []
    for option in options:
        reference = verified(option['reference'])
        if option.get('design_id'):
            need(library_path and reference.resolve() == library_path.resolve(), 'Recipe reference is not the approved portable library')
            if recipes is None:
                recipes = {}
                wanted = {o.get('design_id') for o in options}
                with open_recipe_text(library_path) as lines:
                    for line in lines:
                        match = re.search(r'"design_id"\s*:\s*"([^"]+)"',line)
                        if match and match[1] in wanted:
                            r = json.loads(line); recipes[r['design_id']] = r
            need(option['design_id'] in recipes, 'Unknown portable recipe ID')
            recipe = recipes[option['design_id']]
            need(re.fullmatch(r'[0-9a-fA-F]{64}', str(recipe.get('source_sha256', ''))) is not None
                 and type(recipe.get('source_page')) is int and recipe['source_page'] > 0,
                 'Recipe lacks valid corpus provenance')
            need(option.get('reference_validation_note'), 'Disclose structural-only/reference-review status in the style board')
        else:
            need(corpus and reference.resolve().is_relative_to(corpus), 'Style reference is outside the approved corpus')
            refinfo = inspect(reference)
            need(option.get('reference_pages') and all(isinstance(p, int) and 1 <= p <= refinfo['slide_count']
                 for p in option['reference_pages']), 'Style reference page is invalid')
        sample = verified(option['sample'])
        info = inspect(sample)
        need(info['slide_count'] >= 2, 'Each style needs a cover and a substantive content page')
        check_render(option['render'], sample)
        need(option.get('name') and option.get('design_notes'), 'Missing style design rationale')
        signatures.append(tuple(s['geometry_hash'] for s in info['slides']))
        content_signatures.append(tuple(s['geometry_hash'] for s in info['slides'][1:]))
    need(len(set(signatures)) == len(signatures), 'Style options repeat the same silhouettes; recoloring is not a new style')
    need(len(set(content_signatures)) == len(content_signatures), 'Style options differ only in the cover; substantive pages repeat')
    return board


def check_selection(root, job):
    board = check_board(root, job)
    selection = load(root / 'selection.json')
    need(selection['design_round'] == job['design_round'], 'Style selection belongs to a previous round')
    need(selection['board_sha256'] == sha(root / 'board.json'), 'Board changed after style selection')
    need(selection['option'] in [str(o['id']) for o in board['options']], 'Unknown selected style')
    need(len(selection.get('user_quote', '').strip()) >= 1, 'Missing actual user style reply')
    need(selection.get('board_shown_to_user') is True, 'Visual board was not shown to the user')
    return selection


def check_design(root, job):
    selection = check_selection(root, job)
    tokens = job.get('design_tokens', {})
    need(tokens.get('option') == selection['option'], 'Design system does not match selected option')
    for key in ('fonts', 'palette', 'layout_vocabulary'):
        need(tokens.get(key), f'Design system lacks {key}')
    option = next(o for o in load(root / 'board.json')['options'] if str(o['id']) == selection['option'])
    pilot = tokens.get('pilot_review', {})
    need(pilot.get('render_sha256') == option['render']['sha256'], 'Selected sample has no current pilot review')
    need(len(pilot.get('observation', '').strip()) >= 20, 'Pilot needs a specific readability/style observation')


def check_content(job, deck):
    brief = job['brief']
    for key in ('audience', 'objective', 'density'):
        need(bool(str(brief.get(key, '')).strip()), f'Missing brief: {key}')
    need(job['sources'], 'No verified content sources')
    source_map = {s['id']: s for s in job['sources']}
    need(len(source_map) == len(job['sources']), 'Duplicate source IDs')
    for src in source_map.values():
        verified(src)
        need(isinstance(src.get('pages'), int) and src['pages'] > 0, 'Invalid source page count')
    evidence = {e['id']: e for e in job['evidence']}
    need(evidence and len(evidence) == len(job['evidence']), 'Missing/duplicate evidence IDs')
    for item in evidence.values():
        need(item['source_id'] in source_map, 'Unknown evidence source')
        need(isinstance(item['page'], int) and 1 <= item['page'] <= source_map[item['source_id']]['pages'],
             f'Invalid evidence page: {item["id"]}')
        need(item.get('claim') and item.get('locator'), 'Evidence needs claim and exact locator')
        need(item.get('kind') in ('fact','calculation','interpretation','assumption'), 'Unknown evidence kind')
        if item['kind'] == 'calculation':
            need(item.get('formula') and item.get('inputs'), 'Calculation lacks inputs/formula')
    slides = job['storyboard']
    n = brief['slide_count']
    need(deck['slide_count'] == n, f'Expected {n} pages; actual {deck["slide_count"]}')
    need([s['slide'] for s in slides] == list(range(1, n+1)), 'Storyboard must cover every page exactly once')
    normalize = lambda t: re.sub(r'\s+', '', str(t)).casefold()
    for plan, actual in zip(slides, deck['slides']):
        for key in ('title', 'purpose', 'body', 'layout_family', 'visual_owner'):
            need(plan.get(key), f'Slide {plan["slide"]} lacks {key}')
        ids = plan.get('evidence_ids', [])
        if plan['purpose'] not in ('cover', 'section', 'closing'):
            need(ids and plan.get('required_terms'), f'Slide {plan["slide"]} lacks evidence/visible key content')
        visible = normalize(''.join(actual['paragraphs']))
        notes = ''.join(actual['notes'])
        for term in plan.get('required_terms', []):
            need(normalize(term) in visible, f'Slide {plan["slide"]} omits required content: {term}')
        for eid in ids:
            need(eid in evidence, f'Unknown evidence: {eid}')
            item = evidence[eid]
            citation = re.escape(f'{item["source_id"]}:p{item["page"]}')
            need(re.search(r'(?<![\w-])' + citation + r'(?!\d)', notes) is not None,
                 f'Slide {plan["slide"]} lacks source locator in notes')
        owner = plan['visual_owner']
        if owner in ('table', 'chart'):
            need(actual[f'{owner}_count'] > 0, f'Slide {plan["slide"]} lacks editable {owner}')
        if owner == 'diagram':
            need(sum(e['kind'] in ('sp','text','cxnSp','grpSp') for e in actual['elements']) >= 2,
                 f'Slide {plan["slide"]} lacks native diagram objects')
    need(job['required_topics'], 'No must-cover topics specified')
    for topic in job['required_topics']:
        need(topic.get('topic') and topic.get('slides') and all(1 <= p <= n for p in topic['slides']),
             'Mandatory topic has no valid slide mapping')


def check_engine(record, candidate):
    receipt = load(verified(record))
    need(receipt.get('schemaVersion') == 'presentation-finalization.v1', 'Unsupported/missing engine finalization receipt')
    need(receipt.get('finalSha256') == sha(candidate), 'Engine validated a different candidate')
    for key in ('packageIntegrity', 'presentationLayout'):
        report = receipt.get(key, {})
        need(report.get('exitCode') == 0 and report.get('findingCount') == 0,
             f'Engine check not passed: {key}')
    need(receipt.get('firstPartyImport', {}).get('passed') is True, 'Engine import check not passed')


def snapshot(root, job):
    # Read current bytes, not self-reported historic hashes.
    files = [root / 'job.json', root / 'board.json', root / 'selection.json']
    for record in job['sources'] + [job['candidate'], job['builder'], job['engine_receipt'], job['render']]:
        files.append(verified(record))
    board = load(root / 'board.json')
    for option in board['options']:
        for key in ('reference', 'sample', 'render'):
            files.append(verified(option[key]))
        files.extend(verified(p) for p in load(option['render']['path'])['slides'])
    files.extend(verified(p) for p in load(job['render']['path'])['slides'])
    return digest(sorted((str(p.resolve()), sha(p)) for p in files))


def validate(root, include_review=True):
    root = Path(root).resolve()
    errors, info = [], None
    try:
        job = load(root / 'job.json')
        need(job.get('schema') == 'aurelia-job-v2', 'Unknown job schema')
    except Exception as exc:
        return {'passed': False, 'errors': [str(exc)]}
    def run(label, fn):
        try:
            return fn()
        except Exception as exc:
            errors.append(f'{label}: {exc}')
    candidate = run('candidate', lambda: verified(job['candidate']))
    run('builder', lambda: verified(job['builder']))
    if candidate:
        run('candidate location', lambda: need(candidate.resolve().is_relative_to(root), 'Candidate outside job'))
        info = run('PPTX', lambda: inspect(candidate))
        run('engine', lambda: check_engine(job['engine_receipt'], candidate))
        run('renders', lambda: check_render(job['render'], candidate))
    run('style', lambda: check_selection(root, job))
    run('design system', lambda: check_design(root, job))
    if info:
        run('content', lambda: check_content(job, info))
    stamp = run('snapshot', lambda: snapshot(root, job))
    signals = info['signals'] if info else []
    if job.get('previous_candidate') and candidate:
        diff = run('revision comparison', lambda: compare(verified(job['previous_candidate']), candidate))
        if diff and job.get('mode') == 'redesign' and len(diff['same_geometry_pages']) >= .8 * max(diff['compared_slides'], 1):
            signals.append({'id':'redesign-same-geometry', 'kind':'redesign_mostly_unchanged'})
    if include_review:
        def reviews():
            review = load(root / 'review.json')
            need(review['snapshot'] == stamp, 'Review is stale after job/artifact changes')
            need(review.get('reviewer'), 'Reviewer identity missing')
            need(review.get('review_method') in ('agent-self-review','human','independent-agent'), 'Disclose actual review method')
            for key in ('coverage','factual_accuracy','design_fidelity','editability'):
                need(review.get(key) is True, f'Review unfinished: {key}')
            need(not any(x.get('status') != 'resolved' for x in review.get('issues', [])), 'Unresolved review issues')
            pages = load(job['render']['path'])['slides']
            rows = review.get('slides', [])
            need([r['slide'] for r in rows] == [p['slide'] for p in pages], 'Missing/duplicate slide reviews')
            for row, page in zip(rows, pages):
                need(row.get('image_sha256') == page['sha256'], 'Reviewed a different PNG')
                for key in ('content','style','readability'):
                    need(len(row.get(key, '').strip()) >= 12, f'Slide {row["slide"]}: missing specific {key} observation')
            dispositions = review.get('signal_dispositions', {})
            for signal in signals:
                need(len(dispositions.get(signal['id'], '').strip()) >= 16,
                     f'Unreviewed inspector signal: {signal["id"]}')
        run('review', reviews)
    return {'passed': not errors, 'errors': errors, 'signals': signals, 'snapshot': stamp,
            'candidate_sha256': info['sha256'] if info else None, 'checked_at': timestamp()}


def render_deck(deck, out, node, renderer, modules):
    need(not out.exists(), 'Render destination already exists; use a fresh directory')
    out.mkdir(parents=True)
    env = dict(os.environ, RUNTIME_NODE=str(node), RUNTIME_NODE_MODULES=str(modules))
    command = [str(node), str(renderer), '--input', str(deck), '--output_dir', str(out), '--scale', '1.5']
    before = sha(deck)
    result = subprocess.run(command, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=600)
    (out / 'renderer.log').write_text(result.stdout + '\n' + result.stderr, encoding='utf-8')
    need(result.returncode == 0, f'Render failed; inspect {out / "renderer.log"}')
    need(sha(deck) == before, 'Candidate changed during rendering')
    n = inspect(deck)['slide_count']
    pages = []
    for number in range(1, n+1):
        path = out / f'slide-{number}.png'
        width, height = png_size(path)
        pages.append(dict(bind(path), slide=number, width=width, height=height))
    manifest = {'candidate_sha256': before, 'directory': str(out.resolve()), 'slides': pages,
                'renderer': bind(renderer), 'created_at': timestamp()}
    write_json(out / 'render.json', manifest)
    return bind(out / 'render.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', required=True)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('init'); p.add_argument('--pages', type=int, required=True)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument('--corpus'); source.add_argument('--library')
    p = sub.add_parser('add-source'); p.add_argument('--id', required=True); p.add_argument('--file', required=True); p.add_argument('--pages', type=int, required=True)
    p = sub.add_parser('select'); p.add_argument('--option', required=True); p.add_argument('--quote', required=True); p.add_argument('--shown', action='store_true')
    p = sub.add_parser('bind'); p.add_argument('--candidate', required=True); p.add_argument('--builder', required=True); p.add_argument('--receipt', required=True)
    p = sub.add_parser('render'); p.add_argument('--deck', required=True); p.add_argument('--node', required=True); p.add_argument('--renderer', required=True); p.add_argument('--modules', required=True); p.add_argument('--attach', action='store_true')
    sub.add_parser('prepare-review'); sub.add_parser('validate'); sub.add_parser('release')
    args = parser.parse_args()
    root = Path(args.job).resolve()
    if args.command == 'init':
        need(not (root / 'job.json').exists(), 'Existing job is preserved; use a new directory')
        need(args.pages > 0, 'Need positive page count')
        need((args.corpus and Path(args.corpus).is_dir()) or (args.library and Path(args.library).is_file()),
             'Need existing corpus or packaged recipe library')
        write_json(root / 'job.json', {'schema':'aurelia-job-v2','design_round':uuid.uuid4().hex,
            'corpus_root':str(Path(args.corpus).resolve()) if args.corpus else None,
            'recipe_library':bind(args.library) if args.library else None, 'mode':'new',
            'brief':{'slide_count':args.pages,'audience':'','objective':'','density':''},
            'sources':[],'evidence':[],'required_topics':[],'storyboard':[], 'design_tokens':{}})
        return
    job = load(root / 'job.json')
    if args.command == 'add-source':
        need(args.pages > 0 and args.id not in [s['id'] for s in job['sources']], 'Invalid/duplicate source')
        job['sources'].append(dict(bind(args.file), id=args.id, pages=args.pages))
    elif args.command == 'select':
        board = check_board(root, job)
        need(args.shown and args.quote.strip(), 'Display board and obtain actual user reply before selection')
        need(args.option in [str(o['id']) for o in board['options']], 'Unknown option')
        write_json(root / 'selection.json', {'design_round':job['design_round'], 'board_sha256':sha(root / 'board.json'),
            'option':args.option, 'user_quote':args.quote, 'board_shown_to_user':True, 'recorded_at':timestamp()})
        return
    elif args.command == 'bind':
        check_selection(root, job)
        need(job.get('design_tokens'), 'Record the selected visual system before production')
        job['candidate'] = bind(local(root, args.candidate)); job['builder'] = bind(local(root,args.builder))
        job['engine_receipt'] = bind(local(root,args.receipt))
        check_engine(job['engine_receipt'], Path(job['candidate']['path']))
    elif args.command == 'render':
        deck = local(root,args.deck)
        out = local(root, 'renders/' + sha(deck)[:12] + '-' + uuid.uuid4().hex[:8])
        record = render_deck(deck, out, args.node,args.renderer,args.modules)
        print(json.dumps(record))
        if not args.attach:
            return
        need(job.get('candidate', {}).get('sha256') == sha(deck), 'Attach render only to bound candidate')
        job['render'] = record
    elif args.command == 'prepare-review':
        report = validate(root, include_review=False)
        write_json(root / 'pre-review-check.json', report)
        need(report['passed'], '\n'.join(report['errors']))
        need(not (root / 'review.json').exists(), 'Preserve existing review; use a new job/revision or archive it explicitly')
        pages = load(job['render']['path'])['slides']
        write_json(root / 'review.json', {'snapshot': report['snapshot'], 'reviewer':'', 'review_method':'agent-self-review',
            'coverage':False,'factual_accuracy':False,'design_fidelity':False,'editability':False,'issues':[],
            'signal_dispositions': {s['id']:'' for s in report['signals']},
            'slides':[{'slide':p['slide'],'image_sha256':p['sha256'],'content':'','style':'','readability':''} for p in pages]})
        return
    elif args.command in ('validate','release'):
        report = validate(root)
        write_json(root / 'gate-report.json', report)
        print(json.dumps(report, ensure_ascii=False))
        need(report['passed'], 'Delivery blocked; see gate-report.json')
        if args.command == 'release':
            # Exclusive create: no overwrite. Re-read, compare and copy the validated bytes.
            data = verified(job['candidate']).read_bytes()
            import hashlib
            need(hashlib.sha256(data).hexdigest() == report['candidate_sha256'], 'Candidate changed during release')
            destination = local(root, 'released/deck-' + report['candidate_sha256'][:12] + '.pptx')
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(data)
            write_json(destination.with_suffix('.receipt.json'), dict(report, released_file=bind(destination)))
            print(str(destination))
        return
    write_json(root / 'job.json', job)


if __name__ == '__main__':
    try:
        main()
    except (GateError, OSError, KeyError, ValueError, subprocess.SubprocessError) as exc:
        print(f'BLOCKED: {exc}', file=sys.stderr)
        sys.exit(2)
