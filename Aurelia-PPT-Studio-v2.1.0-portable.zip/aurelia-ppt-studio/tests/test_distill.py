"""Synthetic OOXML engineering tests, not aesthetic or renderer validation."""
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
from zipfile import ZipFile

SPEC = importlib.util.spec_from_file_location("distill_designs",Path(__file__).parents[1]/"scripts"/"distill_designs.py")
d = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(d)
NS = 'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
RELS = 'http://schemas.openxmlformats.org/package/2006/relationships'
RT = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/'


def relationships(items):
    return '<Relationships xmlns="'+RELS+'">'+''.join('<Relationship Id="'+i+'" Type="'+RT+t+'" Target="'+p+'"/>' for i,t,p in items)+'</Relationships>'


def shape(text, ph='', xfrm='', fill='', textprops=''):
    return '<p:sp><p:nvSpPr><p:cNvPr id="2" name="SECRET_COMPANY"/><p:cNvSpPr/><p:nvPr>'+ph+'</p:nvPr></p:nvSpPr><p:spPr>'+xfrm+fill+'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr/><a:r>'+textprops+'<a:t>'+text+'</a:t></a:r></a:p></p:txBody></p:sp>'


def fixture(path, body_extra=''):
    ph='<p:ph type="title" idx="1"/>'
    xfrm='<a:xfrm><a:off x="100000" y="50000"/><a:ext cx="500000" cy="200000"/></a:xfrm>'
    parts = {
      'ppt/presentation.xml': '<p:presentation '+NS+'><p:sldIdLst><p:sldId id="257" r:id="s2"/><p:sldId id="256" r:id="s1"/></p:sldIdLst><p:sldSz cx="1000000" cy="562500"/></p:presentation>',
      'ppt/_rels/presentation.xml.rels':relationships([('s1','slide','slides/slide1.xml'),('s2','slide','slides/slide2.xml')]),
      'ppt/slides/slide2.xml':'<p:sld '+NS+'><p:cSld><p:spTree>'+shape('PRIVATE_SOURCE_FIRST',ph=ph)+body_extra+'</p:spTree></p:cSld></p:sld>',
      'ppt/slides/slide1.xml':'<p:sld '+NS+'><p:cSld><p:spTree>'+shape('OTHER_PRIVATE_COPY',xfrm=xfrm,textprops='<a:rPr sz="1200"/>')+'</p:spTree></p:cSld></p:sld>',
      'ppt/slides/_rels/slide2.xml.rels':relationships([('l1','slideLayout','../slideLayouts/slideLayout1.xml'),('im','image','../media/private-brand.png'),('cx','chart','../charts/chartEx1.xml')]),
      'ppt/slides/_rels/slide1.xml.rels':relationships([('l1','slideLayout','../slideLayouts/slideLayout1.xml')]),
      'ppt/slideLayouts/slideLayout1.xml':'<p:sldLayout '+NS+'><p:cSld><p:spTree>'+shape('LAYOUT_ORIGINAL',ph=ph,xfrm=xfrm)+'</p:spTree></p:cSld></p:sldLayout>',
      'ppt/slideLayouts/_rels/slideLayout1.xml.rels':relationships([('m1','slideMaster','../slideMasters/slideMaster1.xml')]),
      'ppt/slideMasters/slideMaster1.xml':'<p:sldMaster '+NS+'><p:cSld><p:bg><p:bgPr><a:solidFill><a:schemeClr val="bg1"/></a:solidFill></p:bgPr></p:bg><p:spTree>'+shape('MASTER_PRIVATE',ph=ph,xfrm=xfrm)+'</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1"/><p:txStyles><p:titleStyle><a:lvl1pPr algn="ctr"><a:defRPr sz="3600" b="1"><a:solidFill><a:schemeClr val="accent1"/></a:solidFill><a:latin typeface="+mj-lt"/><a:ea typeface="Microsoft YaHei"/></a:defRPr></a:lvl1pPr></p:titleStyle></p:txStyles></p:sldMaster>',
      'ppt/slideMasters/_rels/slideMaster1.xml.rels':relationships([('t1','theme','../theme/theme1.xml')]),
      'ppt/theme/theme1.xml':'<a:theme '+NS+'><a:themeElements><a:clrScheme name="PRIVATE_CLIENT"><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk1><a:srgbClr val="111111"/></a:dk1><a:accent1><a:srgbClr val="1277AA"/></a:accent1></a:clrScheme><a:fontScheme name="PRIVATE_CLIENT"><a:majorFont><a:latin typeface="Aptos Display"/><a:ea typeface="Microsoft YaHei"/></a:majorFont><a:minorFont><a:latin typeface="Aptos"/></a:minorFont></a:fontScheme></a:themeElements></a:theme>',
      'ppt/charts/chartEx1.xml':'<cx:chartSpace xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"><cx:chart><cx:plotArea><cx:series layoutId="waterfall"><cx:tx>PRIVATE_CHART_LABEL</cx:tx></cx:series></cx:plotArea></cx:chart></cx:chartSpace>',
      'ppt/media/private-brand.png':b'\x89PNG\r\n\x1a\n'+b'\x00'*8+struct.pack('>II',800,400)
    }
    with ZipFile(path,'w') as z:
        for p,content in parts.items(): z.writestr(p,content)


class DistillTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.base=Path(self.t.name)
        self.file=self.base/'private-company-name.pptx'
        fixture(self.file)

    def tearDown(self): self.t.cleanup()

    def test_resolves_layout_geometry_master_fonts_theme_colors(self):
        slides=list(d.distill_file(self.file))
        self.assertEqual(len(slides),2)
        e=slides[0]['elements'][0]
        self.assertEqual(e['box'],[.1,round(50000/562500,6),.5,round(200000/562500,6)])
        self.assertEqual(e['text_style']['font_size_pt'],36)
        self.assertEqual(e['text_style']['font_latin'],'Aptos Display')
        self.assertEqual(e['text_style']['font_east_asian'],'Microsoft YaHei')
        self.assertEqual(e['text_style']['color']['rgb'],'1277AA')
        self.assertEqual(slides[0]['background']['inheritance_source'],'master')
        self.assertEqual(slides[0]['background']['color']['rgb'],'FFFFFF')

    def test_slide_order_not_filename_order_and_no_source_copy(self):
        slides=list(d.distill_file(self.file))
        self.assertEqual(slides[0]['source_page'],1)
        self.assertEqual(slides[0]['elements'][0]['text_style']['font_size_pt'],36)
        self.assertEqual(slides[1]['elements'][0]['text_style']['font_size_pt'],12)
        raw=json.dumps(slides)
        for secret in ('PRIVATE','SECRET_COMPANY','private-company-name','LAYOUT_ORIGINAL','MASTER_PRIVATE',str(self.base)):
            self.assertNotIn(secret,raw)
        self.assertEqual(slides[0]['source_sha256'],d.sha_file(self.file))
        self.assertTrue(all(s['validation_status']=='structural_only' for s in slides))

    def test_group_transform_is_applied(self):
        group='<p:grpSp><p:grpSpPr><a:xfrm><a:off x="200000" y="100000"/><a:ext cx="400000" cy="200000"/><a:chOff x="0" y="0"/><a:chExt cx="100000" cy="100000"/></a:xfrm></p:grpSpPr>'+shape('PRIVATE_GROUP',xfrm='<a:xfrm><a:off x="0" y="0"/><a:ext cx="50000" cy="50000"/></a:xfrm>')+'</p:grpSp>'
        fixture(self.file,group)
        e=list(d.distill_file(self.file))[0]['elements'][1]
        self.assertEqual(e['box'],[.2,round(100000/562500,6),.2,round(100000/562500,6)])
        self.assertEqual(e['group_matrix_emu'],[4,0,0,2,200000,100000])

    def test_image_dimensions_crop_no_asset_copy(self):
        pic='<p:pic><p:nvPicPr/><p:blipFill><a:blip r:embed="im"/><a:srcRect l="10000" r="20000"/></p:blipFill><p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="400000" cy="200000"/></a:xfrm></p:spPr></p:pic>'
        fixture(self.file,pic)
        e=list(d.distill_file(self.file))[0]['elements'][1]
        self.assertEqual(e['intrinsic_pixels'],[800,400])
        self.assertEqual(e['crop']['left'],.1)
        self.assertTrue(e['requires_asset'] and e['needs_rights'])
        self.assertNotIn('private-brand',json.dumps(e))

    def test_chartex_is_flagged_without_data(self):
        chart='<p:graphicFrame><p:xfrm><a:off x="0" y="0"/><a:ext cx="400000" cy="200000"/></p:xfrm><a:graphic><a:graphicData><cx:chart xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex" r:id="cx"/></a:graphicData></a:graphic></p:graphicFrame>'
        fixture(self.file,chart)
        e=list(d.distill_file(self.file))[0]['elements'][1]
        self.assertEqual(e['kind'],'chart')
        self.assertEqual(e['chart_spec']['namespace_family'],'chartEx')
        self.assertTrue(e['chart_spec']['requires_rebuild'])
        self.assertNotIn('PRIVATE_CHART_LABEL',json.dumps(e))

    def test_full_library_duplicate_unsupported_corrupt_accounting(self):
        lib=self.base/'input'; lib.mkdir()
        (lib/'first.pptx').write_bytes(self.file.read_bytes())
        (lib/'duplicate.potx').write_bytes(self.file.read_bytes())
        (lib/'legacy.ppt').write_bytes(b'legacy')
        (lib/'broken.pptx').write_bytes(b'corrupt')
        out=self.base/'output'
        m=d.distill_library(lib,out)
        self.assertEqual(m['slide_records'],2)
        self.assertEqual(m['duplicate_source_files'],1)
        self.assertEqual(m['unsupported_sources'],1)
        self.assertEqual(m['failed_sources'],1)
        self.assertFalse(m['coverage_complete'])
        self.assertEqual(set(p.name for p in out.iterdir()),{'recipes.jsonl','manifest.json'})
        with self.assertRaises(ValueError): d.distill_library(lib,out)

    def test_color_map_and_transform_explicitness(self):
        theme=d.Theme(None,{'tx1':'dk1'})
        theme.colors={'dk1':'000000'}
        color=theme.color(d.ET.fromstring('<a:solidFill '+NS+'><a:schemeClr val="tx1"><a:tint val="50000"/><a:alpha val="70000"/></a:schemeClr></a:solidFill>'))
        self.assertEqual(color['rgb'],'808080')
        self.assertEqual(color['opacity'],.7)

    def test_empty_text_body_is_not_a_new_copy_slot(self):
        fixture(self.file,shape('',xfrm='<a:xfrm><a:off x="0" y="0"/><a:ext cx="400000" cy="200000"/></a:xfrm>'))
        e=list(d.distill_file(self.file))[0]['elements'][1]
        self.assertEqual(e['kind'],'shape')
        self.assertIsNone(e['text_style'])

    def test_real_theme_fill_reference_resolution(self):
        root=d.ET.fromstring('<a:theme '+NS+'><a:themeElements><a:fmtScheme><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:bgFillStyleLst><a:solidFill><a:srgbClr val="121314"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>')
        theme=d.Theme(root,{})
        ref=d.ET.fromstring('<a:fillRef '+NS+' idx="1"><a:srgbClr val="1277AA"/></a:fillRef>')
        fill=theme.referenced_fill(ref)
        self.assertEqual(fill['color']['rgb'],'1277AA')
        self.assertEqual(fill['resolved_style_index'],1)
        ref.set('idx','0')
        self.assertEqual(theme.referenced_fill(ref)['kind'],'none')
        ref.set('idx','1001')
        self.assertEqual(theme.referenced_fill(ref)['color']['rgb'],'121314')
        ref.set('idx','1009')
        self.assertEqual(theme.referenced_fill(ref)['kind'],'unresolved_theme_fill')


if __name__=='__main__': unittest.main()
