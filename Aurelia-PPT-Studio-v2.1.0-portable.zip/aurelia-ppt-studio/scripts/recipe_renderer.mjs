#!/usr/bin/env node
// Reconstruct supported native objects from distilled geometry and NEW content.
// No built-in page layout, palette, title text, or fallback template.
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import { createGunzip } from 'node:zlib';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

const hash = data => createHash('sha256').update(data).digest('hex');
function need(value, message) { if (!value) throw new Error(message); }
function visibleText(value) { return typeof value === 'string' && /[\p{L}\p{N}\p{P}\p{S}]/u.test(value); }

function checkBindings(recipe, page) {
  const ids=new Set(recipe.elements.map(e=>e.id));
  need(page.bindings && typeof page.bindings==='object' && !Array.isArray(page.bindings),'Explicit bindings object required');
  for(const id of Object.keys(page.bindings)) need(ids.has(id),`Unknown binding ID: ${page.design_id}/${id}`);
  for(const id of page.required_slots ?? []) {
    need(ids.has(id) && Object.hasOwn(page.bindings,id),`Missing required content slot: ${page.design_id}/${id}`);
    const element=recipe.elements.find(e=>e.id===id), binding=page.bindings[id];
    if(element.kind==='chart') checkChart(binding,id);
    else if(element.kind==='table') checkTable(binding,id);
    else if(element.kind==='image') need(binding?.asset && binding.content_type && visibleText(binding.alt),`Missing required image: ${id}`);
    else need(visibleText(typeof binding==='string'?binding:binding?.text),`Empty required content slot: ${id}`);
  }
}

function checkTable(binding, id) {
  const rows=binding?.values;
  need(Array.isArray(rows) && rows.length && rows.every(row=>Array.isArray(row) && row.length===rows[0].length) && rows[0].length,
    `Missing rectangular new table data at ${id}`);
  need(rows.flat().every(v=>typeof v==='string' || (typeof v==='number' && Number.isFinite(v))),`Invalid table cell value at ${id}`);
  need(rows.flat().some(v=>typeof v==='number'||visibleText(v)),`Empty table content at ${id}`);
}

function checkChart(binding,id) {
  need(visibleText(binding?.chart_kind) && Array.isArray(binding?.categories) && binding.categories.length &&
    binding.categories.every(c=>visibleText(c) || (typeof c==='number' && Number.isFinite(c))),`Missing chart categories at ${id}`);
  need(Array.isArray(binding?.series) && binding.series.length && binding.series.every(s=>visibleText(s.name) &&
    Array.isArray(s.values) && s.values.length===binding.categories.length && s.values.every(v=>typeof v==='number' && Number.isFinite(v))),
    `Chart series must name and bind one finite numeric value per category at ${id}`);
}

function checkTextFit(value, position, style, id) {
  const insets=style.insets ?? {};
  const availableWidth=position.width-(insets.left ?? 9.6)-(insets.right ?? 9.6);
  const availableHeight=position.height-(insets.top ?? 4.8)-(insets.bottom ?? 4.8);
  need(availableWidth>0 && availableHeight>0, `Text frame has no usable area: ${id}`);
  const units=t=>Array.from(t).reduce((n,c)=>n+(/\s/.test(c)?.3: /[\u0000-\u00ff]/.test(c)?.55:1),0);
  if(style.wrap==='none') need(value.split(/\r?\n/).every(line=>units(line)*style.fontSize<=availableWidth*1.1),
    `Unwrapped text exceeds estimated frame width at ${id}; shorten content, do not silently wrap`);
  const rows=value.split(/\r?\n/).reduce((n,line)=>n+Math.max(1,Math.ceil(units(line)*style.fontSize/availableWidth)),0);
  // Conservative signal, not font metrics. Never shrink typography silently.
  need(rows*style.fontSize*1.05<=availableHeight*1.1,
    `New text exceeds estimated frame capacity at ${id}; shorten/restructure content, then render and inspect`);
}

function color(spec) {
  need(spec?.rgb && /^[0-9a-f]{6}$/i.test(spec.rgb), 'Unresolved source color; provide a validated recipe');
  const alpha = spec.alpha ?? spec.opacity;
  return '#' + spec.rgb + (alpha === undefined ? '' : '/' + Math.round(alpha <= 1 ? alpha * 100 : alpha));
}

function fill(spec) {
  need(!spec || !Object.hasOwn(spec,'unresolved_theme_fill_style'), 'Unresolved theme fill cannot be flattened to solid');
  if (!spec || spec.kind === 'none') return 'none';
  if (spec.kind === 'solid') return color(spec.color);
  if (spec.kind === 'gradient' && spec.stops?.length >= 2) {
    need(spec.angle_degrees !== null, 'Path gradient needs a faithful adapter; linear fallback is forbidden');
    return {type:'gradient', gradientKind:'linear', angleDeg:spec.angle_degrees ?? 0,
      stops:spec.stops.map(s => ({offset:s.position !== undefined ? Math.round(s.position*100000) : s.offset, color:color(s.color)}))};
  }
  throw new Error(`Unsupported source fill: ${spec.kind}; do not silently simplify`);
}

async function moduleFromRuntime() {
  const root = process.env.RUNTIME_NODE_MODULES;
  need(root && path.isAbsolute(root), 'Set RUNTIME_NODE_MODULES from the workspace dependency loader');
  const packageDir = path.join(root,'@oai','artifact-tool');
  const pkg = JSON.parse(await fs.readFile(path.join(packageDir,'package.json'),'utf8'));
  const exported = pkg.exports?.['.'];
  need(typeof exported === 'string', 'Unsupported artifact-tool entrypoint; consult current engine docs');
  return import(pathToFileURL(path.join(packageDir,exported)).href);
}

export async function build(libraryPath, requestPath, outputDir) {
  const requestBytes = await fs.readFile(requestPath);
  const request = JSON.parse(requestBytes.toString('utf8'));
  need(request.schema === 'aurelia-build-v1' && ['draft','validation'].includes(request.purpose), 'Explicit draft/validation build request required');
  need(request.pages?.length, 'No requested pages');
  const wanted = new Set(request.pages.map(p=>p.design_id));
  const recipes = new Map();
  const libraryHasher=createHash('sha256');
  for await (const block of createReadStream(libraryPath)) libraryHasher.update(block);
  const libraryHash=libraryHasher.digest('hex');
  const source=createReadStream(libraryPath);
  const input=libraryPath.toLowerCase().endsWith('.gz') ? source.pipe(createGunzip()) : source;
  if(input!==source) source.on('error',error=>input.destroy(error));
  const lines=createInterface({input,crlfDelay:Infinity});
  for await (const line of lines) {
    const match=line.match(/"design_id"\s*:\s*"([^"]+)"/);
    if(match && wanted.has(match[1])) {const r=JSON.parse(line);recipes.set(r.design_id,r);}
  }
  const first = recipes.get(request.pages[0].design_id);
  need(first, 'Unknown design ID');
  const width = first.canvas.width_emu / 9525;
  const height = first.canvas.height_emu / 9525;
  const {Presentation,PresentationFile} = await moduleFromRuntime();
  const presentation = Presentation.create({slideSize:{width,height}});
  const warnings = [], used = [];
  for (const [index,page] of request.pages.entries()) {
    const recipe = recipes.get(page.design_id);
    need(recipe, `Unknown recipe: ${page.design_id}`);
    need(recipe.elements?.length && recipe.validation_status !== 'extraction_failed', `Recipe has no recovered design: ${page.design_id}`);
    checkBindings(recipe,page);
    need(recipe.canvas.width_emu === first.canvas.width_emu && recipe.canvas.height_emu === first.canvas.height_emu,
      'Mixed canvas sizes need an explicit adapted recipe; stretching silently is forbidden');
    const slide = presentation.slides.add();
    warnings.push(...(recipe.warnings ?? []).map(w=>`${page.design_id}: ${w}`));
    const bg = recipe.background;
    if (bg?.kind === 'image') {
      need(page.background_asset?.path && page.background_asset.content_type && page.background_asset.alt,
        `Slide ${index+1} needs a rights-cleared background image with MIME and alt text`);
      const bytes = await fs.readFile(path.resolve(path.dirname(requestPath),page.background_asset.path));
      slide.images.add({blob:bytes,contentType:page.background_asset.content_type,alt:page.background_asset.alt,
        position:{left:0,top:0,width,height},fit:'cover'});
    } else slide.background.fill = fill(bg);
    for (const element of recipe.elements) {
      need(element.box?.length === 4, `Missing geometry: ${page.design_id}/${element.id}`);
      const [x,y,w,h] = element.box;
      need(!(element.rotation_degrees ?? 0), `Rotated AABB needs transform-aware adapter: ${page.design_id}/${element.id}`);
      const matrix = element.group_matrix_emu;
      need(!matrix || (Math.abs(matrix[1]) < 1e-8 && Math.abs(matrix[2]) < 1e-8 && matrix[0] > 0 && matrix[3] > 0),
        `Rotated/mirrored group needs a transform-aware adapter: ${page.design_id}/${element.id}`);
      const position = {left:x*width,top:y*height,width:w*width,height:h*height,
        horizontalFlip:!!element.flip_horizontal,verticalFlip:!!element.flip_vertical};
      const binding = page.bindings?.[element.id];
      const id = `${page.design_id}/${element.id}`;
      const kind = element.kind;
      const style = {...element.text_style, ...(typeof binding === 'object' ? binding?.text_style : {})};
      const textStyle = (value='', effectiveStyle=style) => {
        const style=effectiveStyle;
        const requested = /[^\u0000-\u00ff]/.test(String(value)) ? style.font_east_asian || style.font_latin : style.font_latin || style.font_east_asian;
        const family = request.font_substitutions?.[requested] || requested;
        need(family && !family.startsWith('+'), `Unresolved font at ${id}; bind a tested font substitution`);
        need(style.font_size_pt > 0, `Unresolved font size at ${id}`);
        need(!style.vertical_mode || style.vertical_mode === 'horz', `Vertical text needs a faithful adapter: ${id}`);
        const rawInsets=style.insets_emu ?? {};
        const insets=Object.fromEntries(Object.entries({left:'lIns',top:'tIns',right:'rIns',bottom:'bIns'})
          .filter(([,key])=>rawInsets[key] !== undefined).map(([name,key])=>[name,rawInsets[key]/9525]));
        return {typeface:family,fontSize:style.font_size_pt*4/3,bold:!!style.bold,
          italic:!!style.italic,color:color(style.color),autoFit:'none',
          ...(['none','square'].includes(style.wrap) ? {wrap:style.wrap} : {}),
          ...(Object.keys(insets).length ? {insets} : {}),
          alignment:({l:'left',ctr:'center',r:'right',just:'justify'})[style.alignment] ?? 'left',
          verticalAlignment:({t:'top',ctr:'middle',b:'bottom'})[style.vertical_anchor] ?? 'top'};
      };
      if (kind === 'image') {
        need(binding?.asset && binding.content_type && binding.alt, `Missing new image binding/alt at ${id}`);
        const bytes = await fs.readFile(path.resolve(path.dirname(requestPath),binding.asset));
        const image=slide.images.add({blob:bytes,contentType:binding.content_type,alt:binding.alt,
          position:{left:position.left,top:position.top,width:position.width,height:position.height},
          fit:'cover',crop:element.crop,geometry:element.geometry?.preset || 'rect'});
        image.flipHorizontal=!!element.flip_horizontal;
        image.flipVertical=!!element.flip_vertical;
      } else if (kind === 'table') {
        checkTable(binding,id);
        const spec=element.table_spec ?? {};
        const rowCount=binding.values.length, columnCount=binding.values[0].length;
        need(!spec.column_widths_emu || spec.column_widths_emu.length===columnCount,`Table column count changes require an explicit adapted recipe: ${id}`);
        need(!spec.row_heights_emu || spec.row_heights_emu.length===rowCount,`Table row count changes require an explicit adapted recipe: ${id}`);
        const totalWidth=(spec.column_widths_emu ?? []).reduce((a,b)=>a+b,0);
        const totalHeight=(spec.row_heights_emu ?? []).reduce((a,b)=>a+b,0);
        const table = slide.tables.add({rows:binding.values.length,columns:binding.values[0].length,
          left:position.left,top:position.top,width:position.width,height:position.height,values:binding.values,
          ...(totalWidth?{columnWidths:spec.column_widths_emu.map(w=>w/totalWidth*position.width)}:{})});
        if(totalHeight) spec.row_heights_emu.forEach((h,r)=>{table.rows[r].height=h/totalHeight*position.height;});
        for(const merged of spec.merge_regions ?? []) {
          table.merge({startRow:merged.start_row,endRow:merged.end_row,startColumn:merged.start_column,endColumn:merged.end_column});
        }
        for(let r=0;r<rowCount;r++) for(let c=0;c<columnCount;c++) {
          const sourceCell=spec.cells?.find(cell=>cell.row===r&&cell.column===c);
          if(sourceCell?.is_merge_continuation) continue;
          const target=table.getCell(r,c);
          const ts=textStyle(binding.values[r][c],{...style,...sourceCell?.text_style});
          target.text.style=ts;
          if(sourceCell?.fill) target.fill=fill(sourceCell.fill);
          const borders={};
          for(const [side,line] of Object.entries(sourceCell?.borders ?? {})) {
            if(!['left','right','top','bottom'].includes(side)) {
              if(line.fill?.kind!=='none')warnings.push(`${id}/${r}/${c}: unsupported table border ${side}`);
              continue;
            }
            // Explicit transparency avoids the engine retaining a default grid when zero-width/noFill is omitted.
            borders[side]={fill:line.fill?.kind==='none'?'#000000/0':fill(line.fill),width:line.fill?.kind==='none'?1:(line.width_pt ?? 0)*4/3,
              style:({solid:'solid',dash:'dashed',dot:'dotted',dashDot:'dash-dot'})[line.dash] ?? 'solid'};
          }
          const margins=Object.fromEntries(Object.entries(sourceCell?.margins_emu ?? {}).map(([side,n])=>[side,n/9525]));
          table.cells.block({row:r,column:c,rowCount:1,columnCount:1}).assign({
            ...(Object.keys(borders).length?{borders}:{}),...(Object.keys(margins).length?{margins}:{})});
          warnings.push(...(sourceCell?.warnings ?? []).map(w=>`${id}/${r}/${c}: ${w}`));
        }
        warnings.push(...(spec.warnings ?? []).map(w=>`${id}: ${w}`));
        warnings.push(`${id}: native table rebuilt; visually verify cell inheritance, merges, borders and new data fit`);
        if(!spec.cells?.length) warnings.push(`${id}: cell styles missing in recipe; source-faithful table styling is NOT established`);
      } else if (kind === 'chart') {
        checkChart(binding,id);
        slide.charts.add(binding.chart_kind,{...binding.options,position,categories:binding.categories,series:binding.series});
        warnings.push(`${id}: new native chart requires axis/unit/data and template style validation`);
      } else if (['shape','text','connector'].includes(kind)) {
        const geometry = element.geometry?.preset || (kind === 'text' ? 'textbox' : null);
        need(geometry && geometry !== 'custom', `Unsupported custom geometry at ${id}; needs an explicit adapter`);
        const shape = slide.shapes.add({geometry,position,fill:fill(element.fill),
          line:{fill:fill(element.line?.fill),width:(element.line?.width_pt ?? 0)*4/3,
            style:({solid:'solid',dash:'dashed',sysDash:'dashed',dot:'dotted',sysDot:'dotted',dashDot:'dash-dot',lgDash:'dashed',lgDashDot:'dash-dot',lgDashDotDot:'dash-dot-dot',sysDashDot:'dash-dot',sysDashDotDot:'dash-dot-dot'})[element.line?.dash] ?? 'solid'},
          ...(element.geometry?.adjustments ? {adjustmentList:Object.entries(element.geometry.adjustments).map(([name,formula])=>({name,formula:String(formula)}))} : {})});
        if ((element.text_capacity?.character_count ?? 0) > 0 || typeof binding === 'string' || binding?.text !== undefined) {
          const value = typeof binding === 'string' ? binding : binding?.text;
          need(visibleText(value), `Missing visible NEW text binding at ${id}`);
          const ts=textStyle(value);
          checkTextFit(value,position,ts,id);
          shape.text = value;
          shape.text.style = ts;
          if(value.length > Math.max(element.text_capacity?.character_count ?? 0,10)*1.5)
            warnings.push(`${id}: new content exceeds source text capacity; inspect wrapping`);
        }
      } else throw new Error(`Unsupported element kind ${kind} at ${id}`);
      for (const warning of element.warnings ?? []) warnings.push(`${id}: ${warning}`);
    }
    slide.speakerNotes.textFrame.setText(page.notes || '');
    used.push({design_id:page.design_id,source_sha256:recipe.source_sha256,source_page:recipe.source_page,
      validation_status:recipe.validation_status});
  }
  // Never overwrite an existing generation test or candidate.
  await fs.mkdir(outputDir,{recursive:false});
  const candidatePath = path.join(outputDir,'candidate.pptx');
  await (await PresentationFile.exportPptx(presentation)).save(candidatePath);
  for (let i=0;i<presentation.slides.items.length;i++) {
    const preview = await presentation.export({slide:presentation.slides.items[i],format:'png',scale:1.5});
    await fs.writeFile(path.join(outputDir,`slide-${i+1}.png`),new Uint8Array(await preview.arrayBuffer()));
  }
  const receipt = {schema:'aurelia-recipe-build-v1',status:'draft-not-delivered',purpose:request.purpose,
    library_sha256:libraryHash,request_sha256:hash(requestBytes),candidate_sha256:hash(await fs.readFile(candidatePath)),
    page_count:used.length,recipes:used,warnings,
    source_file_access:'No original PPT was opened. Only distilled recipes, new bindings and explicitly supplied assets were read.',
    limitations:'This build receipt is not the engine finalization receipt and does not pass the delivery gate.'};
  await fs.writeFile(path.join(outputDir,'build-receipt.json'),JSON.stringify(receipt,null,2));
  return {candidatePath,...receipt};
}

if(process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const {values} = parseArgs({options:{library:{type:'string'},request:{type:'string'},output:{type:'string'}}});
  need(values.library && values.request && values.output,'Usage: --library recipes.jsonl --request bindings.json --output NEW_DIRECTORY');
  build(path.resolve(values.library),path.resolve(values.request),path.resolve(values.output))
    .then(r=>console.log(JSON.stringify(r,null,2))).catch(e=>{console.error(e.stack);process.exitCode=2;});
}
