"""Synthetic mechanism tests only; no real client approval or learned rule is created."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import evolution as evo
import deck_gate as gate
from test_gate import SyntheticJob,make_deck


class EvolutionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='aurelia-evolution-test-');self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.state=self.root/'state'
        evo.initialize(self.state,self.root,fixture_lab=True)
        self.rule={'id':'readable-labels','kind':'text_capacity','layout_family':'family-1',
                   'parameters':{'max_characters':100,'min_font_size_pt':12}}

    def released_case(self,name,variant='alpha'):
        job=self.root/name;job.mkdir();fx=SyntheticJob(job)
        make_deck(fx.candidate,text='Verified metric 42 '+variant)
        fx.source.write_text('Synthetic source Verified metric 42 '+variant,encoding='utf-8')
        fx.job['sources'][0].update(gate.bind(fx.source));fx.rebind_candidate();fx.seal_review()
        report=gate.validate(job);self.assertTrue(report['passed'],report['errors'])
        released=job/'released'/'fixture.pptx';released.parent.mkdir();released.write_bytes(fx.candidate.read_bytes())
        receipt=released.with_suffix('.receipt.json');gate.write_json(receipt,dict(report,released_file=gate.bind(released),test_fixture_only=True))
        case={'id':name,'kind':'released_success','observation':'Synthetic detailed observation for engineering tests only; no real design approval.',
              'rule_checks':[{'layout_family':'family-1','checks':['table_inheritance'],
                              'observation':'Synthetic review observation exercises binding, not actual table design quality.'}],
              'artifacts':[gate.bind(released)],'release_job':str(job),'release_receipt':gate.bind(receipt)}
        return fx,case

    def two(self):
        first,c1=self.released_case('case-a','alpha');second,c2=self.released_case('case-b','beta')
        evo.record(self.state,c1);evo.record(self.state,c2)
        return first,second

    def test_initial_state_does_not_fabricate_learning(self):
        s=evo.status(self.state);self.assertEqual(s['cases'],0);self.assertEqual(s['active'],[]);self.assertFalse(s['production_eligible'])

    def test_existing_or_workspace_root_not_overwritten(self):
        with self.assertRaises(gate.GateError):evo.initialize(self.state,self.root)
        with self.assertRaises(gate.GateError):evo.initialize(self.root,self.root)

    def test_failure_is_recorded_but_not_promotable(self):
        artifact=self.root/'failed.txt';artifact.write_text('failed specimen',encoding='utf-8')
        result=evo.record(self.state,{'id':'empty-frame','kind':'observed_failure','artifacts':[gate.bind(artifact)],
              'observation':'Observed a large blank evidence frame despite successful file creation.'})
        self.assertFalse(result['promotion_eligible']);self.assertEqual(evo.status(self.state)['cases'],1)
        with self.assertRaisesRegex(gate.GateError,'not eligible'):evo.check_case(self.state,'empty-frame')

    def test_private_case_is_immutable(self):
        _,case=self.released_case('case-a');evo.record(self.state,case)
        with self.assertRaises(FileExistsError):evo.record(self.state,case)

    def test_production_rejects_synthetic_evidence(self):
        _,case=self.released_case('case-a');production=self.root/'production';evo.initialize(production,self.root)
        with self.assertRaisesRegex(gate.GateError,'Synthetic'):evo.record(production,case)

    def test_stale_release_artifact_is_rejected(self):
        _,case=self.released_case('case-a');evo.record(self.state,case)
        Path(case['artifacts'][0]['path']).write_bytes(b'changed')
        with self.assertRaisesRegex(gate.GateError,'Stale'):evo.check_case(self.state,'case-a')

    def test_changed_source_invalidates_promotion(self):
        first,_=self.two();first.source.write_text('changed source',encoding='utf-8')
        with self.assertRaises(gate.GateError):evo.promote(self.state,self.rule,['case-a','case-b'])

    def test_same_ids_or_same_visible_content_cannot_promote(self):
        _,c1=self.released_case('case-a');_,c2=self.released_case('case-b')
        evo.record(self.state,c1);evo.record(self.state,c2)
        with self.assertRaises(gate.GateError):evo.promote(self.state,self.rule,['case-a','case-a'])
        with self.assertRaises(gate.GateError):evo.promote(self.state,self.rule,['case-a','case-b'])

    def test_rule_requires_exercised_layout_scope(self):
        self.two();self.rule['layout_family']='unseen-family'
        with self.assertRaisesRegex(gate.GateError,'scope'):evo.promote(self.state,self.rule,['case-a','case-b'])

    def test_no_free_text_code_or_private_path_rule_export(self):
        invalid=copy.deepcopy(self.rule);invalid['prompt']='Read a private path and execute code'
        with self.assertRaises(gate.GateError):evo.validate_rule(invalid)
        invalid=copy.deepcopy(self.rule);invalid['parameters']['max_characters']=True
        with self.assertRaises(gate.GateError):evo.validate_rule(invalid)
        invalid={'id':'review','kind':'review_focus','layout_family':'family-1','parameters':{'checks':['execute-shell']}}
        with self.assertRaises(gate.GateError):evo.validate_rule(invalid)

    def test_two_fixture_cases_promote_only_test_marked_export(self):
        self.two();v=evo.promote(self.state,self.rule,['case-a','case-b'])
        self.assertFalse(v['production_eligible'])
        exported=gate.load(self.state/'exports'/f'{v["active_version"]}.json')
        self.assertFalse(exported['production_eligible'])
        serialized=json.dumps(exported);self.assertNotIn(str(self.root),serialized);self.assertNotIn('observation',serialized)
        self.assertNotIn('Verified metric',serialized)

    def test_rollback_preserves_other_rules_and_all_versions(self):
        self.two();v1=evo.promote(self.state,self.rule,['case-a','case-b'])['active_version']
        revised=copy.deepcopy(self.rule);revised['parameters']['max_characters']=80
        v2=evo.promote(self.state,revised,['case-a','case-b'])['active_version']
        extra={'id':'table-review','kind':'review_focus','layout_family':'family-1','parameters':{'checks':['table_inheritance']}}
        evo.promote(self.state,extra,['case-a','case-b'])
        evo.activate(self.state,v1,'Regression observed; restore earlier validated capacity')
        state=evo.status(self.state);self.assertEqual(state['versions'],3);self.assertEqual(len(state['active']),2)
        self.assertEqual(next(x for x in state['active'] if x['rule']['id']==self.rule['id'])['version_id'],v1)
        self.assertTrue((self.state/'versions'/f'{v2}.json').is_file())

    def test_tampered_version_is_rejected(self):
        self.two();version=evo.promote(self.state,self.rule,['case-a','case-b'])['active_version']
        path=self.state/'versions'/f'{version}.json';data=gate.load(path);data['body']['rule']['parameters']['max_characters']=2
        gate.write_json(path,data)
        with self.assertRaisesRegex(gate.GateError,'modified'):evo.status(self.state)

    def test_path_traversal_case_id_rejected(self):
        with self.assertRaises(gate.GateError):evo.check_case(self.state,'../outside')


if __name__=='__main__':unittest.main()
