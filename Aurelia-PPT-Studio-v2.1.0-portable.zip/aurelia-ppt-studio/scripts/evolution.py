"""Workspace-local PPT feedback ledger and evidence-bound, reversible rule versions.

No network, arbitrary code execution, model training, or automatic skill edits.
Hashes detect drift; they cannot authenticate invented human approvals.
"""
import argparse
import json
import os
from pathlib import Path
import re
import sys
import uuid
import deck_gate as gate
from pptx_inspect import digest, inspect, sha


def identifier(value):
    gate.need(isinstance(value,str) and re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}',value), 'Invalid identifier')
    return value


def save_new(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)


def initialize(root,workspace=None,fixture_lab=False):
    root=Path(root).resolve(); workspace=Path(workspace or Path.cwd()).resolve()
    gate.need(root!=workspace and root.is_relative_to(workspace),'State must be a new child directory in the explicit workspace')
    gate.need(not root.exists(),'Existing folder is preserved; choose a new state directory')
    root.mkdir(parents=True)
    save_new(root/'state.json',{'schema':'aurelia-evolution-v1','workspace':str(workspace),
        'mode':'fixture-lab' if fixture_lab else 'production','created_at':gate.timestamp()})
    return status(root)


def config(root):
    root=Path(root).resolve(); data=gate.load(root/'state.json')
    gate.need(data.get('schema')=='aurelia-evolution-v1','Unknown evolution state')
    gate.need(data.get('mode') in ('production','fixture-lab'),'Unknown state mode')
    gate.need(root.is_relative_to(Path(data['workspace']).resolve()),'State has left its recorded workspace')
    return root,data


def release_evidence(job_path,receipt_record,fixture_lab=False):
    job_path=Path(job_path).resolve()
    receipt_path=gate.verified(receipt_record)
    gate.need(receipt_path.resolve().is_relative_to(job_path/'released'),'Receipt is outside released directory')
    receipt=gate.load(receipt_path)
    gate.need(receipt.get('passed') is True and not receipt.get('errors'),'Release receipt is not passed')
    deck=gate.verified(receipt['released_file'])
    gate.need(deck.resolve().is_relative_to(job_path/'released'),'Released deck is outside released directory')
    result=gate.validate(job_path)
    gate.need(result['passed'],'Production gate failed: '+'; '.join(result['errors']))
    gate.need(receipt.get('snapshot')==result['snapshot'],'Stale release snapshot')
    gate.need(receipt.get('candidate_sha256')==sha(deck)==result['candidate_sha256'],'Release/candidate mismatch')
    job=gate.load(job_path/'job.json')
    engine=gate.load(gate.verified(job['engine_receipt'])); render=gate.load(gate.verified(job['render']))
    synthetic=any(x.get('test_fixture_only') is True for x in (job,receipt,engine,render))
    gate.need(fixture_lab or not synthetic,'Synthetic evidence cannot promote production knowledge')
    info=inspect(deck)
    # Renaming, re-zipping and recoloring the same visible copy are not different content.
    content=digest([[re.sub(r'\s+','',p) for p in s['paragraphs']] for s in info['slides']])
    sources=digest(sorted(gate.bind(gate.verified(s))['sha256'] for s in job['sources']))
    return {'deck_sha256':sha(deck),'content_sha256':content,'source_set_sha256':sources,
            'snapshot':result['snapshot'],'layout_families':sorted(set(s['layout_family'] for s in job['storyboard'])),
            'synthetic':synthetic,'production_eligible':not synthetic and not fixture_lab}


def record(root,data):
    root,cfg=config(root)
    case_id=identifier(data.get('id'))
    gate.need(data.get('kind') in ('observed_failure','released_success'),'Unknown case kind')
    gate.need(isinstance(data.get('observation'),str) and len(data['observation'].strip())>=20,'Specific private observation required')
    artifacts=data.get('artifacts') or []
    gate.need(artifacts,'Bind at least one actual case artifact')
    for artifact in artifacts:gate.verified(artifact)
    # Preserve only supported private fields. Observations are data, never commands.
    case={k:data[k] for k in ('id','kind','observation','artifacts')}
    if data.get('user_feedback') is not None:case['user_feedback']=str(data['user_feedback'])
    if 'rule_checks' in data:
        gate.need(isinstance(data['rule_checks'],list),'Rule checks must be a list')
        for item in data['rule_checks']:
            gate.need(set(item)=={'layout_family','checks','observation'},'Unknown case review fields')
            validate_rule({'id':'case-review','kind':'review_focus','layout_family':item['layout_family'],
                           'parameters':{'checks':item['checks']}})
            gate.need(isinstance(item['observation'],str) and len(item['observation'].strip())>=20,'Specific rule review observation required')
        case['rule_checks']=data['rule_checks']
    if data['kind']=='released_success':
        case['release_job']=str(Path(data['release_job']).resolve());case['release_receipt']=data['release_receipt']
        case['verified_release']=release_evidence(case['release_job'],case['release_receipt'],cfg['mode']=='fixture-lab')
    case['recorded_at']=gate.timestamp()
    save_new(gate.local(root,f'cases/{case_id}.json'),case)
    return {'case_id':case_id,'kind':case['kind'],'promotion_eligible':case['kind']=='released_success' and cfg['mode']=='production'}


def check_case(root,case_id):
    root,cfg=config(root); case=gate.load(gate.local(root,f'cases/{identifier(case_id)}.json'))
    for artifact in case['artifacts']:gate.verified(artifact)
    gate.need(case['kind']=='released_success','Observed failure is recorded but not eligible for promotion')
    actual=release_evidence(case['release_job'],case['release_receipt'],cfg['mode']=='fixture-lab')
    gate.need(actual==case['verified_release'],'Recorded evidence changed')
    return actual


def validate_rule(rule):
    gate.need(set(rule)=={'id','kind','layout_family','parameters'},'Rule must use the abstract allowlisted schema')
    identifier(rule['id']);identifier(rule['layout_family'])
    parameters=rule['parameters'];gate.need(isinstance(parameters,dict),'Rule parameters must be an object')
    if rule['kind']=='text_capacity':
        gate.need(set(parameters)=={'max_characters','min_font_size_pt'},'Unknown capacity parameters')
        gate.need(type(parameters['max_characters']) is int and 1<=parameters['max_characters']<=2000,'Invalid text capacity')
        gate.need(type(parameters['min_font_size_pt']) in (int,float) and 6<=parameters['min_font_size_pt']<=72,'Invalid font threshold')
    elif rule['kind']=='evidence_owner':
        gate.need(set(parameters)=={'required_kind'} and parameters['required_kind'] in ('table','chart','diagram','image'),'Invalid evidence owner rule')
    elif rule['kind']=='review_focus':
        allowed={'overflow','occlusion','empty_evidence','contrast','native_editability','source_coverage','table_inheritance'}
        checks=parameters.get('checks')
        gate.need(set(parameters)=={'checks'} and isinstance(checks,list) and checks and all(isinstance(x,str) and x in allowed for x in checks),'Invalid review checks')
    else:raise gate.GateError('Unsupported rule kind; no free-text/code execution')
    return rule


def verify_version(root,version_id):
    root,cfg=config(root); payload=gate.load(gate.local(root,f'versions/{identifier(version_id)}.json'))
    body=payload['body'];gate.need(digest(body)==payload['sha256'],'Rule version was modified')
    gate.need(body['mode']==cfg['mode'],'Fixture/production version mismatch')
    gate.need(body['production_eligible']==(cfg['mode']=='production'),'Invalid production eligibility')
    validate_rule(body['rule'])
    for item in body['cases']:
        path=gate.local(root,f'cases/{identifier(item["id"])}.json')
        gate.need(sha(path)==item['sha256'],'Supporting case record changed')
    check_rule_cases(root,body['rule'],[item['id'] for item in body['cases']])
    return payload


def check_rule_cases(root,rule,case_ids):
    gate.need(len(case_ids)>=2 and len(set(case_ids))==len(case_ids),'Need at least two distinct case IDs')
    evidence=[check_case(root,case_id) for case_id in case_ids]
    gate.need(len({r['deck_sha256'] for r in evidence})==len(evidence),'Same deck is not independent evidence')
    gate.need(len({r['content_sha256'] for r in evidence})==len(evidence),'Same visible content is not independent evidence')
    gate.need(len({r['source_set_sha256'] for r in evidence})==len(evidence),'Need different source-content cases')
    gate.need(all(rule['layout_family'] in r['layout_families'] for r in evidence),'Rule scope was not exercised by each case')
    for case_id in case_ids:
        case=gate.load(gate.local(root,f'cases/{identifier(case_id)}.json'))
        job_path=Path(case['release_job']);job=gate.load(job_path/'job.json')
        receipt=gate.load(gate.verified(case['release_receipt']))
        actual=inspect(gate.verified(receipt['released_file']))
        scoped=[(plan,actual['slides'][plan['slide']-1]) for plan in job['storyboard'] if plan['layout_family']==rule['layout_family']]
        for plan,page in scoped:
            if rule['kind']=='evidence_owner':
                owner=rule['parameters']['required_kind']
                gate.need(plan['visual_owner']==owner,'Rule evidence owner was not exercised in storyboard')
                count=(page['picture_count'] if owner=='image' else
                       sum(e['kind'] in ('sp','text','cxnSp','grpSp') for e in page['elements']) if owner=='diagram' else
                       page[f'{owner}_count'])
                gate.need(count >= (2 if owner=='diagram' else 1),'Rule lacks the required native evidence owner')
            elif rule['kind']=='text_capacity':
                params=rule['parameters']
                gate.need(page['paragraphs'] and all(len(p)<=params['max_characters'] for p in page['paragraphs']),
                          'Case paragraph exceeds proposed text capacity')
                text_elements=[e for e in page['elements'] if e['kind'] in ('text','grpSp','table')]
                gate.need(text_elements and all(e['font_sizes'] for e in text_elements),'Explicit font evidence required for capacity promotion')
                gate.need(all(size>=params['min_font_size_pt'] for e in text_elements for size in e['font_sizes']),
                          'Case font is below proposed minimum font size')
        if rule['kind']=='review_focus':
            reviews=[r for r in case.get('rule_checks',[]) if r['layout_family']==rule['layout_family']]
            recorded={c for r in reviews for c in r['checks']}
            gate.need(set(rule['parameters']['checks']).issubset(recorded),'Missing specific case rule review evidence')
    return evidence


def activate(root,version_id,reason):
    root,cfg=config(root);version=verify_version(root,version_id)
    gate.need(len(reason.strip())>=12,'Specific activation/rollback reason required')
    rule_id=version['body']['rule']['id']
    active=gate.load(root/'active.json') if (root/'active.json').is_file() else {'rules':{}}
    # One rule's upgrade/rollback must not erase other learned capabilities.
    for existing_id,entry in active['rules'].items():
        if existing_id!=rule_id:
            existing=verify_version(root,entry['version_id'])
            gate.need(entry['version_sha256']==existing['sha256'],'Existing active pointer hash mismatch')
            gate.need(existing['body']['rule']['id']==existing_id,'Existing active rule ID mismatch')
    active['rules'][rule_id]={'version_id':version_id,'version_sha256':version['sha256']}
    event={'rule_id':rule_id,'version_id':version_id,'version_sha256':version['sha256'],'reason':reason,'recorded_at':gate.timestamp()}
    event_id=uuid.uuid4().hex
    save_new(gate.local(root,f'history/{event_id}.json'),event)
    temporary=gate.local(root,f'.active-{event_id}.json')
    save_new(temporary,active)
    os.replace(temporary,gate.local(root,'active.json'))
    return {'active_version':version_id,'production_eligible':cfg['mode']=='production'}


def promote(root,rule,case_ids):
    root,cfg=config(root);validate_rule(rule)
    evidence=check_rule_cases(root,rule,case_ids)
    version_id='v-'+uuid.uuid4().hex[:16]
    body={'rule':rule,'mode':cfg['mode'],'production_eligible':cfg['mode']=='production',
          'cases':[{'id':identifier(case_id),'sha256':sha(gate.local(root,f'cases/{case_id}.json'))} for case_id in case_ids],
          'created_at':gate.timestamp()}
    save_new(gate.local(root,f'versions/{version_id}.json'),{'body':body,'sha256':digest(body)})
    # Export contains no private observations, paths, user copy or source assets.
    save_new(gate.local(root,f'exports/{version_id}.json'),{'schema':'aurelia-abstract-rule-v1','rule':rule,
        'production_eligible':cfg['mode']=='production','evidence_count':len(evidence),'version_sha256':digest(body)})
    return activate(root,version_id,'Evidence-bound promotion after distinct-case validation')


def status(root):
    root,cfg=config(root);active=[]
    if (root/'active.json').is_file():
        pointers=gate.load(root/'active.json')['rules']
        for rule_id,pointer in pointers.items():
            version=verify_version(root,pointer['version_id'])
            gate.need(pointer['version_sha256']==version['sha256'],'Active pointer hash mismatch')
            gate.need(version['body']['rule']['id']==rule_id,'Active rule ID mismatch')
            active.append({'version_id':pointer['version_id'],'rule':version['body']['rule']})
    return {'schema':'aurelia-agent-status-v1','mode':cfg['mode'],'cases':len(list((root/'cases').glob('*.json'))),
            'versions':len(list((root/'versions').glob('*.json'))),'active':active,
            'production_eligible':bool(active) and cfg['mode']=='production','background_service':False}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--state',required=True)
    s=p.add_subparsers(dest='command',required=True)
    cmd=s.add_parser('init');cmd.add_argument('--workspace');cmd.add_argument('--fixture-lab',action='store_true')
    cmd=s.add_parser('record');cmd.add_argument('--case',required=True)
    cmd=s.add_parser('check');cmd.add_argument('--case-id',required=True)
    cmd=s.add_parser('promote');cmd.add_argument('--rule',required=True);cmd.add_argument('--case-id',action='append',required=True)
    cmd=s.add_parser('rollback');cmd.add_argument('--version',required=True);cmd.add_argument('--reason',required=True)
    s.add_parser('status');a=p.parse_args()
    if a.command=='init':result=initialize(a.state,a.workspace,a.fixture_lab)
    elif a.command=='record':result=record(a.state,gate.load(a.case))
    elif a.command=='check':result=check_case(a.state,a.case_id)
    elif a.command=='promote':result=promote(a.state,gate.load(a.rule),a.case_id)
    elif a.command=='rollback':result=activate(a.state,a.version,a.reason)
    else:result=status(a.state)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError,TypeError) as error:
        print(f'BLOCKED: {error}',file=sys.stderr);sys.exit(2)
